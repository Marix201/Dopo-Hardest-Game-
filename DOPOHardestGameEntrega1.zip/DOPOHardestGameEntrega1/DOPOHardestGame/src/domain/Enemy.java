package domain;
import java.awt.*;

public class Enemy extends GameElement {
    private int dx, dy;

    public Enemy(int x, int y, int dx, int dy) {
        super(x, y, 20, 20);
        this.dx = dx;
        this.dy = dy;
    }

    public void move() {
        x += dx;
        y += dy;
    }

    public void reverseX() { dx = -dx; }
    public void reverseY() { dy = -dy; }

    public boolean collidesWithPlayer(Player p) {
        return getBounds().intersects(p.getBounds());
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 60));
        g2.fillOval(x + 3, y + 3, width, height);
        GradientPaint gp = new GradientPaint(
            x, y,             new Color(80, 140, 255),
            x + width, y + height, new Color(20, 60, 200)
        );
        g2.setPaint(gp);
        g2.fillOval(x, y, width, height);
        g2.setColor(new Color(255, 255, 255, 100));
        g2.fillOval(x + 4, y + 3, width / 3, height / 3);
        g2.setColor(new Color(10, 30, 150));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawOval(x, y, width, height);
    }
}