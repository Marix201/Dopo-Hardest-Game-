package presentation;
import domain.*;
import domain.Zone.ZoneType;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements KeyListener, ActionListener {
    private GameEngine         engine;
    private HUDPanel           hud;
    private DopoHardestGameGUI gui;
    private Timer              timer;
    private boolean[]          keys  = new boolean[256];
    private boolean            won   = false;
    private boolean            lost  = false;

    private static final int TIME_LIMIT   = 60;
    private static final int TOTAL_LEVELS = 5;
    private int timeLeft;
    private int tickCount    = 0;
    private int currentLevel = 1;

    public static final int WIDTH  = 620;
    public static final int HEIGHT = 400;

    private static final int BOARD_X    = 10;
    private static final int BOARD_Y    = 60;
    private static final int BOARD_W    = 600;
    private static final int BOARD_H    = 280;

    private static final int CORRIDOR_X = 160;
    private static final int CORRIDOR_Y = BOARD_Y;
    private static final int CORRIDOR_W = 280;
    private static final int CORRIDOR_H = BOARD_H;

    private static final int START_X = BOARD_X;
    private static final int START_Y = BOARD_Y;
    private static final int ZONE_W  = CORRIDOR_X - BOARD_X;
    private static final int ZONE_H  = BOARD_H;

    private static final int GOAL_X = CORRIDOR_X + CORRIDOR_W;
    private static final int GOAL_Y = BOARD_Y;

    private static final int PLAYER_START_X = START_X + ZONE_W / 2 - 10;
    private static final int PLAYER_START_Y = START_Y + ZONE_H  / 2 - 10;

    private Rectangle btnPrimary;
    private Rectangle btnLevels;
    private Rectangle btnExit;

    public GamePanel(HUDPanel hud, DopoHardestGameGUI gui) {
        this.hud = hud;
        this.gui = gui;
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        addKeyListener(this);
        timer = new Timer(16, this);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!won && !lost) return;
                Point p = e.getPoint();
                if (btnPrimary != null && btnPrimary.contains(p)) {
                    won  = false;
                    lost = false;
                    startGame(currentLevel);
                } else if (btnLevels != null && btnLevels.contains(p)) {
                    timer.stop();
                    gui.showLevelSelect();
                } else if (btnExit != null && btnExit.contains(p)) {
                    timer.stop();
                    gui.showMenu();
                }
            }
        });
    }

    public void startGame(int levelNumber) {
        this.currentLevel = levelNumber;
        Level  level  = buildLevel(levelNumber);
        Player player = new Player(PLAYER_START_X, PLAYER_START_Y);
        engine    = new GameEngine(player, level);
        won       = false;
        lost      = false;
        timeLeft  = TIME_LIMIT;
        tickCount = 0;
        if (!timer.isRunning()) timer.start();
    }

    private Level buildLevel(int number) {
        Level level = new Level(number);
        level.setStartZone(new Zone(START_X, START_Y, ZONE_W, ZONE_H, ZoneType.START));
        level.setGoalZone( new Zone(GOAL_X,  GOAL_Y,  ZONE_W, ZONE_H, ZoneType.GOAL));
        level.addEnemy(new Enemy(220, CORRIDOR_Y + 20,  0,  2));
        level.addEnemy(new Enemy(300, CORRIDOR_Y + 80,  0, -2));
        level.addEnemy(new Enemy(360, CORRIDOR_Y + 20,  0,  2));
        level.addEnemy(new Enemy(260, CORRIDOR_Y + 150, 0, -2));
        level.addCoin(new Coin(230, CORRIDOR_Y + CORRIDOR_H / 2 - 6));
        level.addCoin(new Coin(295, CORRIDOR_Y + CORRIDOR_H / 2 - 6));
        level.addCoin(new Coin(360, CORRIDOR_Y + CORRIDOR_H / 2 - 6));
        return level;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (won || lost) return;

        tickCount++;
        if (tickCount >= 60) {
            tickCount = 0;
            timeLeft--;
            if (timeLeft <= 0) {
                timeLeft = 0;
                lost = true;
                timer.stop();
                hud.update(engine.getPlayer().getDeaths(),
                           engine.getCurrentLevel().getNumber(), timeLeft);
                repaint();
                return;
            }
        }

        Player p = engine.getPlayer();
        int dx = 0, dy = 0;
        if (keys[KeyEvent.VK_LEFT]  || keys[KeyEvent.VK_A]) dx = -1;
        if (keys[KeyEvent.VK_RIGHT] || keys[KeyEvent.VK_D]) dx =  1;
        if (keys[KeyEvent.VK_UP]    || keys[KeyEvent.VK_W]) dy = -1;
        if (keys[KeyEvent.VK_DOWN]  || keys[KeyEvent.VK_S]) dy =  1;

        p.setDirection(dx, dy);
        engine.update();

        if (p.getX() < BOARD_X)
            p.setX(BOARD_X);
        if (p.getX() > BOARD_X + BOARD_W - p.getWidth())
            p.setX(BOARD_X + BOARD_W - p.getWidth());
        if (p.getY() < BOARD_Y)
            p.setY(BOARD_Y);
        if (p.getY() > BOARD_Y + BOARD_H - p.getHeight())
            p.setY(BOARD_Y + BOARD_H - p.getHeight());

        for (Enemy enemy : engine.getCurrentLevel().getEnemies()) {
            if (enemy.getY() <= CORRIDOR_Y)
                enemy.reverseY();
            if (enemy.getY() + enemy.getHeight() >= CORRIDOR_Y + CORRIDOR_H)
                enemy.reverseY();
            if (enemy.getX() <= CORRIDOR_X)
                enemy.reverseX();
            if (enemy.getX() + enemy.getWidth() >= CORRIDOR_X + CORRIDOR_W)
                enemy.reverseX();
        }

        if (!p.isAlive()) {
            p.reset(PLAYER_START_X, PLAYER_START_Y);
        }

        if (engine.getCurrentLevel().isComplete(p)) {
            won = true;
            timer.stop();
        }

        hud.update(p.getDeaths(),
                   engine.getCurrentLevel().getNumber(), timeLeft);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(new Color(100, 120, 200));
        g2.fillRect(0, 0, WIDTH, HEIGHT);

        g2.setColor(new Color(120, 210, 120));
        g2.fillRect(START_X, START_Y, ZONE_W, ZONE_H);

        int tileSize = 20;
        for (int row = 0; row < CORRIDOR_H / tileSize; row++) {
            for (int col = 0; col < CORRIDOR_W / tileSize; col++) {
                g2.setColor((row + col) % 2 == 0
                    ? new Color(230, 230, 245)
                    : new Color(210, 210, 235));
                g2.fillRect(CORRIDOR_X + col * tileSize,
                            CORRIDOR_Y + row * tileSize,
                            tileSize, tileSize);
            }
        }

        g2.setColor(new Color(120, 210, 120));
        g2.fillRect(GOAL_X, GOAL_Y, ZONE_W, ZONE_H);

        g2.setColor(new Color(30, 30, 50));
        g2.setStroke(new BasicStroke(3));
        g2.drawRect(BOARD_X, BOARD_Y, BOARD_W, BOARD_H);

        g2.setStroke(new BasicStroke(2));
        g2.drawLine(CORRIDOR_X, BOARD_Y, CORRIDOR_X, BOARD_Y + BOARD_H);
        g2.drawLine(GOAL_X,     BOARD_Y, GOAL_X,     BOARD_Y + BOARD_H);

        g2.setFont(new Font("Arial", Font.BOLD, 12));
        g2.setColor(new Color(20, 80, 20));
        FontMetrics fm = g2.getFontMetrics();
        String sLabel = "START";
        String gLabel = "GOAL";
        g2.drawString(sLabel,
            START_X + (ZONE_W - fm.stringWidth(sLabel)) / 2,
            START_Y + ZONE_H / 2);
        g2.drawString(gLabel,
            GOAL_X + (ZONE_W - fm.stringWidth(gLabel)) / 2,
            GOAL_Y + ZONE_H / 2);

        Level lvl = engine.getCurrentLevel();
        lvl.getWalls().forEach(w   -> w.draw(g2));
        lvl.getCoins().forEach(c   -> c.draw(g2));
        lvl.getEnemies().forEach(en -> en.draw(g2));
        engine.getPlayer().draw(g2);

        g2.setColor(new Color(30, 30, 50));
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(2, 2, WIDTH - 4, HEIGHT - 4);

        if (won)  drawWinOverlay(g2);
        if (lost) drawLoseOverlay(g2);
    }

    private int[] overlayBox() {
        int boxW = 400, boxH = 240;
        int boxX = (WIDTH  - boxW) / 2;
        int boxY = (HEIGHT - boxH) / 2;
        return new int[]{boxX, boxY, boxW, boxH};
    }

    private void computeButtonRects(int boxX, int boxY) {
        int btnW = 110, btnH = 38;
        int y    = boxY + 150;
        btnPrimary = new Rectangle(boxX + 20,  y, btnW, btnH);
        btnLevels  = new Rectangle(boxX + 145, y, btnW, btnH);
        btnExit    = new Rectangle(boxX + 270, y, btnW, btnH);
    }

    private void drawWinOverlay(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 160));
        g2.fillRect(0, 0, WIDTH, HEIGHT);

        int[] b   = overlayBox();
        int boxX  = b[0], boxY = b[1], boxW = b[2], boxH = b[3];

        GradientPaint bg = new GradientPaint(
            boxX, boxY, new Color(30, 80, 30),
            boxX + boxW, boxY + boxH, new Color(10, 40, 10));
        g2.setPaint(bg);
        g2.fillRoundRect(boxX, boxY, boxW, boxH, 20, 20);
        g2.setColor(new Color(80, 220, 80));
        g2.setStroke(new BasicStroke(3));
        g2.drawRoundRect(boxX, boxY, boxW, boxH, 20, 20);

        g2.setColor(new Color(120, 255, 120));
        g2.setFont(new Font("Arial", Font.BOLD, 32));
        FontMetrics fm1 = g2.getFontMetrics();
        String title = "¡GANASTE!";
        g2.drawString(title, boxX + (boxW - fm1.stringWidth(title)) / 2, boxY + 60);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.PLAIN, 15));
        FontMetrics fm2 = g2.getFontMetrics();
        String d = "Muertes: " + engine.getPlayer().getDeaths();
        g2.drawString(d, boxX + (boxW - fm2.stringWidth(d)) / 2, boxY + 100);

        computeButtonRects(boxX, boxY);
        drawBtn(g2, btnPrimary, new Color(40, 120, 40), "CONTINUAR");
        drawBtn(g2, btnLevels,  new Color(40, 40, 160), "VER NIVELES");
        drawBtn(g2, btnExit,    new Color(150, 30, 30), "SALIR");
    }

    private void drawLoseOverlay(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 160));
        g2.fillRect(0, 0, WIDTH, HEIGHT);

        int[] b   = overlayBox();
        int boxX  = b[0], boxY = b[1], boxW = b[2], boxH = b[3];

        GradientPaint bg = new GradientPaint(
            boxX, boxY, new Color(100, 20, 20),
            boxX + boxW, boxY + boxH, new Color(50, 10, 10));
        g2.setPaint(bg);
        g2.fillRoundRect(boxX, boxY, boxW, boxH, 20, 20);
        g2.setColor(new Color(220, 60, 60));
        g2.setStroke(new BasicStroke(3));
        g2.drawRoundRect(boxX, boxY, boxW, boxH, 20, 20);

        g2.setColor(new Color(255, 100, 100));
        g2.setFont(new Font("Arial", Font.BOLD, 28));
        FontMetrics fm1 = g2.getFontMetrics();
        String title = "¡TIEMPO AGOTADO!";
        g2.drawString(title, boxX + (boxW - fm1.stringWidth(title)) / 2, boxY + 60);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.PLAIN, 15));
        FontMetrics fm2 = g2.getFontMetrics();
        String d = "Muertes: " + engine.getPlayer().getDeaths();
        g2.drawString(d, boxX + (boxW - fm2.stringWidth(d)) / 2, boxY + 100);

        computeButtonRects(boxX, boxY);
        drawBtn(g2, btnPrimary, new Color(40, 120, 40), "REINTENTAR");
        drawBtn(g2, btnLevels,  new Color(40, 40, 160), "VER NIVELES");
        drawBtn(g2, btnExit,    new Color(150, 30, 30), "SALIR");
    }

    private void drawBtn(Graphics2D g2, Rectangle r, Color color, String label) {
        g2.setColor(color);
        g2.fillRoundRect(r.x, r.y, r.width, r.height, 10, 10);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(1));
        g2.drawRoundRect(r.x, r.y, r.width, r.height, 10, 10);
        g2.setFont(new Font("Arial", Font.BOLD, 11));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(label,
            r.x + (r.width  - fm.stringWidth(label)) / 2,
            r.y + (r.height + fm.getAscent()) / 2 - 2);
    }

    @Override
    public void keyPressed(KeyEvent e)  { keys[e.getKeyCode()] = true; }
    @Override
    public void keyReleased(KeyEvent e) { keys[e.getKeyCode()] = false; }
    @Override
    public void keyTyped(KeyEvent e)    {}
}