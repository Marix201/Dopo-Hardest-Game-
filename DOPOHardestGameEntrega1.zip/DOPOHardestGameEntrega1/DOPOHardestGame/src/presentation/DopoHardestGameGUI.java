package presentation;
import javax.swing.*;
import java.awt.*;

public class DopoHardestGameGUI {
    private JFrame           frame;
    private MenuPanel        menuPanel;
    private GamePanel        gamePanel;
    private HUDPanel         hudPanel;
    private LevelSelectPanel levelSelectPanel;

    public DopoHardestGameGUI() {
        frame = new JFrame("The DOPO Hardest Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        menuPanel = new MenuPanel(this);
        frame.add(menuPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void showLevelSelect() {
        frame.getContentPane().removeAll();
        levelSelectPanel = new LevelSelectPanel(this);
        frame.add(levelSelectPanel);
        frame.revalidate();
        frame.repaint();
    }

    public void showInstructions() {
        frame.getContentPane().removeAll();
        menuPanel = new MenuPanel(this);
        menuPanel.goToInstructions();
        frame.add(menuPanel);
        frame.revalidate();
        frame.repaint();
    }

    public void startGame(int levelNumber) {
        frame.getContentPane().removeAll();
        hudPanel  = new HUDPanel();
        gamePanel = new GamePanel(hudPanel, this);
        frame.setLayout(new BorderLayout());
        frame.add(hudPanel,  BorderLayout.NORTH);
        frame.add(gamePanel, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
        gamePanel.requestFocusInWindow();
        gamePanel.startGame(levelNumber);
    }

    public void showMenu() {
        frame.getContentPane().removeAll();
        menuPanel = new MenuPanel(this);
        frame.add(menuPanel);
        frame.revalidate();
        frame.repaint();
    }
}