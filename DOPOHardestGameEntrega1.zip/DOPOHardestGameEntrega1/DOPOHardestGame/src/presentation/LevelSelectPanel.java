package presentation;
import javax.swing.*;
import java.awt.*;

public class LevelSelectPanel extends JPanel {
    private final DopoHardestGameGUI gui;

    public LevelSelectPanel(DopoHardestGameGUI gui) {
        this.gui = gui;
        setPreferredSize(new Dimension(620, 412));
        setLayout(null);
        setBackground(new Color(160, 175, 220));
        buildPanel();
    }

    private void buildPanel() {
        JLabel title = new JLabel("SELECCIONA UN NIVEL");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 100));
        title.setBounds(0, 40, 620, 40);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title);

        int btnW   = 90;
        int btnH   = 70;
        int padX   = 25;
        int totalW = 5 * btnW + 4 * padX;
        int startX = (620 - totalW) / 2;
        int startY = 140;

        for (int i = 1; i <= 5; i++) {
            int x = startX + (i - 1) * (btnW + padX);

            JButton btn = new JButton("<html><center>NIVEL<br>" + i + "</center></html>");
            btn.setBounds(x, startY, btnW, btnH);
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            btn.setFocusPainted(false);

            if (i == 1) {
                btn.setBackground(new Color(40, 160, 60));
                btn.setForeground(Color.WHITE);
                btn.setBorder(BorderFactory.createLineBorder(
                    new Color(80, 220, 100), 2));
                btn.addActionListener(e -> gui.startGame(1));
            } else {
                btn.setEnabled(false);
                btn.setBackground(new Color(60, 60, 80));
                btn.setForeground(new Color(120, 120, 140));
                btn.setBorder(BorderFactory.createLineBorder(
                    new Color(80, 80, 100), 1));
            }
            add(btn);
        }

        JLabel available = new JLabel("■  Disponible");
        available.setFont(new Font("Arial", Font.PLAIN, 12));
        available.setForeground(new Color(40, 160, 60));
        available.setBounds(200, 260, 110, 20);
        add(available);

        JLabel locked = new JLabel("■  Bloqueado");
        locked.setFont(new Font("Arial", Font.PLAIN, 12));
        locked.setForeground(new Color(120, 120, 140));
        locked.setBounds(330, 260, 110, 20);
        add(locked);

        JButton back = new JButton("← VOLVER");
        back.setBounds(20, 370, 110, 30);
        back.setBackground(new Color(150, 50, 150));
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Arial", Font.BOLD, 12));
        back.setFocusPainted(false);
        back.addActionListener(e -> gui.showInstructions());
        add(back);
    }
}