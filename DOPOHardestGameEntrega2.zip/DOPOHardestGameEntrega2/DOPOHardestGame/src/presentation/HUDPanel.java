package presentation;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HUDPanel extends JPanel {
    private int deaths;
    private int levelNumber;
    private int timeLeft;
    private DopoHardestGameGUI gui;
    private Timer gameTimer;

    public HUDPanel(DopoHardestGameGUI gui) {
        this.gui = gui;
        setPreferredSize(new Dimension(620, 32));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getX() >= 10 && e.getX() <= 50 &&
                    e.getY() >= 5  && e.getY() <= 28) {
                    if (gameTimer != null) gameTimer.stop();
                    gui.showMenu();
                }
            }
        });
    }

    public void setGameTimer(Timer t) { this.gameTimer = t; }

    public void update(int deaths, int levelNumber, int timeLeft) {
        this.deaths      = deaths;
        this.levelNumber = levelNumber;
        this.timeLeft    = timeLeft;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        GradientPaint gp = new GradientPaint(
            0, 0, new Color(20, 20, 40),
            0, getHeight(), new Color(40, 40, 80)
        );
        g2.setPaint(gp);
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setFont(new Font("Arial", Font.BOLD, 13));
        g2.setColor(new Color(100, 180, 255));
        g2.drawString("MENU", 10, 21);
        g2.setColor(Color.WHITE);
        g2.drawString("LEVEL " + levelNumber + " / 5", 230, 21);
        g2.setColor(timeLeft <= 10
            ? new Color(255, 60, 60)
            : new Color(100, 255, 100));
        g2.drawString("TIME: " + timeLeft + "s", 390, 21);
        g2.setColor(new Color(255, 120, 120));
        g2.drawString("DEATHS: " + deaths, 500, 21);
    }
}