package presentation;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuPanel extends JPanel {
    public enum GameState { LOADING, MENU, INSTRUCTIONS }
    private GameState state;
    private final DopoHardestGameGUI gui;
    private JButton begin;

    public MenuPanel(DopoHardestGameGUI gui) {
        this.gui   = gui;
        this.state = GameState.LOADING;
        setPreferredSize(new Dimension(620, 412));
        setLayout(null);
        buildLoadingScreen();

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if (begin != null) {
                    begin.setBounds((getWidth() - 200) / 2,
                                    getHeight() / 2 - 30, 200, 40);
                }
            }
        });
    }

    private void buildLoadingScreen() {
        removeAll();
        setBackground(Color.BLACK);
        begin = new JButton("BEGIN");
        begin.setBounds(210, 176, 200, 40);
        begin.setBackground(new Color(50, 50, 50));
        begin.setForeground(Color.WHITE);
        begin.setFont(new Font("Arial", Font.BOLD, 16));
        begin.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        begin.setFocusPainted(false);
        begin.addActionListener(e -> showMenu());
        add(begin);
        revalidate();
        repaint();
    }

    private void showMenu() {
        state = GameState.MENU;
        begin = null;
        removeAll();
        setBackground(new Color(160, 175, 220));
        JButton play = new JButton("PLAY GAME");
        play.setBounds(210, 220, 200, 45);
        play.setBackground(Color.WHITE);
        play.setForeground(Color.RED);
        play.setFont(new Font("Arial", Font.BOLD, 16));
        play.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        play.setFocusPainted(false);
        play.addActionListener(e -> showInstructions());
        add(play);
        revalidate();
        repaint();
    }

    public void goToInstructions() {
        showInstructions();
    }

    private void showInstructions() {
        state = GameState.INSTRUCTIONS;
        begin = null;
        removeAll();
        setBackground(new Color(160, 175, 220));

        JTextArea text = new JTextArea(
            "Eres el cuadrado rojo (Blinky). Evita los círculos azules " +
            "y recoge todas las monedas amarillas. Una vez recolectadas, " +
            "llega a la zona segura verde para completar el nivel.\n\n" +
            "Si un enemigo te toca, reapareces en el inicio y sumas una " +
            "muerte. Algunos niveles tienen zonas seguras intermedias que " +
            "actúan como puntos de control.\n\n" +
            "Tu puntuación es el número de muertes, entre menos, mejor."
        );
        text.setWrapStyleWord(true);
        text.setLineWrap(true);
        text.setOpaque(false);
        text.setEditable(false);
        text.setFont(new Font("Arial", Font.PLAIN, 14));
        text.setBounds(40, 40, 540, 200);
        add(text);

        JButton back = new JButton("BACK TO MENU");
        back.setBounds(130, 300, 150, 40);
        back.setBackground(new Color(150, 50, 150));
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Arial", Font.BOLD, 13));
        back.setFocusPainted(false);
        back.addActionListener(e -> showMenu());
        add(back);

        JButton playGame = new JButton("VER NIVELES");
        playGame.setBounds(340, 300, 150, 40);
        playGame.setBackground(new Color(200, 30, 30));
        playGame.setForeground(Color.WHITE);
        playGame.setFont(new Font("Arial", Font.BOLD, 13));
        playGame.setFocusPainted(false);
        playGame.addActionListener(e -> gui.showLevelSelect());
        add(playGame);

        revalidate();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);

        int panelW = getWidth();
        int panelH = getHeight();

        if (state == GameState.LOADING) {
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Courier", Font.PLAIN, 13));
            FontMetrics fm = g2.getFontMetrics();
            String complete = "Complete";
            g2.drawString(complete,
                (panelW - fm.stringWidth(complete)) / 2,
                panelH / 2 - 55);

            g2.setColor(new Color(180, 180, 180));
            g2.setFont(new Font("Courier", Font.PLAIN, 11));
            fm = g2.getFontMetrics();
            String line1 = "This is The DOPO Hardest Game.";
            String line2 = "I guarantee it is harder than any game";
            String line3 = "you have ever played, or ever will play.";
            g2.drawString(line1, (panelW - fm.stringWidth(line1)) / 2, panelH / 2 + 55);
            g2.drawString(line2, (panelW - fm.stringWidth(line2)) / 2, panelH / 2 + 70);
            g2.drawString(line3, (panelW - fm.stringWidth(line3)) / 2, panelH / 2 + 85);

            if (begin != null) {
                begin.setBounds((panelW - 200) / 2, panelH / 2 - 30, 200, 40);
            }

        } else if (state == GameState.MENU) {
            g2.setColor(new Color(30, 40, 100));
            g2.setFont(new Font("Arial", Font.PLAIN, 16));
            FontMetrics fm = g2.getFontMetrics();
            String sub = "THE DOPO'S";
            g2.drawString(sub, (panelW - fm.stringWidth(sub)) / 2, 80);

            g2.setFont(new Font("Arial", Font.BOLD, 42));
            fm = g2.getFontMetrics();
            String title = "HARDEST GAME";
            g2.drawString(title, (panelW - fm.stringWidth(title)) / 2, 140);
        }
    }
}