package domain;
import java.awt.*;

public class Coin extends GameElement {
    private boolean collected;

    public Coin(int x, int y) {
        super(x, y, 12, 12);
        this.collected = false;
    }

    public void collect()        { collected = true; }
    public boolean isCollected() { return collected; }
    public void reset()          { collected = false; }

    @Override
    public void draw(Graphics g) {
        if (!collected) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0, 0, 0, 50));
            g2.fillOval(x + 2, y + 2, width, height);
            GradientPaint gp = new GradientPaint(
                x, y,             new Color(255, 220, 50),
                x + width, y + height, new Color(200, 140, 0)
            );
            g2.setPaint(gp);
            g2.fillOval(x, y, width, height);
            g2.setColor(new Color(255, 255, 200, 150));
            g2.fillOval(x + 2, y + 2, width / 3, height / 3);
            g2.setColor(new Color(160, 100, 0));
            g2.setStroke(new BasicStroke(1f));
            g2.drawOval(x, y, width, height);
        }
    }
}