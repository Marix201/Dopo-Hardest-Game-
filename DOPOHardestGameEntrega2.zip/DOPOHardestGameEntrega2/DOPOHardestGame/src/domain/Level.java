package domain;
import java.util.ArrayList;
import java.util.List;

public class Level {
    private int number;
    private List<Enemy> enemies;
    private List<Wall>  walls;
    private List<Coin>  coins;
    private Zone startZone, goalZone;

    public Level(int number) {
        this.number = number;
        enemies = new ArrayList<>();
        walls   = new ArrayList<>();
        coins   = new ArrayList<>();
    }

    public void addEnemy(Enemy e)        { enemies.add(e); }
    public void addWall(Wall w)          { walls.add(w); }
    public void addCoin(Coin c)          { coins.add(c); }
    public void setStartZone(Zone z)     { startZone = z; }
    public void setGoalZone(Zone z)      { goalZone  = z; }

    public boolean isComplete(Player p) {
        boolean allCoins = coins.stream().allMatch(Coin::isCollected);
        return allCoins && goalZone != null && goalZone.contains(p);
    }

    public void reset() { coins.forEach(Coin::reset); }

    public int         getNumber()    { return number; }
    public List<Enemy> getEnemies()   { return enemies; }
    public List<Wall>  getWalls()     { return walls; }
    public List<Coin>  getCoins()     { return coins; }
    public Zone        getStartZone() { return startZone; }
    public Zone        getGoalZone()  { return goalZone; }
}