package domain;
import java.awt.*;

public class Zone extends GameElement {
    public enum ZoneType { START, GOAL }
    private ZoneType type;

    public Zone(int x, int y, int width, int height, ZoneType type) {
        super(x, y, width, height);
        this.type = type;
    }

    public boolean contains(Player p) {
        return getBounds().contains(p.getBounds());
    }

    public ZoneType getType() { return type; }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        GradientPaint gp = new GradientPaint(
            x, y,             new Color(120, 220, 120),
            x + width, y + height, new Color(80, 170, 80)
        );
        g2.setPaint(gp);
        g2.fillRect(x, y, width, height);
        g2.setColor(new Color(40, 120, 40));
        g2.setStroke(new BasicStroke(2));
        g2.drawRect(x, y, width, height);
        g2.setColor(new Color(20, 80, 20));
        g2.setFont(new Font("Arial", Font.BOLD, 11));
        String label = (type == ZoneType.START) ? "START" : "GOAL";
        g2.drawString(label, x + width / 2 - 16, y + height / 2);
    }
}