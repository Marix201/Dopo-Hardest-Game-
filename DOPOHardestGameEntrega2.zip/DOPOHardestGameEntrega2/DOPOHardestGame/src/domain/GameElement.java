package domain;
import java.awt.Graphics;
import java.awt.Rectangle;

public abstract class GameElement {
    protected int x, y, width, height;

    public GameElement(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public abstract void draw(Graphics g);

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    public int getX()       { return x; }
    public int getY()       { return y; }
    public int getWidth()   { return width; }
    public int getHeight()  { return height; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
}