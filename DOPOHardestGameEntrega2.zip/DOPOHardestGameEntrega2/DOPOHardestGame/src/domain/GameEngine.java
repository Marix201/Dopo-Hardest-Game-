package domain;

public class GameEngine {
    private Player player;
    private Level  currentLevel;

    public GameEngine(Player player, Level level) {
        this.player       = player;
        this.currentLevel = level;
    }

    public void update() {
        player.move();
        currentLevel.getEnemies().forEach(Enemy::move);
        checkCollisions();
    }

    public void checkCollisions() {
        for (Enemy e : currentLevel.getEnemies()) {
            if (e.collidesWithPlayer(player)) {
                player.die();
                return;
            }
        }
        for (Wall w : currentLevel.getWalls()) {
            if (w.getBounds().intersects(player.getBounds())) {
                player.reset(
                    currentLevel.getStartZone().getX(),
                    currentLevel.getStartZone().getY() +
                    currentLevel.getStartZone().getHeight() / 2
                );
                return;
            }
        }
        for (Coin c : currentLevel.getCoins()) {
            if (!c.isCollected() &&
                c.getBounds().intersects(player.getBounds())) {
                c.collect();
            }
        }
    }

    public Player getPlayer()       { return player; }
    public Level  getCurrentLevel() { return currentLevel; }
}