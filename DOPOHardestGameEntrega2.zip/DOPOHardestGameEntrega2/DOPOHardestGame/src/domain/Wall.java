package domain;
import java.awt.*;

public class Wall extends GameElement {
    public Wall(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(new Color(40, 40, 60));
        g2.fillRect(x, y, width, height);
        g2.setColor(new Color(80, 80, 110));
        g2.setStroke(new BasicStroke(1f));
        g2.drawRect(x, y, width, height);
    }
}