package domain;
import java.awt.*;

public class Player extends GameElement {
    private int dx, dy;
    private boolean alive;
    private int deaths;
    private final int speed = 3;

    public Player(int x, int y) {
        super(x, y, 20, 20);
        this.alive  = true;
        this.deaths = 0;
    }

    public void move() {
        x += dx;
        y += dy;
    }

    public void setDirection(int dx, int dy) {
        this.dx = dx * speed;
        this.dy = dy * speed;
    }

    public void die() {
        deaths++;
        alive = false;
    }

    public void reset(int startX, int startY) {
        x  = startX;
        y  = startY;
        dx = 0;
        dy = 0;
        alive = true;
    }

    public boolean isAlive()  { return alive; }
    public int getDeaths()    { return deaths; }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 5, 5);
        GradientPaint gp = new GradientPaint(
            x, y,             new Color(255, 80, 80),
            x + width, y + height, new Color(180, 20, 20)
        );
        g2.setPaint(gp);
        g2.fillRoundRect(x, y, width, height, 5, 5);
        g2.setColor(new Color(120, 0, 0));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
    }
}