package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HUDPanel extends JPanel {
    private int deaths;
    private int levelNumber;
    private int timeLeft;
    private int coinsCollected;
    private int coinsTotal;
    private final DopoHardestGameGUI gui;
    private Timer gameTimer;

    public HUDPanel(DopoHardestGameGUI gui) {
        this.gui = gui;
        setPreferredSize(new Dimension(620, 32));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getX() >= 8 && e.getX() <= 55 && e.getY() >= 4 && e.getY() <= 28) {
                    if (gameTimer != null) gameTimer.stop();
                    gui.showMenu();
                }
            }
        });
    }

    public void setGameTimer(Timer t) { this.gameTimer = t; }

    // Llamada sin monedas (compatibilidad)
    public void update(int deaths, int levelNumber, int timeLeft) {
        update(deaths, levelNumber, timeLeft, coinsCollected, coinsTotal);
    }

    // Llamada completa con monedas
    public void update(int deaths, int levelNumber, int timeLeft,
                       int coinsCollected, int coinsTotal) {
        this.deaths = deaths;
        this.levelNumber = levelNumber;
        this.timeLeft = timeLeft;
        this.coinsCollected = coinsCollected;
        this.coinsTotal = coinsTotal;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Fondo
        g2.setPaint(new GradientPaint(0, 0, new Color(18, 18, 38),
                                      0, getHeight(), new Color(38, 38, 75)));
        g2.fillRect(0, 0, getWidth(), getHeight());

        g2.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g2.getFontMetrics();
        int midY = getHeight() / 2 + fm.getAscent() / 2 - 1;

        // Menú
        g2.setColor(new Color(100, 180, 255));
        g2.drawString("MENU", 8, midY);

        // Separador
        g2.setColor(new Color(70, 70, 120));
        g2.drawLine(56, 5, 56, 27);

        // Nivel
        String lvl = "NIVEL " + levelNumber + " / 6";
        int lvlX = (getWidth() - fm.stringWidth(lvl)) / 2;
        g2.setColor(Color.WHITE);
        g2.drawString(lvl, lvlX, midY);

        // Monedas
        String coins = coinsCollected + "/" + coinsTotal + " 🪙";
        int coinsX = lvlX - fm.stringWidth(coins) - 18;
        g2.setColor(new Color(255, 215, 50));
        g2.drawString(coins, coinsX, midY);

        // Tiempo
        String tiempo = "T: " + timeLeft + "s";
        int tiempoX = getWidth() - fm.stringWidth("MUERTES: 000") - fm.stringWidth(tiempo) - 18;
        g2.setColor(timeLeft <= 10 ? new Color(255, 60, 60) : new Color(80, 220, 80));
        g2.drawString(tiempo, tiempoX, midY);

        // Muertes
        String muertes = "MUERTES: " + deaths;
        int muertesX = getWidth() - fm.stringWidth(muertes) - 8;
        g2.setColor(new Color(255, 100, 100));
        g2.drawString(muertes, muertesX, midY);
    }
}