package presentation;

import domain.*;
import domain.Zone.ZoneType;
import domain.MachinePlayer.Profile;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class GamePanel extends JPanel implements KeyListener, ActionListener {

    private GameEngine engine;
    private HUDPanel hud;
    private DopoHardestGameGUI gui;
    private Timer timer;
    private boolean[]  keys = new boolean[256];
    private boolean won = false;
    private boolean lost = false;
    private boolean paused = false;
    private boolean wasWon = false;

    private String gameMode;
    private String p1Type;
    private String p2Type;
    private String p1OriginalType;
    private String p2OriginalType;

    private int p1SpawnX, p1SpawnY;
    private int p2SpawnX, p2SpawnY;
    private int p1PrevX, p1PrevY;
    private int p2PrevX, p2PrevY;

    private String p1ActiveSkin = null;
    private String p2ActiveSkin = null;
    private int p1CoinsCount = 0;
    private int p2CoinsCount = 0;
    private String winnerTag = "";  // quién gana en modos 2 jugadores
    
    // LevelData activo leido del .txt null = usando hardcodeado
    private LevelData currentLevelData = null;
    private int totalLevels = 3;
    private int timeLeft;
    private int tickCount = 0;
    private int currentLevel = 1;

    private static final String LEVELS_FOLDER = "levels";

    public static final int W = 620;
    public static final int H = 400;

    // Forma recta
    private static final int N1_BX=10, N1_BY=60, N1_BW=600, N1_BH=280;
    private static final int N1_CX=160, N1_CW=280;
    private static final int N1_ZW=N1_CX-N1_BX;
    private static final int N1_SX=N1_BX, N1_SY=N1_BY;
    private static final int N1_GX=N1_CX+N1_CW, N1_GY=N1_BY;
    private static final int N1_PX=N1_SX+N1_ZW/2-10, N1_PY=N1_SY+N1_BH/2-10;

    // Forma de L
    private static final int N2_SX=10, N2_SY=20, N2_SW=150, N2_SH=260;
    private static final int N2_CX=160, N2_CY=160, N2_CW=300, N2_CH=120;
    private static final int N2_GX=460, N2_GY=160, N2_GW=150, N2_GH=220;
    private static final int N2_PX=N2_SX+N2_SW/2-10, N2_PY=N2_SY+20;

    // Forma de U
    private static final int N3_SX=10,   N3_SY=80,  N3_SW=100, N3_SH=170;
    private static final int N3_IZX=110, N3_IZY=80, N3_IZW=80, N3_IZH=220;
    private static final int N3_BJX=110, N3_BJY=270,N3_BJW=380,N3_BJH=80;
    private static final int N3_DRX=450, N3_DRY=60, N3_DRW=80, N3_DRH=290;
    private static final int N3_GX=500,  N3_GY=60,  N3_GW=110, N3_GH=130;
    private static final int N3_CKX=275, N3_CKY=270,N3_CKW=40, N3_CKH=80;
    private static final int N3_P1X=N3_SX+10,          N3_P1Y=N3_SY+N3_SH/2-10;
    private static final int N3_P2X=N3_GX+N3_GW/2-10,  N3_P2Y=N3_GY+20;

    private static final int ES=2;

    private Rectangle btnPrimary, btnLevels, btnSave, btnExit;

    public GamePanel(HUDPanel hud, DopoHardestGameGUI gui) {
        this.hud=hud; this.gui=gui;
        setPreferredSize(new Dimension(W,H));
        setFocusable(true);
        addKeyListener(this);
        timer=new Timer(33,this);

        List<LevelData> all=LevelManager.loadAllFromFolder(LEVELS_FOLDER);
        if(!all.isEmpty()) totalLevels=all.size();

        addMouseListener(new MouseAdapter(){
            @Override public void mouseClicked(MouseEvent e){
                if(!won&&!lost) return;
                int mx=e.getX(), my=e.getY();
                if(btnSave!=null&&btnSave.contains(mx,my)){doSave();return;}
                if(btnPrimary!=null&&btnPrimary.contains(mx,my)){
                    boolean goNext=wasWon;
                    won=false;lost=false;wasWon=false;
                    int next=goNext?(currentLevel<totalLevels?currentLevel+1:1):currentLevel;
                    startGame(gameMode,p1OriginalType,p2OriginalType,next);
                }else if(btnLevels!=null&&btnLevels.contains(mx,my)){timer.stop();gui.showLevelSelect();}
                else if(btnExit!=null&&btnExit.contains(mx,my)){timer.stop();gui.showMenu();}
            }
        });
    }

    public Timer getTimer(){
    	return timer;
    }
    
    public int getTotalLevels(){
    	return totalLevels;
    }

    public void startGame(String mode,String p1Type,String p2Type,int levelNum){
        this.gameMode=mode; this.p1Type=p1Type; this.p2Type=p2Type;
        this.p1OriginalType=p1Type; this.p2OriginalType=p2Type;
        this.currentLevel=levelNum;
        this.won=false;this.lost=false;this.wasWon=false;this.paused=false;
        this.p1ActiveSkin=null;this.p2ActiveSkin=null;
        this.p1CoinsCount=0;this.p2CoinsCount=0;this.winnerTag="";

        currentLevelData=tryLoadLevelData(levelNum);
        Level level = (currentLevelData != null)
            ? LevelManager.buildLevel(currentLevelData)
            : buildLevelHardcoded(levelNum);

        int[]sp1=getSpawn1(levelNum);
        p1SpawnX=sp1[0];p1SpawnY=sp1[1];p1PrevX=p1SpawnX;p1PrevY=p1SpawnY;
        Player p1=makePlayer(p1Type,p1SpawnX,p1SpawnY);

        if("PLAYER".equals(mode)){engine=new GameEngine(p1,level);}
        else{
            int[]sp2=getSpawn2(levelNum);
            p2SpawnX=sp2[0];p2SpawnY=sp2[1];p2PrevX=p2SpawnX;p2PrevY=p2SpawnY;
            Player p2;
            switch(mode){
                case"PVM_RANDOM":p2=new MachinePlayer(p2SpawnX,p2SpawnY,Profile.ALEATORIA,level);break;
                case"PVM_EXPERT":p2=new MachinePlayer(p2SpawnX,p2SpawnY,Profile.EXPERTA,level);break;
                case"MVM":
                    p1=new MachinePlayer(p1SpawnX,p1SpawnY,Profile.EXPERTA,level,p1Type!=null?p1Type:"RED");
                    p2=new MachinePlayer(p2SpawnX,p2SpawnY,Profile.ALEATORIA,level,p2Type!=null?p2Type:"BLUE");
                    break;
                default:p2=makePlayer(p2Type!=null?p2Type:"BLUE",p2SpawnX,p2SpawnY);
            }
            engine=new GameEngine(p1,p2,level);
        }
        timeLeft=level.getTimeLimit();tickCount=0;
        
        // Asignar etiquetas y colores de borde para distinguir jugadores
        engine.getPlayer().setPlayerTag("J1");
        engine.getPlayer().setBorderColor(new Color(255, 220, 50));  // borde amarillo J1
        if (engine.getPlayer2() != null) {
            boolean isAI = "MVM".equals(mode)
                        || "PVM_RANDOM".equals(mode)
                        || "PVM_EXPERT".equals(mode);
            engine.getPlayer2().setPlayerTag(isAI ? "IA" : "J2");
            engine.getPlayer2().setBorderColor(new Color(80, 220, 255)); // borde cian J2/IA
        }
        
        // En MVM ambos son IA — J1=morado, J2=cian
        if ("MVM".equals(mode)) {
            engine.getPlayer().setPlayerTag("IA1");
            engine.getPlayer().setBorderColor(new Color(220, 80, 255)); // borde morado IA1
        }
        if(!timer.isRunning())timer.start();
    }

    public void startGame(int n){startGame("PLAYER","RED",null,n);}

    private LevelData tryLoadLevelData(int n){
        String path=LEVELS_FOLDER+File.separator+"level"+n+".txt";
        try{
            LevelData ld=LevelManager.loadFromTxt(path);
            System.out.println("Nivel "+n+" cargado desde: "+path);
            return ld;
        }catch(IOException ex){
            System.out.println("Nivel "+n+" usando hardcodeado (no encontro "+path+")");
            return null;
        }
    }

    private int[]getSpawn1(int n){
    	return currentLevelData!=null?currentLevelData.spawn1:spawnH(n,1);
    }
    
    private int[]getSpawn2(int n){
    	return currentLevelData!=null?currentLevelData.spawn2:spawnH(n,2);
    }

    private String getLevelLayout() {
        if (currentLevelData != null) return currentLevelData.layoutType;
        if (currentLevel == 2 || currentLevel == 5) return "L_SHAPE";
        if (currentLevel == 3 || currentLevel == 6) return "U_SHAPE";
        return "STRAIGHT";
    }
    
    @Override public void actionPerformed(ActionEvent e){
        if(won||lost||paused)return;
        tickCount++;
        if(tickCount>=30){
            tickCount=0;timeLeft--;
            if(timeLeft<=0){
                timeLeft=0;lost=true;wasWon=false;timer.stop();
                Level lvl=engine.getCurrentLevel();
                hud.update(engine.getPlayer().getDeaths(),lvl.getNumber(),0,
                           countNormalCoins(),countTotalNormalCoins());
                repaint();return;
            }
        }
        Player p1=engine.getPlayer();
        p1PrevX=p1.getX();p1PrevY=p1.getY();
        Player p2=engine.getPlayer2();
        if(p2!=null){p2PrevX=p2.getX();p2PrevY=p2.getY();}

        p1.computeAIMove(); // no op si es humano, actúa si es IA
        // FIX: p2 también necesita computeAIMove en modo MVM
        if(p2!=null&&("MVM".equals(gameMode)||"PVM_RANDOM".equals(gameMode)||"PVM_EXPERT".equals(gameMode))){
            p2.computeAIMove();
        }
        int dx1=0,dy1=0;
        if(keys[KeyEvent.VK_LEFT]||keys[KeyEvent.VK_A])dx1=-1;
        if(keys[KeyEvent.VK_RIGHT]||keys[KeyEvent.VK_D])dx1=1;
        if(keys[KeyEvent.VK_UP]||keys[KeyEvent.VK_W])dy1=-1;
        if(keys[KeyEvent.VK_DOWN]||keys[KeyEvent.VK_S])dy1=1;
        if(dx1!=0||dy1!=0) p1.setDirection(dx1,dy1);

        if(p2!=null&&"PVP".equals(gameMode)){
            int dx2=0,dy2=0;
            if(keys[KeyEvent.VK_J])dx2=-1;if(keys[KeyEvent.VK_L])dx2=1;
            if(keys[KeyEvent.VK_I])dy2=-1;if(keys[KeyEvent.VK_K])dy2=1;
            p2.setDirection(dx2,dy2);
        }

        engine.update();
        applyBounds();
        checkSkinCoins();
        checkCheckpoint();

        // Bombas
        for(Bomb b : engine.getCurrentLevel().getBombs()){
            b.checkCollision(engine);
        }

        // Elimina enemigos destruidos
        engine.getCurrentLevel().getEnemies().removeIf(en -> !en.isAlive());

        handleDeaths();

        Level lvl=engine.getCurrentLevel();
        p1=engine.getPlayer();p2=engine.getPlayer2();
        if(p2==null){
            // Modo PLAYER: condición normal
        	boolean isPvP="PVP".equals(gameMode)||"MVM".equals(gameMode)
                    ||"PVM_RANDOM".equals(gameMode)||"PVM_EXPERT".equals(gameMode);
        int total=countTotalNormalCoins();
        int needed=(total/2)+1;

        if(!isPvP){
            // Modo 1 jugador: recoger todas y llegar al GOAL
            boolean allCoins=(p1CoinsCount==total);
            boolean inGoal=lvl.getGoalZone()!=null&&lvl.getGoalZone().contains(p1);
            if(allCoins&&inGoal){won=true;wasWon=true;winnerTag="J1";timer.stop();}
        } else {
            // J1 gana: mayoría de monedas Y llega al GOAL
            boolean p1Wins=(p1CoinsCount>=needed)&&lvl.getGoalZone()!=null&&lvl.getGoalZone().contains(p1);
            
            // J2 gana: mayoría de monedas Y llega al START
            boolean p2Wins=p2!=null&&(p2CoinsCount>=needed)&&lvl.getStartZone()!=null&&lvl.getStartZone().contains(p2);
            if(p1Wins){
                won=true;wasWon=true;
                winnerTag=p1.getPlayerTag()!=null?p1.getPlayerTag():"J1";
                timer.stop();
            } else if(p2Wins){
                won=true;wasWon=true;
                winnerTag=p2.getPlayerTag()!=null?p2.getPlayerTag():"J2";
                timer.stop();
            }
        }
        } else {
            boolean isPvP = "PVP".equals(gameMode)||"MVM".equals(gameMode)
                         ||"PVM_RANDOM".equals(gameMode)||"PVM_EXPERT".equals(gameMode);
            if(isPvP){
                int total=countTotalNormalCoins();
                int needed=(total/2)+1; // mayoría simple
                // J1 gana: tiene mayoría de monedas Y llega al GOAL
                if(p1CoinsCount>=needed && lvl.getGoalZone()!=null && lvl.getGoalZone().contains(p1)){
                    won=true;wasWon=true;winnerTag=p1.getPlayerTag()!=null?p1.getPlayerTag():"J1";timer.stop();
                }
                // J2 gana: tiene mayoría de monedas Y llega al START
                else if(p2CoinsCount>=needed && lvl.getStartZone()!=null && lvl.getStartZone().contains(p2)){
                    won=true;wasWon=true;winnerTag=p2.getPlayerTag()!=null?p2.getPlayerTag():"J2";timer.stop();
                }
                // Si alguien recoge TODAS las monedas, gana al llegar a su zona
                else if(p1CoinsCount==total && lvl.getGoalZone()!=null && lvl.getGoalZone().contains(p1)){
                    won=true;wasWon=true;winnerTag=p1.getPlayerTag()!=null?p1.getPlayerTag():"J1";timer.stop();
                }
                else if(p2CoinsCount==total && lvl.getStartZone()!=null && lvl.getStartZone().contains(p2)){
                    won=true;wasWon=true;winnerTag=p2.getPlayerTag()!=null?p2.getPlayerTag():"J2";timer.stop();
                }
            } else {
                if(lvl.isComplete(p1)||(lvl.isComplete(p2))){won=true;wasWon=true;timer.stop();}
            }
        }

        hud.update(p1.getDeaths(),lvl.getNumber(),timeLeft,countNormalCoins(),countTotalNormalCoins());
        repaint();
    }

    private void checkSkinCoins(){
        Player p1=engine.getPlayer(), p2=engine.getPlayer2();
        for(Coin c:engine.getCurrentLevel().getCoins()){
            if(c.isCollected()) continue;
            if(c.isSkinCoin()){
                SkinCoin sc=(SkinCoin)c;
                if(c.getBounds().intersects(p1.getBounds())){
                    c.collect(); transformPlayer(1,sc.getSkinType(),p1);
                } else if(p2!=null&&c.getBounds().intersects(p2.getBounds())){
                    c.collect(); transformPlayer(2,sc.getSkinType(),p2);
                }
            } else {
                if(c.getBounds().intersects(p1.getBounds())){
                    c.collect(); p1CoinsCount++;
                } else if(p2!=null&&c.getBounds().intersects(p2.getBounds())){
                    c.collect(); p2CoinsCount++;
                }
            }
        }
    }

    private void transformPlayer(int num,String skinType,Player old){
        Player nuevo=old.createTransformed(skinType,old.getX(),old.getY(),engine.getCurrentLevel());
        nuevo.setBorderColor(old.getBorderColor());
        nuevo.setPlayerTag(old.getPlayerTag());
        int d=old.getDeaths();for(int i=0;i<d;i++)nuevo.die();
        nuevo.reset(old.getX(),old.getY());
        if(num==1){p1ActiveSkin=skinType;engine.setPlayer1(nuevo);}
        else{p2ActiveSkin=skinType;engine.setPlayer2(nuevo);}
    }

    private void checkCheckpoint(){
        Zone ck=engine.getCurrentLevel().getIntermediateZone();if(ck==null)return;
        int ckX=ck.getX()+ck.getWidth()/2-10,ckY=ck.getY()+ck.getHeight()/2-10;
        Player p1=engine.getPlayer();
        if(ck.intersects(p1)){p1SpawnX=ckX;p1SpawnY=ckY;}
        Player p2=engine.getPlayer2();
        if(p2!=null&&ck.intersects(p2)){p2SpawnX=ckX;p2SpawnY=ckY;}
    }

    private void handleDeaths(){
        Player p1=engine.getPlayer();
        if(!p1.isAlive()){
            engine.getCurrentLevel().reset();
            Player r=makePlayerForMode(1,p1OriginalType,p1SpawnX,p1SpawnY);
            r.setBorderColor(p1.getBorderColor());
            r.setPlayerTag(p1.getPlayerTag());
            int d=p1.getDeaths();for(int i=0;i<d;i++)r.die();
            r.reset(p1SpawnX,p1SpawnY);engine.setPlayer1(r);
            p1PrevX=p1SpawnX;p1PrevY=p1SpawnY;p1ActiveSkin=null;
        }
        Player p2=engine.getPlayer2();
        if(p2!=null&&!p2.isAlive()){
            String orig=p2OriginalType!=null?p2OriginalType:"BLUE";
            Player r=makePlayerForMode(2,orig,p2SpawnX,p2SpawnY);
            r.setBorderColor(p2.getBorderColor());
            r.setPlayerTag(p2.getPlayerTag());
            int d=p2.getDeaths();for(int i=0;i<d;i++)r.die();
            r.reset(p2SpawnX,p2SpawnY);engine.setPlayer2(r);
            p2PrevX=p2SpawnX;p2PrevY=p2SpawnY;p2ActiveSkin=null;
        }
    }

    /**
     * Crea el jugador correcto según el modo
     */
    private Player makePlayerForMode(int playerNum, String skinType, int x, int y){
        Level lvl = engine.getCurrentLevel();
        if("MVM".equals(gameMode)){
            MachinePlayer.Profile prof = (playerNum==1) ? MachinePlayer.Profile.EXPERTA
                                                        : MachinePlayer.Profile.ALEATORIA;
            return new MachinePlayer(x,y,prof,lvl,skinType!=null?skinType:"RED");
        }
        if(playerNum==2&&"PVM_RANDOM".equals(gameMode))
            return new MachinePlayer(x,y,MachinePlayer.Profile.ALEATORIA,lvl,skinType!=null?skinType:"RED");
        if(playerNum==2&&"PVM_EXPERT".equals(gameMode))
            return new MachinePlayer(x,y,MachinePlayer.Profile.EXPERTA,lvl,skinType!=null?skinType:"RED");
        return makePlayer(skinType!=null?skinType:"RED",x,y);
    }

    private void applyBounds(){
        Player p1=engine.getPlayer(),p2=engine.getPlayer2();
        switch(getLevelLayout()){
            case"L_SHAPE":
                boundsL2(p1);if(p2!=null)boundsL2(p2);
                int lCX=N2_CX,lCY=N2_CY,lCW=N2_CW,lCH=N2_CH;
                if(currentLevelData!=null){
                    lCX=currentLevelData.startZone[0]+currentLevelData.startZone[2];
                    lCY=currentLevelData.goalZone[1];
                    lCW=currentLevelData.goalZone[0]-lCX;
                    lCH=currentLevelData.goalZone[3];
                }
                bounceBox(lCX,lCY,lCW,lCH);
                break;
            case"U_SHAPE":
                boundsL3(p1,p1PrevX,p1PrevY);if(p2!=null)boundsL3(p2,p2PrevX,p2PrevY);
                bounceU();
                break;
            default:
                clamp(p1,N1_BX,N1_BY,N1_BW,N1_BH);if(p2!=null)clamp(p2,N1_BX,N1_BY,N1_BW,N1_BH);
                bounceBox(N1_CX,N1_BY,N1_CW,N1_BH);
        }
    }

    private void boundsL2(Player p){
        int px=p.getX(),py=p.getY(),pw=p.getWidth(),ph=p.getHeight(),cx=px+pw/2;
        if(px<N2_SX){p.setX(N2_SX);px=N2_SX;cx=px+pw/2;}
        if(px>N2_GX+N2_GW-pw){p.setX(N2_GX+N2_GW-pw);px=N2_GX+N2_GW-pw;cx=px+pw/2;}
        if(py<N2_SY){p.setY(N2_SY);py=N2_SY;}if(py>N2_GY+N2_GH-ph){p.setY(N2_GY+N2_GH-ph);py=N2_GY+N2_GH-ph;}
        boolean enS=cx<=N2_CX,enG=cx>=N2_GX,enC=!enS&&!enG;
        if(enS){if(py<N2_SY)p.setY(N2_SY);if(py+ph>N2_SY+N2_SH)p.setY(N2_SY+N2_SH-ph);if(px+pw>N2_CX&&(py<N2_CY||py+ph>N2_CY+N2_CH))p.setX(N2_CX-pw);}
        if(enC){if(py<N2_CY)p.setY(N2_CY);if(py+ph>N2_CY+N2_CH)p.setY(N2_CY+N2_CH-ph);}
        if(enG){if(py<N2_GY)p.setY(N2_GY);if(py+ph>N2_GY+N2_GH)p.setY(N2_GY+N2_GH-ph);if(px<N2_GX&&(py<N2_CY||py+ph>N2_CY+N2_CH))p.setX(N2_GX);}
    }

    private void boundsL3(Player p, int prevX, int prevY) {
        int pw = p.getWidth();
        int ph = p.getHeight();
        int px = p.getX();
        int py = p.getY();
        
        // Todas las esquinas deben estar en zona válida
        boolean valid =
            zonaL3(px, py) != null &&
            zonaL3(px+pw-1, py) != null &&
            zonaL3(px, py+ph-1) != null &&
            zonaL3(px+pw-1, py+ph-1) != null;
        if (!valid) {
            p.setX(prevX);
            p.setY(prevY);
        }
    }

    private String zonaL3(int px, int py) {
        if (px >= N3_SX  && px < N3_SX+N3_SW   && py >= N3_SY  && py < N3_SY+N3_SH)  return "START";
        if (px >= N3_IZX && px < N3_IZX+N3_IZW && py >= N3_IZY && py < N3_IZY+N3_IZH) return "IZ";
        if (px >= N3_BJX && px < N3_BJX+N3_BJW && py >= N3_BJY && py < N3_BJY+N3_BJH) return "BJ";
        if (px >= N3_DRX && px < N3_DRX+N3_DRW && py >= N3_DRY && py < N3_DRY+N3_DRH) return "DR";
        if (px >= N3_GX  && px < N3_GX+N3_GW   && py >= N3_GY  && py < N3_GY+N3_GH)  return "GOAL";
        return null;
    }

    private boolean inR(int rx,int ry,int rw,int rh,int px,int py){return px>=rx&&px<=rx+rw&&py>=ry&&py<=ry+rh;}

    private void clampZ(Player p, String z) {
        switch (z) {
            case "START": clamp(p, N3_SX,  N3_SY,  N3_SW,  N3_SH);  break;
            case "IZ": clamp(p, N3_IZX, N3_IZY, N3_IZW, N3_IZH); break;
            case "BJ": clamp(p, N3_BJX, N3_BJY, N3_BJW, N3_BJH); break;
            case "DR": clamp(p, N3_DRX, N3_DRY, N3_DRW, N3_DRH); break;
            case "GOAL": clamp(p, N3_GX,  N3_GY,  N3_GW,  N3_GH);  break;
        }
    }

    private void bounceBox(int bx,int by,int bw,int bh){
        for(Enemy en:engine.getCurrentLevel().getEnemies()){
            if(en.getX()<=bx)en.reverseX();if(en.getX()+en.getWidth()>=bx+bw)en.reverseX();
            if(en.getY()<=by)en.reverseY();if(en.getY()+en.getHeight()>=by+bh)en.reverseY();
        }
    }

    private void bounceU(){
        for(Enemy en : engine.getCurrentLevel().getEnemies()){
            int ex=en.getX(),ey=en.getY(),ew=en.getWidth(),eh=en.getHeight();
            int cx=ex+ew/2, cy=ey+eh/2;
            String zona=zonaL3(cx,cy);
            if(zona==null) zona=zonaL3(cx,ey); // fallback con borde superior
            if("BJ".equals(zona)){
                if(ex<=N3_BJX)en.reverseX();
                if(ex+ew>=N3_BJX+N3_BJW)en.reverseX();
                if(ey<=N3_BJY)en.reverseY();
                if(ey+eh>=N3_BJY+N3_BJH)en.reverseY();
            } else if("IZ".equals(zona)){
                if(ey<=N3_IZY)en.reverseY();
                if(ey+eh>=N3_IZY+N3_IZH)en.reverseY();
                if(ex<=N3_IZX)en.reverseX();
                if(ex+ew>=N3_IZX+N3_IZW)en.reverseX();
            } else {
                // DR o cualquier otra zona
                if(ey<=N3_DRY)en.reverseY();
                if(ey+eh>=N3_DRY+N3_DRH)en.reverseY();
                if(ex<=N3_DRX)en.reverseX();
                if(ex+ew>=N3_DRX+N3_DRW)en.reverseX();
            }
        }
    }

    private void clamp(Player p,int x,int y,int w,int h){
        if(p.getX()<x)p.setX(x);if(p.getX()>x+w-p.getWidth())p.setX(x+w-p.getWidth());
        if(p.getY()<y)p.setY(y);if(p.getY()>y+h-p.getHeight())p.setY(y+h-p.getHeight());
    }


    private int[]spawnH(int n,int p){
        if(n==2)return p==2?new int[]{N2_GX+10,N2_GY+20}:new int[]{N2_PX,N2_PY};
        if(n==3)return p==2?new int[]{N3_P2X,N3_P2Y}:new int[]{N3_P1X,N3_P1Y};
        return p==2?new int[]{N1_GX+N1_ZW/2-10,N1_GY+N1_BH/2-10}:new int[]{N1_PX,N1_PY};
    }

    @Override protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2=(Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);

        // Fondo del nivel
        switch(getLevelLayout()){
            case"L_SHAPE": dL2(g2); break;
            case"U_SHAPE": dL3(g2); break;
            default:       dL1(g2);
        }

        Level lvl = engine.getCurrentLevel();

        // Zona intermedia (checkpoint)
        Zone ck = lvl.getIntermediateZone();
        if(ck != null) ck.draw(g2);

        // Bombas
        lvl.getBombs().forEach(b -> { b.tick(); b.draw(g2); });

        // Fuentes de vida
        lvl.getLifeSources().forEach(ls -> { ls.tick(); ls.draw(g2); });

        // Monedas
        lvl.getCoins().forEach(c -> c.draw(g2));

        // Enemigos
        lvl.getEnemies().forEach(en -> en.draw(g2));

        // Jugadores
        engine.getPlayer().draw(g2);
        if(engine.getPlayer2() != null) engine.getPlayer2().draw(g2);

        // Indicadores HUD en el panel de juego
        drawSkin(g2);
        drawMode(g2);
        drawLvlName(g2);

        // Overlays
        if(paused) drawPause(g2);
        if(won) drawWin(g2);
        if(lost) drawLose(g2);
    }

    private void dL1(Graphics2D g){
        g.setColor(new Color(100,120,200));g.fillRect(0,0,W,H);
        g.setColor(new Color(120,210,120));g.fillRect(N1_SX,N1_SY,N1_ZW,N1_BH);
        chk(g,N1_CX,N1_BY,N1_CW,N1_BH);
        g.setColor(new Color(255,220,80));g.fillRect(N1_GX,N1_GY,N1_ZW,N1_BH);
        brd(g);zl(g,"START",N1_SX,N1_SY,N1_ZW,N1_BH);zl(g,"GOAL",N1_GX,N1_GY,N1_ZW,N1_BH);
    }

    private void dL2(Graphics2D g){
        g.setColor(new Color(100,120,200));g.fillRect(0,0,W,H);
        g.setColor(new Color(120,210,120));g.fillRect(N2_SX,N2_SY,N2_SW,N2_SH);
        chk(g,N2_CX,N2_CY,N2_CW,N2_CH);
        g.setColor(new Color(255,220,80));g.fillRect(N2_GX,N2_GY,N2_GW,N2_GH);
        brd(g);zl(g,"START",N2_SX,N2_SY,N2_SW,N2_SH);zl(g,"GOAL",N2_GX,N2_GY,N2_GW,N2_GH);
    }

    private void dL3(Graphics2D g){
        // Fondo
        g.setColor(new Color(25,25,55));
        g.fillRect(0,0,W,H);

        // START (verde)
        g.setColor(new Color(100,190,100));
        g.fillRect(N3_SX,N3_SY,N3_SW,N3_SH);

        // GOAL (amarillo)
        g.setColor(new Color(240,200,60));
        g.fillRect(N3_GX,N3_GY,N3_GW,N3_GH);

        // Corredores con ajedrez (sin bordes todavía)
        chk(g,N3_IZX,N3_IZY,N3_IZW,N3_IZH);
        chk(g,N3_BJX,N3_BJY,N3_BJW,N3_BJH);
        chk(g,N3_DRX,N3_DRY,N3_DRW,N3_DRH);

        // ── Bordes exteriores de la forma U                          
        g.setColor(new Color(60,60,140));
        g.setStroke(new BasicStroke(3));

        // Corredor IZ: techo, pared izquierda, pared derecha 
        g.drawLine(N3_IZX, N3_IZY, N3_IZX+N3_IZW, N3_IZY);              
        g.drawLine(N3_IZX, N3_IZY, N3_IZX, N3_IZY+N3_IZH);              
        g.drawLine(N3_IZX+N3_IZW, N3_IZY, N3_IZX+N3_IZW, N3_BJY);       

        // Corredor BJ: techo izquierdo (
        // suelo completo, pared izquierda abajo, pared derecha 
        g.drawLine(N3_IZX, N3_BJY+N3_BJH, N3_BJX+N3_BJW, N3_BJY+N3_BJH); 
        g.drawLine(N3_BJX, N3_IZY+N3_IZH, N3_BJX, N3_BJY+N3_BJH);         
        g.drawLine(N3_IZX+N3_IZW, N3_BJY, N3_BJX+N3_BJW, N3_BJY);         
        g.drawLine(N3_BJX+N3_BJW, N3_BJY, N3_BJX+N3_BJW, N3_DRY+N3_DRH); 

        // Corredor DR: techo, pared izquierda 
        g.drawLine(N3_DRX, N3_DRY, N3_DRX+N3_DRW, N3_DRY);               
        g.drawLine(N3_DRX, N3_DRY, N3_DRX, N3_BJY);                      

        // Marco exterior del panel
        brd(g);

        // Flechas guía
        g.setColor(new Color(255,255,255,120));
        g.setFont(new Font("Arial",Font.BOLD,18));
        g.drawString("↓",N3_IZX+N3_IZW/2-6,N3_IZY+N3_IZH/2+6);
        g.drawString("→",N3_BJX+N3_BJW/2-6,N3_BJY+N3_BJH/2+6);
        g.drawString("↑",N3_DRX+N3_DRW/2-6,N3_DRY+N3_DRH/2+6);

        zl(g,"START",N3_SX,N3_SY,N3_SW,N3_SH);
        zl(g,"GOAL",N3_GX,N3_GY,N3_GW,N3_GH);
    }
    private void chk(Graphics2D g,int x,int y,int w,int h){
        int ts=20;for(int r=0;r*ts<h;r++)for(int c=0;c*ts<w;c++){
            g.setColor((r+c)%2==0?new Color(225,225,245):new Color(205,205,230));
            int rx=x+c*ts,ry=y+r*ts,rw=Math.min(ts,x+w-rx),rh2=Math.min(ts,y+h-ry);
            if(rw>0&&rh2>0)g.fillRect(rx,ry,rw,rh2);}
    }
    private void brd(Graphics2D g){
    	g.setColor(new Color(20,20,40));g.setStroke(new BasicStroke(4));g.drawRect(2,2,W-4,H-4);
    }
    
    private void zl(Graphics2D g,String t,int x,int y,int w,int h){
    	g.setColor(new Color(20,70,20));g.setFont(new Font("Arial",Font.BOLD,12));FontMetrics fm=g.getFontMetrics();g.drawString(t,x+(w-fm.stringWidth(t))/2,y+h/2+4);
    }
    
    private void drawLvlName(Graphics2D g){
    	if(currentLevelData==null)return;g.setFont(new Font("Arial",Font.PLAIN,10));g.setColor(new Color(200,200,200,160));g.drawString(currentLevelData.name,8,H-6);
    }
    
    private void drawSkin(Graphics2D g){
    	if(p1ActiveSkin==null&&p2ActiveSkin==null)return;g.setFont(new Font("Arial",Font.BOLD,11));if(p1ActiveSkin!=null){g.setColor(sc(p1ActiveSkin));g.drawString("J1: "+p1ActiveSkin,10,14);}if(p2ActiveSkin!=null){g.setColor(sc(p2ActiveSkin));g.drawString("J2: "+p2ActiveSkin,120,14);}
    }
    
    private void drawMode(Graphics2D g){
    	if("PVM_RANDOM".equals(gameMode)||"PVM_EXPERT".equals(gameMode)){g.setFont(new Font("Arial",Font.BOLD,10));g.setColor(new Color(255,180,60));g.drawString("PVM_RANDOM".equals(gameMode)?"IA: ALEATORIA":"IA: EXPERTA",W-100,14);}
    }
    
    private Color sc(String s){
    	switch(s){case"BLUE":return new Color(80,160,255);case"GREEN":return new Color(60,200,80);default:return new Color(255,80,80);}
    }

    private void drawPause(Graphics2D g){
    	g.setColor(new Color(0,0,0,150));g.fillRect(0,0,W,H);g.setColor(Color.WHITE);g.setFont(new Font("Arial",Font.BOLD,38));ctr(g,"PAUSADO",W/2,H/2-10);g.setFont(new Font("Arial",Font.PLAIN,14));ctr(g,"Presiona P para continuar",W/2,H/2+28);
    }

    private void setOBtns(int bx,int by,int bw){
    	int bW=95,bH=36,gap=8,tot=4*bW+3*gap,sx=bx+(bw-tot)/2,y=by+195;btnPrimary=new Rectangle(sx,y,bW,bH);btnLevels=new Rectangle(sx+bW+gap,y,bW,bH);btnSave=new Rectangle(sx+2*(bW+gap),y,bW,bH);btnExit=new Rectangle(sx+3*(bW+gap),y,bW,bH);
    }

    private void drawWin(Graphics2D g){
        g.setColor(new Color(0,0,0,160));g.fillRect(0,0,W,H);
        int bw=430,bh=300,bx=(W-bw)/2,by=(H-bh)/2;
        g.setPaint(new GradientPaint(bx,by,new Color(20,70,20),bx+bw,by+bh,new Color(5,35,5)));
        g.fillRoundRect(bx,by,bw,bh,20,20);
        g.setColor(new Color(80,220,80));g.setStroke(new BasicStroke(3));
        g.drawRoundRect(bx,by,bw,bh,20,20);

        boolean isPvP = "PVP".equals(gameMode)||"MVM".equals(gameMode)
                     ||"PVM_RANDOM".equals(gameMode)||"PVM_EXPERT".equals(gameMode);

        if(isPvP){
            g.setColor(new Color(255,220,80));
            g.setFont(new Font("Arial",Font.BOLD,28));
            ctr(g,"¡GANÓ "+winnerTag+"!",bx+bw/2,by+52);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial",Font.PLAIN,13));
            ctr(g,"Monedas J1: "+p1CoinsCount+" | Monedas J2: "+p2CoinsCount
               +" (total: "+countTotalNormalCoins()+")",bx+bw/2,by+82);
            ctr(g,"Muertes J1: "+engine.getPlayer().getDeaths()
               +"  |  Muertes J2: "+(engine.getPlayer2()!=null?engine.getPlayer2().getDeaths():0),
               bx+bw/2,by+104);
            ctr(g,"Tiempo restante: "+timeLeft+"s",bx+bw/2,by+126);
        } else {
            g.setColor(new Color(120,255,120));
            g.setFont(new Font("Arial",Font.BOLD,34));
            ctr(g,"¡GANASTE!",bx+bw/2,by+55);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial",Font.PLAIN,14));
            ctr(g,"Muertes: "+engine.getPlayer().getDeaths(),bx+bw/2,by+90);
            ctr(g,"Monedas: "+countNormalCoins()+" / "+countTotalNormalCoins(),bx+bw/2,by+112);
            ctr(g,"Tiempo restante: "+timeLeft+"s",bx+bw/2,by+134);
        }
        setOBtns(bx,by,bw);
        String lbl=currentLevel<totalLevels?"SIGUIENTE":"REINICIAR";
        ob(g,btnPrimary,new Color(40,130,40),lbl);
        ob(g,btnLevels,new Color(40,40,160),"NIVELES");
        ob(g,btnSave,new Color(110,75,0),"GUARDAR");
        ob(g,btnExit,new Color(160,30,30),"SALIR");
    }

    private void drawLose(Graphics2D g){
        g.setColor(new Color(0,0,0,160));g.fillRect(0,0,W,H);
        int bw=430,bh=280,bx=(W-bw)/2,by=(H-bh)/2;
        g.setPaint(new GradientPaint(bx,by,new Color(110,20,20),bx+bw,by+bh,new Color(55,8,8)));g.fillRoundRect(bx,by,bw,bh,20,20);
        g.setColor(new Color(220,60,60));g.setStroke(new BasicStroke(3));g.drawRoundRect(bx,by,bw,bh,20,20);
        g.setColor(new Color(255,100,100));g.setFont(new Font("Arial",Font.BOLD,30));ctr(g,"¡TIEMPO AGOTADO!",bx+bw/2,by+55);
        g.setColor(Color.WHITE);g.setFont(new Font("Arial",Font.PLAIN,14));
        ctr(g,"Muertes: "+engine.getPlayer().getDeaths(),bx+bw/2,by+90);
        boolean isPvPL="PVP".equals(gameMode)||"MVM".equals(gameMode)||
                "PVM_RANDOM".equals(gameMode)||"PVM_EXPERT".equals(gameMode);
		 if(isPvPL){
		     ctr(g,"Monedas J1: "+p1CoinsCount+" | Monedas J2: "+p2CoinsCount
		        +" (total: "+countTotalNormalCoins()+")",bx+bw/2,by+112);
		 } else {
		     ctr(g,"Monedas recogidas: "+countNormalCoins()+" / "+countTotalNormalCoins(),bx+bw/2,by+112);
		 }
        setOBtns(bx,by,bw);
        ob(g,btnPrimary,new Color(40,130,40),"REINTENTAR");ob(g,btnLevels,new Color(40,40,160),"NIVELES");ob(g,btnSave,new Color(110,75,0),"GUARDAR");ob(g,btnExit,new Color(160,30,30),"SALIR");
    }

    private void ctr(Graphics2D g,String t,int cx,int y){
    	FontMetrics fm=g.getFontMetrics();g.drawString(t,cx-fm.stringWidth(t)/2,y);
    }
    
    private void ob(Graphics2D g,Rectangle r,Color c,String l){
    	g.setColor(c);g.fillRoundRect(r.x,r.y,r.width,r.height,10,10);g.setColor(Color.WHITE);g.setStroke(new BasicStroke(1));g.drawRoundRect(r.x,r.y,r.width,r.height,10,10);g.setFont(new Font("Arial",Font.BOLD,10));FontMetrics fm=g.getFontMetrics();g.drawString(l,r.x+(r.width-fm.stringWidth(l))/2,r.y+(r.height+fm.getAscent())/2-2);
    }

    private Player makePlayer(String t,int x,int y){
    	switch(t){case"BLUE":return new BluePlayer(x,y);case"GREEN":return new GreenPlayer(x,y);default:return new RedPlayer(x,y);}
    }
    
    private int countNormalCoins(){
    	return(int)engine.getCurrentLevel().getCoins().stream().filter(c->!c.isSkinCoin()&&c.isCollected()).count();
    }
    
    private int countTotalNormalCoins(){
    	return(int)engine.getCurrentLevel().getCoins().stream().filter(c->!c.isSkinCoin()).count();
    }

    public void doSave(){
        JFileChooser fc=new JFileChooser();fc.setDialogTitle("Guardar partida");
        if(fc.showSaveDialog(this)==JFileChooser.APPROVE_OPTION){
            String path=fc.getSelectedFile().getAbsolutePath();if(!path.endsWith(".txt"))path+=".txt";
            try{GameSave.save(path,currentLevel,p1OriginalType,engine.getPlayer(),gameMode.startsWith("PV")?p2OriginalType:null,engine.getPlayer2(),timeLeft,engine.getCurrentLevel().getCoins());JOptionPane.showMessageDialog(this,"¡Partida guardada!");}
            catch(IOException ex){JOptionPane.showMessageDialog(this,"Error al guardar: "+ex.getMessage());}
        }
    }

    public void doLoad(){
        JFileChooser fc=new JFileChooser();fc.setDialogTitle("Cargar partida");
        if(fc.showOpenDialog(this)==JFileChooser.APPROVE_OPTION){
            try{GameSave.SaveData sd=GameSave.load(fc.getSelectedFile().getAbsolutePath());String mode="NONE".equals(sd.player2Type)?"PLAYER":"PVP";startGame(mode,sd.player1Type,"NONE".equals(sd.player2Type)?null:sd.player2Type,sd.levelNumber);engine.getPlayer().reset(sd.player1X,sd.player1Y);timeLeft=sd.timeLeft;List<Coin>coins=engine.getCurrentLevel().getCoins();for(int i=0;i<sd.coinsState.length&&i<coins.size();i++)if("1".equals(sd.coinsState[i]))coins.get(i).collect();JOptionPane.showMessageDialog(this,"¡Partida cargada!");}
            catch(IOException ex){JOptionPane.showMessageDialog(this,"Error al cargar: "+ex.getMessage());}
        }
    }

    public void doSaveLevelConfig(){
        if(currentLevelData==null){JOptionPane.showMessageDialog(this,"Este nivel no tiene configuracion .txt cargada.");return;}
        JFileChooser fc=new JFileChooser();fc.setDialogTitle("Guardar configuracion de nivel (.txt)");
        if(fc.showSaveDialog(this)==JFileChooser.APPROVE_OPTION){
            String path=fc.getSelectedFile().getAbsolutePath();if(!path.endsWith(".txt"))path+=".txt";
            try{LevelManager.saveToTxt(currentLevelData,path);JOptionPane.showMessageDialog(this,"¡Configuracion guardada!");}
            catch(IOException ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}
        }
    }

    private Level buildLevelHardcoded(int n){
        if(n==2){
            Level l=new Level(2,60);
            l.setStartZone(new Zone(N2_SX,N2_SY,N2_SW,N2_SH,ZoneType.START));
            l.setGoalZone(new Zone(N2_GX,N2_GY,N2_GW,N2_GH,ZoneType.GOAL));
            int s=ES+1,f1=N2_CY+10,f2=N2_CY+N2_CH/2-10,f3=N2_CY+N2_CH-30;
            l.addEnemy(new Enemy(N2_CX+10,f1,new LinearMovementStrategy(s,0)));
            l.addEnemy(new Enemy(N2_CX+N2_CW/2,f1,new LinearMovementStrategy(s,0)));
            l.addEnemy(new Enemy(N2_CX+N2_CW/4,f2,new LinearMovementStrategy(-s,0)));
            l.addEnemy(new Enemy(N2_CX+N2_CW-30,f2,new LinearMovementStrategy(-s,0)));
            l.addEnemy(new Enemy(N2_CX+10,f3,new LinearMovementStrategy(s,0)));
            l.addEnemy(new Enemy(N2_CX+N2_CW/2,f3,new LinearMovementStrategy(s,0)));
            int cy=N2_CY+N2_CH/2-6;
            l.addCoin(new Coin(N2_CX+60,cy));l.addCoin(new Coin(N2_CX+150,cy));l.addCoin(new Coin(N2_CX+240,cy));
            l.addCoin(new SkinCoin(N2_CX+105,cy-25,"BLUE"));l.addCoin(new SkinCoin(N2_CX+195,cy+25,"RED"));
            return l;
        }
        if(n==3){
            Level l=new Level(3,90);
            l.setStartZone(new Zone(N3_SX,N3_SY,N3_SW,N3_SH,ZoneType.START));
            l.setIntermediateZone(new Zone(N3_CKX,N3_CKY,N3_CKW,N3_CKH,ZoneType.INTERMEDIATE));
            l.setGoalZone(new Zone(N3_GX,N3_GY,N3_GW,N3_GH,ZoneType.GOAL));
            int s=ES+1,bj=N3_BJY+N3_BJH/2-6;
            l.addEnemy(new Enemy(N3_BJX+20,N3_BJY+15,new LinearMovementStrategy(s,0)));
            l.addEnemy(new Enemy(N3_BJX+N3_BJW/2,N3_BJY+45,new LinearMovementStrategy(-s,0)));
            l.addEnemy(new Enemy(N3_BJX+N3_BJW-50,N3_BJY+15,new LinearMovementStrategy(s,0)));
            l.addEnemy(new Enemy(N3_IZX+15,N3_IZY+20,new LinearMovementStrategy(0,s)));
            l.addEnemy(new Enemy(N3_IZX+45,N3_IZY+120,new LinearMovementStrategy(0,-s)));
            l.addEnemy(new Enemy(N3_DRX+15,N3_DRY+30,new LinearMovementStrategy(0,s)));
            l.addEnemy(new Enemy(N3_DRX+45,N3_DRY+180,new LinearMovementStrategy(0,-s)));
            l.addCoin(new Coin(N3_BJX+50,bj));l.addCoin(new Coin(N3_BJX+140,bj));
            l.addCoin(new Coin(N3_BJX+230,bj));l.addCoin(new Coin(N3_BJX+320,bj));
            l.addCoin(new Coin(N3_IZX+N3_IZW/2-6,N3_IZY+70));l.addCoin(new Coin(N3_IZX+N3_IZW/2-6,N3_IZY+160));
            l.addCoin(new Coin(N3_DRX+N3_DRW/2-6,N3_DRY+60));l.addCoin(new Coin(N3_DRX+N3_DRW/2-6,N3_DRY+190));
            l.addCoin(new SkinCoin(N3_BJX+185,bj,"GREEN"));l.addCoin(new SkinCoin(N3_DRX+N3_DRW/2-6,N3_DRY+125,"BLUE"));
            return l;
        }
        // Nivel 1 por defecto
        Level l=new Level(1,60);
        l.setStartZone(new Zone(N1_SX,N1_SY,N1_ZW,N1_BH,ZoneType.START));
        l.setGoalZone(new Zone(N1_GX,N1_GY,N1_ZW,N1_BH,ZoneType.GOAL));
        int s=ES,d=2;
        l.addEnemy(new Enemy(215,N1_BY,new LinearMovementStrategy(0,s)));
        l.addEnemy(new Enemy(305,N1_BY+93,new LinearMovementStrategy(0,s)));
        l.addEnemy(new Enemy(395,N1_BY+186,new LinearMovementStrategy(0,s)));
        l.addEnemy(new Enemy(N1_CX+10,N1_BY+10,new DiagonalMovementStrategy(d,d)));
        l.addEnemy(new Enemy(N1_CX+N1_CW-30,N1_BY+N1_BH-30,new DiagonalMovementStrategy(-d,-d)));
        int cy=N1_BY+N1_BH/2-6;
        l.addCoin(new Coin(222,cy));l.addCoin(new Coin(305,cy));l.addCoin(new Coin(388,cy));
        l.addCoin(new SkinCoin(265,cy-30,"GREEN"));
        return l;
    }

    @Override public void keyPressed(KeyEvent e){
    	keys[e.getKeyCode()]=true;if(e.getKeyCode()==KeyEvent.VK_P&&!won&&!lost)paused=!paused;if(e.getKeyCode()==KeyEvent.VK_ESCAPE){timer.stop();gui.showMenu();}
    }
    
    @Override public void keyReleased(KeyEvent e){
    	keys[e.getKeyCode()]=false;
    }
    
    @Override public void keyTyped(KeyEvent e){}
    
    
}