package presentation;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

/**
 * Panel del menú principal.}
 */
public class MenuPanel extends JPanel {

    private enum State { LOADING, MENU, MODE_SELECT, CHAR_SELECT, INSTRUCTIONS }
    private State state;

    private final DopoHardestGameGUI gui;
    private JButton beginBtn;

    // Selecciones actuales
    private String selectedMode = "PLAYER";
    private String selectedP1   = "RED";
    private String selectedP2   = "BLUE";

    public MenuPanel(DopoHardestGameGUI gui) {
        this.gui   = gui;
        this.state = State.LOADING;
        setPreferredSize(new Dimension(620, 412));
        setLayout(null);
        buildLoading();
    }

    // Pantalla de carga 

    private void buildLoading() {
        removeAll();
        setBackground(Color.BLACK);

        beginBtn = new JButton("BEGIN");
        beginBtn.setBounds(210, 176, 200, 40);
        beginBtn.setBackground(new Color(50, 50, 50));
        beginBtn.setForeground(Color.WHITE);
        beginBtn.setFont(new Font("Arial", Font.BOLD, 16));
        beginBtn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        beginBtn.setFocusPainted(false);
        beginBtn.addActionListener(e -> showMenu());
        add(beginBtn);
        revalidate(); repaint();
    }

    // Menú principal 

    private void showMenu() {
        state = State.MENU;
        beginBtn = null;
        removeAll();
        setBackground(new Color(155, 170, 215));

        JButton btnPlay = btn("JUGAR", new Color(200, 30, 30), Color.WHITE);
        btnPlay.setBounds(210, 200, 200, 45);
        btnPlay.addActionListener(e -> showModeSelect());
        add(btnPlay);

        JButton btnLevels = btn("VER NIVELES", new Color(40, 40, 160), Color.WHITE);
        btnLevels.setBounds(210, 258, 200, 40);
        btnLevels.addActionListener(e -> gui.showLevelSelect());
        add(btnLevels);

        JButton btnLoad = btn("CARGAR PARTIDA", new Color(100, 70, 0), Color.WHITE);
        btnLoad.setBounds(210, 308, 200, 38);
        btnLoad.addActionListener(e -> gui.loadGame());
        add(btnLoad);

        JButton btnInfo = btn("INSTRUCCIONES", new Color(60, 100, 60), Color.WHITE);
        btnInfo.setBounds(210, 356, 200, 36);
        btnInfo.addActionListener(e -> showInstructions());
        add(btnInfo);

        revalidate(); repaint();
    }

    // Selección de modo 

    private void showModeSelect() {
        state = State.MODE_SELECT;
        removeAll();
        setBackground(new Color(155, 170, 215));

        JLabel title = label("SELECCIONA EL MODO", new Font("Arial", Font.BOLD, 20),
                             new Color(25, 35, 100));
        title.setBounds(0, 28, 620, 30);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title);

        // Fila 1: Player y PvP
        JButton bPlayer = btn("<html><center><b>PLAYER</b><br><small>1 jugador · flechas/WASD</small></center></html>",
                              new Color(40, 120, 40), Color.WHITE);
        bPlayer.setBounds(70, 90, 200, 80);
        bPlayer.addActionListener(e -> { selectedMode = "PLAYER"; showCharSelect(); });
        add(bPlayer);

        JButton bPvP = btn("<html><center><b>PLAYER VS PLAYER</b><br><small>2 jugadores · J2: I J K L</small></center></html>",
                           new Color(40, 40, 160), Color.WHITE);
        bPvP.setBounds(350, 90, 200, 80);
        bPvP.addActionListener(e -> { selectedMode = "PVP"; showCharSelect(); });
        add(bPvP);

        // Fila 2: PvsM
        JButton bRnd = btn("<html><center><b>VS MÁQUINA</b><br><small>IA Aleatoria</small></center></html>",
                           new Color(150, 80, 0), Color.WHITE);
        bRnd.setBounds(70, 200, 200, 80);
        bRnd.addActionListener(e -> { selectedMode = "PVM_RANDOM"; showCharSelect(); });
        add(bRnd);

        JButton bExp = btn("<html><center><b>VS MÁQUINA</b><br><small>IA Experta</small></center></html>",
                           new Color(120, 0, 0), Color.WHITE);
        bExp.setBounds(350, 200, 200, 80);
        bExp.addActionListener(e -> { selectedMode = "PVM_EXPERT"; showCharSelect(); });
        add(bExp);

        JButton bMvM = btn("<html><center><b>MÁQUINA VS MÁQUINA</b><br><small>IA vs IA</small></center></html>",
                           new Color(80, 0, 120), Color.WHITE);
        bMvM.setBounds(210, 310, 200, 50);
        bMvM.addActionListener(e -> { selectedMode = "MVM"; showCharSelect(); });
        add(bMvM);

        // Descripción de modos PvsM
        JLabel desc = label("<html><center>En modos VS MÁQUINA: tú juegas desde START → GOAL.<br>" +
                            "La máquina sale desde GOAL → START. Gana quien llegue primero.</center></html>",
                            new Font("Arial", Font.PLAIN, 11), new Color(35, 35, 80));
        desc.setBounds(40, 300, 540, 40);
        desc.setHorizontalAlignment(SwingConstants.CENTER);
        add(desc);

        JButton back = backBtn();
        back.addActionListener(e -> showMenu());
        add(back);
        revalidate(); repaint();
    }

    // Selección de personaje 
    
    private void showCharSelect() {
        state = State.CHAR_SELECT;
        removeAll();
        setBackground(new Color(155, 170, 215));

        boolean pvp = "PVP".equals(selectedMode) || "MVM".equals(selectedMode);

        JLabel title = label(pvp ? "ELIGE LOS PERSONAJES" : "ELIGE TU PERSONAJE",
                             new Font("Arial", Font.BOLD, 20), new Color(25, 35, 100));
        title.setBounds(0, 18, 620, 28);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title);

        String[] types = {"RED",   "BLUE",   "GREEN"};
        String[] names = {"Blinky (Rojo)", "Inky (Azul)", "Clyde (Verde)"};
        String[] descs = {
            "<html>Velocidad normal<br>Sin habilidades</html>",
            "<html>Más rápido y grande<br>Muere al 1er golpe</html>",
            "<html>Velocidad normal<br>Absorbe 1 golpe</html>"
        };
        Color[] colors = {new Color(210,55,55), new Color(55,115,210), new Color(55,175,55)};

        charRow(types, names, descs, colors, 55, "JUGADOR 1", t -> selectedP1 = t);

        if (pvp) {
            charRow(types, names, descs, colors, 215, "JUGADOR 2", t -> selectedP2 = t);
        }

        JButton play = btn("¡JUGAR!", new Color(200, 30, 30), Color.WHITE);
        play.setBounds(210, pvp ? 360 : 300, 200, 42);
        play.addActionListener(e -> gui.showLevelSelect());
        add(play);

        JButton back = backBtn();
        back.addActionListener(e -> showModeSelect());
        add(back);
        revalidate(); repaint();
    }

    /** 
     * Dibuja una fila de 3 botones de selección de personaje 
     */
    private void charRow(String[] types, String[] names, String[] descs, Color[] colors,
                         int y, String rowLabel, Consumer<String> setter) {
        JLabel lbl = label(rowLabel, new Font("Arial", Font.BOLD, 13), new Color(25, 35, 100));
        lbl.setBounds(0, y, 620, 18);
        lbl.setHorizontalAlignment(SwingConstants.CENTER);
        add(lbl);

        int bW = 145, gap = 18;
        int total = 3 * bW + 2 * gap;
        int sx = (620 - total) / 2;
        ButtonGroup group = new ButtonGroup();

        for (int i = 0; i < 3; i++) {
            final String t = types[i];
            JToggleButton tb = new JToggleButton(
                "<html><center><b>" + names[i] + "</b><br>" + descs[i] + "</center></html>");
            tb.setBounds(sx + i * (bW + gap), y + 22, bW, 82);
            tb.setBackground(colors[i]);
            tb.setForeground(Color.WHITE);
            tb.setFont(new Font("Arial", Font.PLAIN, 11));
            tb.setFocusPainted(false);
            tb.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            tb.addActionListener(e -> setter.accept(t));
            if (i == 0) { tb.setSelected(true); setter.accept(t); }
            group.add(tb);
            add(tb);
        }
    }

    // Instrucciones 

    public void goToInstructions() { showInstructions(); }

    private void showInstructions() {
        state = State.INSTRUCTIONS;
        removeAll();
        setBackground(new Color(155, 170, 215));

        JTextArea txt = new JTextArea(
            "THE DOPO HARDEST GAME — Instrucciones\n\n" +
            "Mueve tu cuadrado para recoger TODAS las monedas y llega a la zona GOAL (amarilla).\n" +
            "Evita los círculos azules: si te tocan, mueres y vuelves al inicio (o al checkpoint).\n\n" +
            "PERSONAJES:\n" +
            "  • Rojo  (Blinky): velocidad normal, muere al 1er golpe.\n" +
            "  • Azul  (Inky):   más rápido y más grande, muere al 1er golpe.\n" +
            "  • Verde (Clyde):  absorbe el primer golpe sin morir (pierde velocidad).\n\n" +
            "MONEDAS ESPECIALES (con letra S):\n" +
            "  Al recoger una moneda de color, adoptas temporalmente ese personaje.\n" +
            "  El efecto se pierde al morir.\n\n" +
            "MODOS DE JUEGO:\n" +
            "  • Player:          1 jugador, flechas o WASD.\n" +
            "  • Player vs Player: J1 = flechas/WASD · J2 = I (↑) J (←) K (↓) L (→).\n" +
            "  • vs Máquina Aleatoria: la IA se mueve al azar.\n" +
            "  • vs Máquina Experta:   la IA va directo a las monedas.\n\n" +
            "TECLAS ESPECIALES:\n" +
            "  P = Pausar/Reanudar     ESC = Volver al menú"
        );
        txt.setWrapStyleWord(true); txt.setLineWrap(true);
        txt.setOpaque(false); txt.setEditable(false);
        txt.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txt.setForeground(new Color(20, 30, 80));
        txt.setBounds(30, 20, 560, 320);
        add(txt);

        JButton back = btn("← MENÚ", new Color(150, 50, 150), Color.WHITE);
        back.setBounds(130, 358, 140, 36);
        back.addActionListener(e -> showMenu());
        add(back);

        JButton play = btn("VER NIVELES", new Color(200, 30, 30), Color.WHITE);
        play.setBounds(350, 358, 140, 36);
        play.addActionListener(e -> gui.showLevelSelect());
        add(play);

        revalidate(); repaint();
    }

    // Getters para DopoHardestGameGUI 

    public String getSelectedMode(){ 
    	return selectedMode; 
    }
    
    public String getSelectedP1(){ 
    	return selectedP1; 
    }
    
    public String getSelectedP2(){ 
    	return selectedP2; 
    }

    // Helpers de UI 

    private JButton btn(String text, Color bg, Color fg) {
        JButton b = new JButton(text);
        b.setBackground(bg); b.setForeground(fg);
        b.setFont(new Font("Arial", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createLineBorder(fg.darker(), 1));
        return b;
    }

    private JLabel label(String text, Font font, Color fg) {
        JLabel l = new JLabel(text);
        l.setFont(font); l.setForeground(fg);
        return l;
    }

    private JButton backBtn() {
        JButton b = btn("← VOLVER", new Color(130, 45, 130), Color.WHITE);
        b.setBounds(18, 370, 115, 30);
        return b;
    }

    // Fondo personalizado 

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth(), h = getHeight();

        if (state == State.LOADING) {
            // Texto descriptivo de la pantalla de carga
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Courier", Font.BOLD, 14));
            FontMetrics fm = g2.getFontMetrics();
            String top = "Complete";
            g2.drawString(top, (w - fm.stringWidth(top)) / 2, h / 2 - 55);

            g2.setColor(new Color(180, 180, 180));
            g2.setFont(new Font("Courier", Font.PLAIN, 11));
            fm = g2.getFontMetrics();
            String[] lines = {
                "This is The DOPO Hardest Game.",
                "I guarantee it is harder than any game",
                "you have ever played, or ever will play."
            };
            int lineY = h / 2 + 55;
            for (String line : lines) {
                g2.drawString(line, (w - fm.stringWidth(line)) / 2, lineY);
                lineY += 16;
            }
            if (beginBtn != null) beginBtn.setBounds((w - 200) / 2, h / 2 - 30, 200, 40);

        } else if (state == State.MENU) {
            // Título grande
            g2.setColor(new Color(25, 35, 100));
            g2.setFont(new Font("Arial", Font.PLAIN, 16));
            FontMetrics fm = g2.getFontMetrics();
            String sub = "THE DOPO'S";
            g2.drawString(sub, (w - fm.stringWidth(sub)) / 2, 90);

            g2.setFont(new Font("Arial", Font.BOLD, 42));
            fm = g2.getFontMetrics();
            String title = "HARDEST GAME";
            g2.drawString(title, (w - fm.stringWidth(title)) / 2, 148);
        }
    }
}
