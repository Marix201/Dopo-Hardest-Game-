package presentation;

import domain.LevelData;
import domain.LevelManager;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;

/**
 * Pantalla de selección de nivel.
 */
public class LevelSelectPanel extends JPanel {
    private final DopoHardestGameGUI gui;

    public LevelSelectPanel(DopoHardestGameGUI gui) {
        this.gui = gui;
        setPreferredSize(new Dimension(620, 412));
        setLayout(null);
        setBackground(new Color(155, 170, 215));
        build();
    }

    private void build() {
        JLabel title = new JLabel("SELECCIONA UN NIVEL");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(25, 35, 100));
        title.setBounds(0, 18, 620, 35);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title);

        // Cargar niveles desde la carpeta
        List<LevelData> levels = LevelManager.loadAllFromFolder("levels");

        // Si no hay .txt, usar los 3 hardcodeados de respaldo
        if (levels.isEmpty()) {
            levels.add(fallback(1, "Nivel 1 - Corredor Recto",  "STRAIGHT"));
            levels.add(fallback(2, "Nivel 2 - Forma de L", "L_SHAPE"));
            levels.add(fallback(3, "Nivel 3 - La U", "U_SHAPE"));
        }

        JLabel sub = new JLabel(levels.size() + " niveles disponibles");
        sub.setFont(new Font("Arial", Font.PLAIN, 11));
        sub.setForeground(new Color(50, 60, 120));
        sub.setBounds(0, 50, 620, 18);
        sub.setHorizontalAlignment(SwingConstants.CENTER);
        add(sub);

        // Colores para los botones (cicla si hay más de 6)
        Color[] colors = {
            new Color(40, 160, 60),
            new Color(30, 100, 180),
            new Color(150, 50, 30),
            new Color(120, 40, 160),
            new Color(160, 120, 0),
            new Color(0, 130, 130)
        };

        // Diseño en cuadrícula: máx 3 columnas
        int cols = Math.min(3, levels.size());
        int rows = (int) Math.ceil((double) levels.size() / cols);
        int btnW = 165, btnH = 100, gapX = 18, gapY = 14;
        int totalW = cols * btnW + (cols - 1) * gapX;
        int startX = (620 - totalW) / 2;
        int startY = 78;

        for (int i = 0; i < levels.size(); i++) {
            final LevelData ld = levels.get(i);
            int col = i % cols;
            int row = i / cols;
            int x = startX + col * (btnW + gapX);
            int y = startY + row * (btnH + gapY);

            String layoutIcon = layoutIcon(ld.layoutType);
            String timeStr = ld.timeLimit + "s";
            int    nEnemigos = ld.enemies.size();

            String html = "<html><center><b>" + ld.name + "</b><br>"
                + "<small>" + layoutIcon + " &nbsp; " + nEnemigos + " enemigos &nbsp; " + timeStr + "</small>"
                + "</center></html>";

            JButton btn = new JButton(html);
            btn.setBounds(x, y, btnW, btnH);
            btn.setFont(new Font("Arial", Font.BOLD, 11));
            btn.setFocusPainted(false);
            btn.setBackground(colors[i % colors.length]);
            btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            btn.addActionListener(e -> gui.startGame(ld.number));
            add(btn);
        }

        // Botón volver
        JButton back = new JButton("← VOLVER");
        back.setBounds(18, 370, 115, 30);
        back.setBackground(new Color(130, 45, 130));
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Arial", Font.BOLD, 12));
        back.setFocusPainted(false);
        back.addActionListener(e -> gui.showMenu());
        add(back);

        // Botón para abrir la carpeta levels/
        JButton openFolder = new JButton("Abrir carpeta levels/");
        openFolder.setBounds(160, 370, 180, 30);
        openFolder.setBackground(new Color(60, 90, 60));
        openFolder.setForeground(Color.WHITE);
        openFolder.setFont(new Font("Arial", Font.BOLD, 11));
        openFolder.setFocusPainted(false);
        openFolder.addActionListener(e -> {
            try {
                File folder = new File("levels").getAbsoluteFile();
                if (!folder.exists()) folder.mkdirs();
                Desktop.getDesktop().open(folder);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Carpeta: " + new File("levels").getAbsolutePath());
            }
        });
        add(openFolder);
    }

    private String layoutIcon(String layout) {
        switch (layout) {
            case "L_SHAPE": return "Forma L";
            case "U_SHAPE": return "Forma U ✓checkpoint";
            default: return "Corredor";
        }
    }

    private LevelData fallback(int n, String name, String layout) {
        LevelData ld = new LevelData();
        ld.number = n; ld.name = name; ld.layoutType = layout;
        ld.timeLimit = (n == 3) ? 90 : 60;
        return ld;
    }
}
