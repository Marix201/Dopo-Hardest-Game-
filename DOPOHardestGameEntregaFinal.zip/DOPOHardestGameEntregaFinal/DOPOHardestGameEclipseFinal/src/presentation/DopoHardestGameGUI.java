package presentation;

import javax.swing.*;
import java.awt.*;

public class DopoHardestGameGUI {
    private JFrame frame;
    private MenuPanel menuPanel;
    private GamePanel gamePanel;
    private HUDPanel hudPanel;
    private LevelSelectPanel levelSelectPanel;

    // Selecciones guardadas desde el menú
    private String savedMode = "PLAYER";
    private String savedP1 = "RED";
    private String savedP2 = "BLUE";

    public DopoHardestGameGUI() {
        frame = new JFrame("The DOPO Hardest Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        menuPanel = new MenuPanel(this);
        frame.add(menuPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void showMenu() {
        frame.getContentPane().removeAll();
        menuPanel = new MenuPanel(this);
        frame.add(menuPanel);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    /**
     * Llamado desde MenuPanel justo antes de ir a LevelSelect, para guardar las selecciones del jugador.
     */
    public void saveSelections(String mode, String p1, String p2) {
        this.savedMode = mode;
        this.savedP1 = p1;
        this.savedP2 = p2;
    }

    public void showLevelSelect() {
        // Guardar selecciones actuales si hay un menuPanel activo
        if (menuPanel != null) {
            savedMode = menuPanel.getSelectedMode();
            savedP1 = menuPanel.getSelectedP1();
            savedP2 = menuPanel.getSelectedP2();
        }
        frame.getContentPane().removeAll();
        levelSelectPanel = new LevelSelectPanel(this);
        frame.add(levelSelectPanel);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    public void showInstructions() {
        frame.getContentPane().removeAll();
        menuPanel = new MenuPanel(this);
        menuPanel.goToInstructions();
        frame.add(menuPanel);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    public void startGame(int levelNumber) {
        frame.getContentPane().removeAll();
        hudPanel  = new HUDPanel(this);
        gamePanel = new GamePanel(hudPanel, this);
        hudPanel.setGameTimer(gamePanel.getTimer());

        frame.setLayout(new BorderLayout());
        frame.add(hudPanel, BorderLayout.NORTH);
        frame.add(gamePanel, BorderLayout.CENTER);
        frame.pack();
        frame.revalidate();
        frame.repaint();

        gamePanel.requestFocusInWindow();
        gamePanel.startGame(savedMode, savedP1, savedP2, levelNumber);
    }

    public void loadGame() {
        frame.getContentPane().removeAll();
        hudPanel  = new HUDPanel(this);
        gamePanel = new GamePanel(hudPanel, this);
        hudPanel.setGameTimer(gamePanel.getTimer());

        frame.setLayout(new BorderLayout());
        frame.add(hudPanel, BorderLayout.NORTH);
        frame.add(gamePanel, BorderLayout.CENTER);
        frame.pack();
        frame.revalidate();
        frame.repaint();

        gamePanel.requestFocusInWindow();
        gamePanel.startGame("PLAYER", "RED", null, 1);
        gamePanel.doLoad();
    }
}