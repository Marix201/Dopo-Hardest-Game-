package presentation;
import javax.swing.SwingUtilities;

/**
 * Clase principal
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(DopoHardestGameGUI::new);
    }
}
