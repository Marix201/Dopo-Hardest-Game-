package domain;
import java.awt.*;

/**
 * Jugador azul — variante grande y rápida.
 */
public class BluePlayer extends Player {

    public BluePlayer(int x, int y) { 
    	super(x, y, 28, 4); 
    }

    @Override
    public void receiveHit() {
        if (isShieldInvincible()) return;
        if (shield) { consumeShield(); } else { die(); }
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 5, 5);
        GradientPaint gp = new GradientPaint(
            x, y, new Color(80, 140, 255),
            x + width, y + height, new Color(20, 60, 200));
        g2.setPaint(gp);
        g2.fillRoundRect(x, y, width, height, 5, 5);
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
        drawTag(g2);
        drawShield(g2);
    }
}