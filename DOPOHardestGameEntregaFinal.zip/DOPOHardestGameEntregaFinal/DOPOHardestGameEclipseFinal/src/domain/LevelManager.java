package domain;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Gestiona la carga, guardado y construcción de niveles.
 */
public class LevelManager {

    // CARGAR  

    /** 
     * Detecta la extensión y carga el archivo correspondiente. 
     */
    public static LevelData load(String path) throws IOException {
        if (path.endsWith(".dat")) return loadFromDat(path);
        return loadFromTxt(path);
    }

    /** 
     * Lee un archivo .txt con el formato de LevelData. 
     */
    public static LevelData loadFromTxt(String path) throws IOException {
        LevelData ld = new LevelData();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                
                if (line.startsWith("name=")) ld.name = line.substring(5);
                else if (line.startsWith("number=")) ld.number = Integer.parseInt(line.substring(7).trim());
                else if (line.startsWith("timeLimit=")) ld.timeLimit = Integer.parseInt(line.substring(10).trim());
                else if (line.startsWith("layoutType=")) ld.layoutType = line.substring(11).trim();
                else if (line.startsWith("zone ")) parseZone (ld, line.substring(5).trim());
                else if (line.startsWith("spawn ")) parseSpawn(ld, line.substring(6).trim());
                else if (line.startsWith("enemy ")) parseEnemy(ld, line.substring(6).trim());
                else if (line.startsWith("coin ")) parseCoin (ld, line.substring(5).trim());
                else if (line.startsWith("lifesource ")) parseLifeSource(ld, line.substring(11).trim());
                else if (line.startsWith("bomb ")) parseBomb(ld, line.substring(5).trim());
            }
        }
        return ld;
    }

    private static void parseZone(LevelData ld, String s) {
        String[] p = s.split("\\s+");
        int[] box = { Integer.parseInt(p[1]), Integer.parseInt(p[2]),
                      Integer.parseInt(p[3]), Integer.parseInt(p[4]) };
        switch (p[0]) {
            case "START": ld.startZone = box; break;
            case "GOAL":  ld.goalZone  = box; break;
            case "CHECK": ld.checkZone = box; break;
        }
    }

    private static void parseSpawn(LevelData ld, String s) {
        String[] p = s.split("\\s+");
        int[] pos = { Integer.parseInt(p[1]), Integer.parseInt(p[2]) };
        if (Integer.parseInt(p[0]) == 1) ld.spawn1 = pos; else ld.spawn2 = pos;
    }

    private static void parseEnemy(LevelData ld, String s) {
        String[] p = s.split("\\s+");
        ld.enemies.add(new LevelData.EnemyData(
            p[0],
            Integer.parseInt(p[1]), Integer.parseInt(p[2]),
            Integer.parseInt(p[3]), Integer.parseInt(p[4])
        ));
    }

    private static void parseCoin(LevelData ld, String s) {
        String[] p = s.split("\\s+");
        ld.coins.add(new LevelData.CoinData(
            p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2])
        ));
    }

    /** 
     * Deserializa un LevelData desde binario .dat. 
     */
    public static LevelData loadFromDat(String path) throws IOException {
        try (ObjectInputStream ois =
                new ObjectInputStream(new FileInputStream(path))) {
            return (LevelData) ois.readObject();
        } catch (ClassNotFoundException e) {
            throw new IOException("Archivo corrupto: " + e.getMessage());
        }
    }

    // GUARDAR
    
    /** 
     * Guarda un LevelData en formato .txt legible y editable. 
     */
    public static void saveToTxt(LevelData ld, String path) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
            pw.println("# DOPO Hardest Game - Configuracion de nivel");
            pw.println("# Puedes editar este archivo para modificar el nivel");
            pw.println();
            pw.println("name=" + ld.name);
            pw.println("number=" + ld.number);
            pw.println("timeLimit=" + ld.timeLimit);
            pw.println("layoutType=" + ld.layoutType);
            pw.println();
            pw.println("# Zonas: zone TIPO x y ancho alto");
            pw.printf ("zone START  %d %d %d %d%n",
                ld.startZone[0], ld.startZone[1], ld.startZone[2], ld.startZone[3]);
            pw.printf ("zone GOAL   %d %d %d %d%n",
                ld.goalZone[0],  ld.goalZone[1],  ld.goalZone[2],  ld.goalZone[3]);
            if (ld.checkZone != null)
                pw.printf("zone CHECK  %d %d %d %d%n",
                    ld.checkZone[0], ld.checkZone[1], ld.checkZone[2], ld.checkZone[3]);
            pw.println();
            pw.println("# Spawn jugadores: spawn JUGADOR x y");
            pw.printf ("spawn 1 %d %d%n", ld.spawn1[0], ld.spawn1[1]);
            pw.printf ("spawn 2 %d %d%n", ld.spawn2[0], ld.spawn2[1]);
            pw.println();
            pw.println("# Enemigos: enemy TIPO x y dx dy  (TIPO: LINEAR | DIAGONAL)");
            for (LevelData.EnemyData e : ld.enemies)
                pw.printf("enemy %s %d %d %d %d%n", e.type, e.x, e.y, e.dx, e.dy);
            pw.println();
            pw.println("# Monedas: coin TIPO x y  (TIPO: YELLOW | RED | BLUE | GREEN)");
            for (LevelData.CoinData c : ld.coins)
                pw.printf("coin %s %d %d%n", c.type, c.x, c.y);
            if (!ld.lifeSources.isEmpty()) {
                pw.println();
                pw.println("# Fuentes de vida: lifesource x y");
                for (LevelData.LifeSourceData ls : ld.lifeSources)
                    pw.printf("lifesource %d %d%n", ls.x, ls.y);
            }
            if (!ld.bombs.isEmpty()) {
                pw.println();
                pw.println("# Bombas: bomb x y");
                for (LevelData.BombData b : ld.bombs)
                    pw.printf("bomb %d %d%n", b.x, b.y);
            }
        }
    }

    /** 
     * Serializa un LevelData en binario .dat. 
     * */
    public static void saveToDat(LevelData ld, String path) throws IOException {
        try (ObjectOutputStream oos =
                new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(ld);
        }
    }

    // CONSTRUIR NIVEL JUGABLE
    
    /**
     * Convierte un LevelData en un Level jugable.
     * Es el puente entre los datos del .txt y el motor del juego.
     */
    public static Level buildLevel(LevelData ld) {
        Level lvl = new Level(ld.number, ld.timeLimit);

        lvl.setStartZone(new Zone(
            ld.startZone[0], ld.startZone[1], ld.startZone[2], ld.startZone[3],
            Zone.ZoneType.START));
        lvl.setGoalZone(new Zone(
            ld.goalZone[0], ld.goalZone[1], ld.goalZone[2], ld.goalZone[3],
            Zone.ZoneType.GOAL));
        if (ld.checkZone != null)
            lvl.setIntermediateZone(new Zone(
                ld.checkZone[0], ld.checkZone[1], ld.checkZone[2], ld.checkZone[3],
                Zone.ZoneType.INTERMEDIATE));
        for (LevelData.EnemyData ed : ld.enemies) {
            MovementStrategy ms;
            switch (ed.type.toUpperCase()) {
                case "DIAGONAL":
                    ms = new DiagonalMovementStrategy(ed.dx, ed.dy);
                    break;
                case "PATROL":
                    ms = new PatrolMovementStrategy(ed.dx);
                    break;
                default:
                    ms = new LinearMovementStrategy(ed.dx, ed.dy);
                    break;
            }

            lvl.addEnemy(new Enemy(ed.x, ed.y, ms));
        }

        for (LevelData.CoinData cd : ld.coins) {
            switch (cd.type.toUpperCase()) {
                case "RED": lvl.addCoin(new SkinCoin(cd.x, cd.y, "RED")); break;
                case "BLUE": lvl.addCoin(new SkinCoin(cd.x, cd.y, "BLUE")); break;
                case "GREEN": lvl.addCoin(new SkinCoin(cd.x, cd.y, "GREEN")); break;
                default: lvl.addCoin(new Coin(cd.x, cd.y)); break;
            }
        }

        for (LevelData.LifeSourceData ls : ld.lifeSources)
            lvl.addLifeSource(new LifeSource(ls.x, ls.y));

        for (LevelData.BombData bd : ld.bombs)
            lvl.addBomb(new Bomb(bd.x, bd.y));

        // Zonas jugables para la IA 
        switch (ld.layoutType != null ? ld.layoutType : "STRAIGHT") {

            case "STRAIGHT":
                int stX = ld.startZone[0];
                int stY = Math.min(ld.startZone[1], ld.goalZone[1]);
                int stW = (ld.goalZone[0] + ld.goalZone[2]) - stX;
                int stH = Math.max(ld.startZone[3], ld.goalZone[3]);
                lvl.addPlayableZone(stX, stY, stW, stH);
                break;

            case "L_SHAPE":
                // START (alto, izquierda)
                lvl.addPlayableZone(ld.startZone[0], ld.startZone[1], ld.startZone[2], ld.startZone[3]);
                
                // GOAL (alto, derecha)
                lvl.addPlayableZone(ld.goalZone[0], ld.goalZone[1], ld.goalZone[2], ld.goalZone[3]);
                
                // Corredor horizontal entre START y GOAL
                int lCorX = ld.startZone[0] + ld.startZone[2];
                int lCorY = ld.goalZone[1];
                int lCorW = ld.goalZone[0] - lCorX;
                int lCorH = ld.goalZone[3];
                lvl.addPlayableZone(lCorX, lCorY, lCorW, lCorH);
                break;

            case "U_SHAPE":
                // START
                lvl.addPlayableZone(ld.startZone[0], ld.startZone[1], ld.startZone[2], ld.startZone[3]);
                
                // GOAL
                lvl.addPlayableZone(ld.goalZone[0], ld.goalZone[1], ld.goalZone[2], ld.goalZone[3]);
                
                // Corredor izquierdo (IZ)
                int izX = ld.startZone[0] + ld.startZone[2];
                int izY = ld.startZone[1];
                int izW = 80, izH = 220;
                lvl.addPlayableZone(izX, izY, izW, izH);
                
                // Corredor bajo (BJ)
                lvl.addPlayableZone(izX, izY + izH - 30, 380, 80);
                
                // Corredor derecho (DR)
                lvl.addPlayableZone(izX + 380 - 40, ld.goalZone[1], 80, 290);
                if (ld.checkZone != null)
                    lvl.addPlayableZone(ld.checkZone[0], ld.checkZone[1], ld.checkZone[2], ld.checkZone[3]);
                break;

            default:
                // Fallback: zona que engloba todo el nivel
                lvl.addPlayableZone(0, 0, 640, 480);
        }

        return lvl;
    }

    // CARGAR CARPETA COMPLETA
   
    /**
     * Lee todos los .txt y .dat de una carpeta y los devuelve
     * ordenados por número de nivel.
     */
    public static List<LevelData> loadAllFromFolder(String folderPath) {
        List<LevelData> result = new ArrayList<>();
        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) return result;

        File[] files = folder.listFiles((dir, name) ->
            name.endsWith(".txt") || name.endsWith(".dat"));
        if (files == null) return result;

        for (File f : files) {
            try {
                result.add(load(f.getAbsolutePath()));
            } catch (IOException ex) {
                System.err.println("No se pudo cargar " + f.getName()
                                   + ": " + ex.getMessage());
            }
        }
        result.sort((a, b) -> Integer.compare(a.number, b.number));
        return result;
    }
    
    private static void parseLifeSource(LevelData ld, String s) {
        String[] p = s.split("\\s+");
        ld.lifeSources.add(new LevelData.LifeSourceData(
            Integer.parseInt(p[0]), Integer.parseInt(p[1])));
    }

    private static void parseBomb(LevelData ld, String s) {
        String[] p = s.split("\\s+");
        ld.bombs.add(new LevelData.BombData(
            Integer.parseInt(p[0]), Integer.parseInt(p[1])));
    }
}
