package domain;

import java.awt.*;

/**
 * Fuente de vida: elemento que da un escudo al jugador.
 * Desaparece al ser usada.
 */
public class LifeSource extends GameElement {
    private boolean used = false;
    private int animTick = 0; // animación de pulso

    public LifeSource(int x, int y) {
        super(x, y, 22, 22);
    }

    public boolean isUsed(){ 
    	return used; 
    }
    
    public void use() { 
    	used = true; 
    }

    public void tick() { 
    	animTick++; 
    }

    @Override
    public void draw(Graphics g) {
        if (used) return;
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Parpadeo lento igual que el GreenPlayer con escudo 
        boolean blink = (animTick % 40) < 8 && (animTick % 40) % 2 == 0;
        if (blink) return;

        // Halo exterior 
        float pulse = (float)(Math.sin(animTick * 0.12) * 0.5 + 0.5); // 0..1
        int extra   = (int)(pulse * 7);
        
        // Halo verde-cian
        g2.setColor(new Color(80, 255, 160, 55));
        g2.fillRoundRect(x - extra, y - extra, width + extra*2, height + extra*2, 10, 10);
        g2.setColor(new Color(80, 255, 160, 130));
        g2.setStroke(new BasicStroke(2.5f));
        g2.drawRoundRect(x - extra, y - extra, width + extra*2, height + extra*2, 10, 10);

        // Cuerpo: mismo gradiente verde que GreenPlayer con ownShield 
        g2.setPaint(new GradientPaint(x, y, new Color(80, 255, 100),
                                     x + width, y + height, new Color(20, 180, 50)));
        g2.fillRoundRect(x, y, width, height, 5, 5);

        // Borde blanco igual que el borde del GreenPlayer 
        g2.setColor(new Color(200, 255, 200, 180));
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(x - 2, y - 2, width + 4, height + 4, 7, 7);

        // Cruz blanca (símbolo de escudo/vida)
        g2.setColor(Color.WHITE);
        int cx = x + width/2, cy = y + height/2;
        int arm = 5, thick = 3;
        g2.fillRect(cx - thick, cy - arm,   thick*2, arm*2);   // vertical
        g2.fillRect(cx - arm,   cy - thick, arm*2,   thick*2); // horizontal

        // Borde exterior 
        g2.setColor(new Color(0, 160, 80));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
    }
}