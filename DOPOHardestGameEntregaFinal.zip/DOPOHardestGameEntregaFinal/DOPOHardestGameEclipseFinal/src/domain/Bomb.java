package domain;

import java.awt.*;

import presentation.GamePanel;

/**
 * Bomba: elemento estático que destruye a cualquier elemento que pase por ella
 * (jugador O enemigo). 
 * Desaparece al explotar.
 */
public class Bomb extends GameElement {
    private boolean exploded = false;
    private int animTick = 0;

    public Bomb(int x, int y) {
        super(x, y, 20, 20);
    }

    public boolean isExploded(){ 
    	return exploded; 
    }
    
    public void explode(){ 
    	exploded = true; 
    }
    
    public void tick(){ 
    	animTick++; 
    }
    
    public void checkCollision(GameEngine engine) {

        if (exploded) return;

        // Jugador 1
        Player p1 = engine.getPlayer();

        if (p1 != null && getBounds().intersects(p1.getBounds())) {
            p1.die();
            explode();
            return;
        }

        // Jugador 2
        Player p2 = engine.getPlayer2();

        if (p2 != null && getBounds().intersects(p2.getBounds())) {
            p2.die();
            explode();
            return;
        }

        // Enemigos
        for (Enemy e : engine.getCurrentLevel().getEnemies()) {

            if (e != null && getBounds().intersects(e.getBounds())) {
                e.destroy();
                explode();
                return;
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        if (exploded) return;
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Mecha 
        g2.setColor(new Color(180, 140, 60));
        g2.setStroke(new BasicStroke(2f));
        g2.drawLine(x + width - 3, y + 2, x + width + 3, y - 4);

        // Destello de la mecha que parpadea :)
        if ((animTick / 6) % 2 == 0) {
            g2.setColor(new Color(255, 200, 50));
            g2.fillOval(x + width, y - 7, 6, 6);
        }

        // Bomba
        g2.setColor(new Color(30, 30, 30));
        g2.fillOval(x, y + 3, width, height - 3);

        // Brillo
        g2.setColor(new Color(255, 255, 255, 60));
        g2.fillOval(x + 4, y + 5, width/3, height/4);

        // Borde
        g2.setColor(new Color(10, 10, 10));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawOval(x, y + 3, width, height - 3);
    }
}