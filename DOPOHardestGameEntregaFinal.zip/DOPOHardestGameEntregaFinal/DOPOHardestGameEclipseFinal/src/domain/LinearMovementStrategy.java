package domain;

/**
 * Estrategia de movimiento lineal para enemigos.
 */ 
public class LinearMovementStrategy implements MovementStrategy {
    private int dx, dy;

    public LinearMovementStrategy(int dx, int dy) { 
    	this.dx = dx; this.dy = dy; 
    }

    @Override public void move(Enemy enemy) {
        enemy.setX(enemy.getX() + dx);
        enemy.setY(enemy.getY() + dy);
    }
    
    @Override public void reverseX(){
    	dx = -dx; 
    }
    
    @Override public void reverseY(){ 
    	dy = -dy; 
    }
}
