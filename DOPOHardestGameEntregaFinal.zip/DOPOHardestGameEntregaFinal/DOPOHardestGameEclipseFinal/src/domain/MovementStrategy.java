package domain;

/**
 * Contrato que define cómo se mueve un enemigo
 */
public interface MovementStrategy {
    void move(Enemy enemy);
    void reverseX();
    void reverseY();
}
