package domain;

/**
 * Estrategia de movimiento diagonal para enemigos.
 */
public class DiagonalMovementStrategy implements MovementStrategy {
    private int dx, dy;

    public DiagonalMovementStrategy(int dx, int dy){ 
    	this.dx = dx; this.dy = dy; 
    }

    @Override public void move(Enemy enemy) {
        enemy.setX(enemy.getX() + dx);
        enemy.setY(enemy.getY() + dy);
    }
    
    @Override public void reverseX(){ 
    	dx = -dx; 
    }
    
    @Override public void reverseY(){ 
    	dy = -dy; 
    }
}
