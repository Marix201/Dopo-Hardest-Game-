package domain;
import java.util.*;
import java.awt.Rectangle;

/**
 * Jugador controlado por inteligencia artificial.
 */
public class MachinePlayer extends RedPlayer {

    public enum Profile { ALEATORIA, EXPERTA }

    private final Profile profile;
    private final Random  rng = new Random();
    private Level level;
    private String skinType = "RED"; // apariencia visual del jugador IA

    // Estado IA aleatoria
    private int ticksSinceDir = 0;
    private int dirChangeTick = 25;
    private int aiDx = 1, aiDy = 0;

    // Estado IA experta 
    private int stuckTicks = 0;
    private int lastX = -1, lastY = -1;
    private int escapeDx = 0,  escapeDy = 0;
    private int escapeTicks = 0;
    private static final int STUCK_THRESHOLD = 12;
    private static final int ESCAPE_DURATION = 18;

    public MachinePlayer(int x, int y, Profile profile, Level level) {
        this(x, y, profile, level, "RED");
    }

    /** 
     * Constructor con skin, la IA puede tener cualquier apariencia visual 
     */
    public MachinePlayer(int x, int y, Profile profile, Level level, String skinType) {
        super(x, y);
        this.profile = profile;
        this.level = level;
        this.lastX = x;
        this.lastY = y;
        this.skinType = skinType;
    }

    @Override
    public void computeAIMove() {
        if (profile == Profile.ALEATORIA) moveRandom();
        else moveExpert();
    }

    // IA Aleatoria 

    private void moveRandom() {
        ticksSinceDir++;

        // Evadir enemigos cercanos
        Enemy nearest = nearestEnemy();
        if (nearest != null) {
            double dist = Math.hypot(nearest.getX() - getX(), nearest.getY() - getY());
            if (dist < 50) {
                int fx = Integer.compare(getX(), nearest.getX());
                int fy = Integer.compare(getY(), nearest.getY());
                if (isValidMove(fx, fy)) { setDirection(fx, fy); ticksSinceDir = 0; return; }
            }
        }

        if (ticksSinceDir >= dirChangeTick) {
            ticksSinceDir = 0;
            dirChangeTick = 15 + rng.nextInt(20);

            List<int[]> valid = new ArrayList<>();
            int[][] dirs = {{-1,0},{1,0},{0,-1},{0,1},{-1,-1},{-1,1},{1,-1},{1,1}};
            for (int[] d : dirs) {
                if (isValidMove(d[0], d[1])) valid.add(d);
            }
            if (!valid.isEmpty()) {
                int[] chosen = valid.get(rng.nextInt(valid.size()));
                aiDx = chosen[0]; aiDy = chosen[1];
            }
        }
        setDirection(aiDx, aiDy);
    }

    // IA Experta 

    private void moveExpert() {
        if (escapeTicks > 0) {
            escapeTicks--;
            setDirection(escapeDx, escapeDy);
            return;
        }

        if (Math.abs(getX() - lastX) < 1 && Math.abs(getY() - lastY) < 1) {
            stuckTicks++;
        } else {
            stuckTicks = 0;
        }
        lastX = getX(); lastY = getY();

        if (stuckTicks >= STUCK_THRESHOLD) {
            stuckTicks = 0;
            int[][] perps = {{0,-1},{0,1},{-1,0},{1,0},{-1,-1},{1,1},{-1,1},{1,-1}};
            List<int[]> valid = new ArrayList<>();
            for (int[] d : perps) {
                if (isValidMove(d[0], d[1]) && !towardEnemy(d[0], d[1])) valid.add(d);
            }
            if (valid.isEmpty()) {
                for (int[] d : perps) if (isValidMove(d[0], d[1])) valid.add(d);
            }
            if (!valid.isEmpty()) {
                int[] e = valid.get(rng.nextInt(valid.size()));
                escapeDx = e[0]; escapeDy = e[1];
                escapeTicks = ESCAPE_DURATION;
                setDirection(escapeDx, escapeDy);
            }
            return;
        }

        Enemy nearest = nearestEnemy();
        if (nearest != null) {
            double dist = Math.hypot(nearest.getX() - getX(), nearest.getY() - getY());
            if (dist < 45) {
                int fx = Integer.compare(getX(), nearest.getX());
                int fy = Integer.compare(getY(), nearest.getY());
                int[][] opts = {{fx,fy},{fx,0},{0,fy},{-fx,-fy}};
                for (int[] o : opts) {
                    if (isValidMove(o[0], o[1])) { setDirection(o[0], o[1]); return; }
                }
            }
        }

        int[] target = getTarget();
        if (target == null) { moveRandom(); return; }

        int dx = Integer.compare(target[0], getX());
        int dy = Integer.compare(target[1], getY());

        int[][] attempts = {{dx,dy},{dx,0},{0,dy},{-dx,dy},{dx,-dy}};
        for (int[] a : attempts) {
            if ((a[0] != 0 || a[1] != 0) && isValidMove(a[0], a[1])) {
                setDirection(a[0], a[1]);
                return;
            }
        }

        moveRandom();
    }

    // Helpers 
    
    private int[] getTarget() {
        Coin target = level.getCoins().stream()
                .filter(c -> !c.isSkinCoin() && !c.isCollected())
                .min(Comparator.comparingDouble(c ->
                        Math.hypot(c.getX() - getX(), c.getY() - getY())))
                .orElse(null);

        if (target != null) return new int[]{target.getX(), target.getY()};

        if (level.getGoalZone() != null) {
            Zone g = level.getGoalZone();
            return new int[]{g.getX() + g.getWidth() / 2, g.getY() + g.getHeight() / 2};
        }
        return null;
    }

    private Enemy nearestEnemy() {
        return level.getEnemies().stream()
                .min(Comparator.comparingDouble(e ->
                        Math.hypot(e.getX() - getX(), e.getY() - getY())))
                .orElse(null);
    }

    private boolean towardEnemy(int dx, int dy) {
        Enemy e = nearestEnemy();
        if (e == null) return false;
        int ex = Integer.compare(e.getX(), getX());
        int ey = Integer.compare(e.getY(), getY());
        return dx == ex && dy == ey;
    }

    private boolean isValidMove(int dx, int dy) {
        Rectangle future = new Rectangle(
                getX() + dx * speed,
                getY() + dy * speed,
                getWidth(), getHeight());
        
        // No atraviesa paredes sólidas
        for (Wall w : level.getWalls()) {
            if (future.intersects(w.getBounds())) return false;
        }
        
        // No sale de las zonas jugables del nivel
        if (!level.isInsideBounds(future)) return false;
        return true;
    }

    public void setLevel(Level l) { this.level = l; }
    public Profile getProfile()   { return profile; }
    @Override
    public boolean isMachinePlayer() { return true; }
    public String  getSkinType()  { return skinType; }

    @Override
    public void draw(java.awt.Graphics g) {
        // Dibujar según la skin seleccionada
        java.awt.Graphics2D g2 = (java.awt.Graphics2D) g;
        g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,
                            java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        // Sombra
        g2.setColor(new java.awt.Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 5, 5);
        
        // Color según skin
        java.awt.Color top, bot;
        switch (skinType) {
            case "BLUE":
                top = new java.awt.Color(80, 140, 255);
                bot = new java.awt.Color(20, 60, 200);
                break;
            case "GREEN":
                top = new java.awt.Color(80, 255, 100);
                bot = new java.awt.Color(20, 180, 50);
                break;
            default: // RED
                top = new java.awt.Color(255, 80, 80);
                bot = new java.awt.Color(180, 20, 20);
        }
        g2.setPaint(new java.awt.GradientPaint(x, y, top, x + width, y + height, bot));
        g2.fillRoundRect(x, y, width, height, 5, 5);
        
        // Borde (color del jugador para distinguir J1/J2)
        g2.setColor(borderColor);
        g2.setStroke(new java.awt.BasicStroke(2f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
        
        // Etiqueta IA pequeña
        g2.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 7));
        g2.setColor(java.awt.Color.WHITE);
        g2.drawString("IA", x + width/2 - 4, y + height/2 + 3);
        drawShield(g2);
    }

    @Override
    public Player createTransformed(String skinType, int x, int y, Level level) {
        return new MachinePlayer(x, y, this.profile, level, skinType);
    }
}