package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase serializable que representa la configuración completa de un nivel.
 *
 * Se puede guardar/cargar en dos formatos:
 *   .txt  → legible y editable a mano
 *   .dat  → binario Java serializado.
 */
public class LevelData implements Serializable {

    private static final long serialVersionUID = 1L;

    // Metadatos
    public String name = "Sin nombre";
    public int number = 1;
    public int timeLimit  = 60;
    
     // STRAIGHT | L_SHAPE | U_SHAPE 
    public String layoutType = "STRAIGHT";

    // Zonas [x, y, w, h]
    public int[] startZone = new int[]{10, 60, 150, 280};
    public int[] goalZone  = new int[]{460, 60, 150, 280};
    public int[] checkZone = null; // null = no hay checkpoint

    // Posiciones de spawn [x, y]
    public int[] spawn1 = new int[]{75, 190};
    public int[] spawn2 = new int[]{495, 190};

    // Listas de enemigos y monedas
    public List<EnemyData> enemies = new ArrayList<>();
    public List<CoinData> coins = new ArrayList<>();
    
    public List<LifeSourceData> lifeSources = new ArrayList<>();
    public List<BombData> bombs = new ArrayList<>();

    public static class LifeSourceData implements Serializable {
        private static final long serialVersionUID = 1L;
        public int x, y;
        public LifeSourceData(int x, int y){ 
        	this.x=x; this.y=y;
        }
    }

    public static class BombData implements Serializable {
        private static final long serialVersionUID = 1L;
        public int x, y;
        public BombData(int x, int y){ this.x=x; this.y=y; }
    }


    public static class EnemyData implements Serializable {
        private static final long serialVersionUID = 1L;
        public String type; // "LINEAR" | "DIAGONAL" | "PATROL"
        public int x, y, dx, dy;

        public EnemyData() {}
        public EnemyData(String type, int x, int y, int dx, int dy) {
            this.type = type;
            this.x = x; this.y = y;
            this.dx = dx; this.dy = dy;
        }
    }

    public static class CoinData implements Serializable {
        private static final long serialVersionUID = 1L;
        public String type; // "YELLOW" | "RED" | "BLUE" | "GREEN"
        public int x, y;
        public CoinData(){}
        public CoinData(String type, int x, int y) {
            this.type = type;
            this.x = x; this.y = y;
        }
    }
}
