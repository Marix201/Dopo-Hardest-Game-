package domain;

/**
 * Motor principal del juego, coordina el update de todos los elementos cada tick y gestiona las colisiones.
 */
public class GameEngine {
    private Player player1;
    private Player player2;
    private final Level currentLevel;

    public GameEngine(Player p1, Level level) {
        this.player1      = p1;
        this.player2      = null;
        this.currentLevel = level;
    }

    public GameEngine(Player p1, Player p2, Level level) {
        this.player1      = p1;
        this.player2      = p2;
        this.currentLevel = level;
    }

    public void update() {
        player1.computeAIMove();
        if (player2 != null) player2.computeAIMove();
        player1.move();
        if (player2 != null) player2.move();
        currentLevel.getLifeSources().forEach(LifeSource::tick);
        currentLevel.getEnemies().forEach(Enemy::move);
        checkCollisions();
    }

    private void checkCollisions() {
        checkForPlayer(player1);
        if (player2 != null) checkForPlayer(player2);
        checkBombs();

        if (player2 != null
                && player1.isAlive() && player2.isAlive()
                && player1.getBounds().intersects(player2.getBounds())) {
            player1.receiveHit();
            player2.receiveHit();
        }
    }

    private void checkForPlayer(Player p) {
        if (!p.isAlive()) return;

        boolean enZonaSegura = false;
        if (currentLevel.getStartZone() != null && currentLevel.getStartZone().intersects(p))
            enZonaSegura = true;
        if (currentLevel.getIntermediateZone() != null && currentLevel.getIntermediateZone().intersects(p))
            enZonaSegura = true;
        if (currentLevel.getGoalZone() != null && currentLevel.getGoalZone().intersects(p))
            enZonaSegura = true;

        if (!enZonaSegura) {
            for (Enemy e : currentLevel.getEnemies()) {
                if (e.collidesWithPlayer(p)) {
                    p.receiveHit();
                    return;
                }
            }
        }

        for (LifeSource ls : currentLevel.getLifeSources()) {
            if (!ls.isUsed() && ls.getBounds().intersects(p.getBounds())) {
                ls.use();
                p.grantShield();
            }
        }

        for (Bomb b : currentLevel.getBombs()) {
            if (!b.isExploded() && b.getBounds().intersects(p.getBounds())) {
                b.explode();
                p.die();
                return;
            }
        }
    }

    private void checkBombs() {
        for (Bomb b : currentLevel.getBombs()) {
            if (b.isExploded()) continue;
            for (int i = 0; i < currentLevel.getEnemies().size(); i++) {
                Enemy e = currentLevel.getEnemies().get(i);
                if (b.getBounds().intersects(e.getBounds())) {
                    b.explode();
                    currentLevel.getEnemies().remove(i);
                    return;
                }
            }
        }
    }

    public void setPlayer1(Player p) { this.player1 = p; }
    public void setPlayer2(Player p) { this.player2 = p; }
    public Player getPlayer()        { return player1; }
    public Player getPlayer2()       { return player2; }
    public Level  getCurrentLevel()  { return currentLevel; }
}
