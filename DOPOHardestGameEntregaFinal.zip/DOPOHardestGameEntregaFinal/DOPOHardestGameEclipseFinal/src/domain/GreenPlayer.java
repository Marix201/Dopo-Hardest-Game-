package domain;
import java.awt.*;

/**
 * Jugador verde — variante resistente con escudo propio incorporado.
 */
public class GreenPlayer extends Player{
    private boolean ownShield   = true;
    private int     invincible  = 0;
    private static final int INVINCIBLE_TICKS = 60;

    public GreenPlayer(int x, int y) { super(x, y, 20, 3); }

    @Override
    public void receiveHit(){
        if (invincible > 0) return;
        if (shield) { consumeShield(); invincible = INVINCIBLE_TICKS; return; }
        if (ownShield) { ownShield = false; speed = 2; invincible = INVINCIBLE_TICKS; return; }
        die();
    }

    @Override
    public void move(){
        super.move();
        if (invincible > 0) invincible--;
    }

    @Override
    public void reset(int startX, int startY){
        super.reset(startX, startY);
        ownShield  = true;
        speed      = 3;
        invincible = 0;
    }

    public boolean hasOwnShield(){ 
    	return ownShield; 
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (invincible > 0 && (invincible / 5) % 2 == 0) return;
        g2.setColor(new Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 5, 5);
        Color top = ownShield ? new Color(80, 255, 100) : new Color(40, 160, 60);
        Color bot = ownShield ? new Color(20, 180, 50)  : new Color(10, 90, 30);
        g2.setPaint(new GradientPaint(x, y, top, x + width, y + height, bot));
        g2.fillRoundRect(x, y, width, height, 5, 5);
        if (ownShield) {
            g2.setColor(new Color(200, 255, 200, 100));
            g2.setStroke(new BasicStroke(3f));
            g2.drawRoundRect(x - 2, y - 2, width + 4, height + 4, 7, 7);
        }
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
        drawTag(g2);
        drawShield(g2);
    }
}