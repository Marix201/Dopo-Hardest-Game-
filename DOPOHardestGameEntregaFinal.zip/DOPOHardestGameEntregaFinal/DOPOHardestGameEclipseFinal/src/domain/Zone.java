package domain;
import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 * Zona especial del mapa con comportamiento según tipo.
 */
public class Zone extends GameElement {
    public enum ZoneType { START, INTERMEDIATE, GOAL }
    private final ZoneType type;

    public Zone(int x, int y, int width, int height, ZoneType type) {
        super(x, y, width, height);
        this.type = type;
    }

    /** 
     * El jugador está completamente dentro de la zona
     */
    public boolean contains(Player p) {
        return new Rectangle2D.Float(x, y, width, height)
               .contains(new Rectangle2D.Float(p.getX(), p.getY(), p.getWidth(), p.getHeight()));
    }

    /** 
     * El jugador toca la zona (para checkpoints) 
     */
    public boolean intersects(Player p) {
        return getBounds().intersects(p.getBounds());
    }

    public ZoneType getType() { return type; }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        Color top, bot, border;
        String label;
        switch (type) {
            case START:
                top = new Color(120, 220, 120); bot = new Color(80, 170, 80);
                border = new Color(40, 120, 40);  label = "START"; break;
            case INTERMEDIATE:
                top = new Color(120, 210, 255); bot = new Color(60, 140, 220);
                border = new Color(20, 80, 180);  label = "CHECK"; break;
            default: // GOAL
                top = new Color(255, 220, 80); bot = new Color(200, 150, 0);
                border = new Color(140, 90, 0);   label = "GOAL"; break;
        }
        
        GradientPaint gp = new GradientPaint(x, y, top, x + width, y + height, bot);
        g2.setPaint(gp);
        g2.fillRect(x, y, width, height);
        g2.setColor(border);
        g2.setStroke(new BasicStroke(2));
        g2.drawRect(x, y, width, height);
        g2.setColor(new Color(20, 60, 20));
        g2.setFont(new Font("Arial", Font.BOLD, 10));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(label, x + (width - fm.stringWidth(label)) / 2, y + height / 2 + 4);
    }
}