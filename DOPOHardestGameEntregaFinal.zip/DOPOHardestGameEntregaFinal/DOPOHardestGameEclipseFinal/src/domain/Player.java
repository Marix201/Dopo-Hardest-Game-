package domain;
import java.awt.*;

public abstract class Player extends GameElement {
    protected int dx, dy;
    protected boolean alive;
    protected int deaths;
    protected int speed;
    protected Color borderColor;
    protected boolean shield = false; // escudo de fuente de vida
    protected String playerTag = null; // "J1", "J2", "IA1", "IA2"
    protected int shieldInvincibleTicks = 0;
    protected static final int SHIELD_INVINCIBLE_DURATION = 15;

    public Player(int x, int y, int size, int speed) {
        super(x, y, size, size);
        this.speed = speed;
        this.alive = true;
        this.deaths = 0;
        this.borderColor = Color.WHITE;
    }

    public void move() {
        x += dx;
        y += dy;

        if (shieldInvincibleTicks > 0) {
            shieldInvincibleTicks--;
        }
    }

    public void setDirection(int dx, int dy) {
        this.dx = dx * speed;
        this.dy = dy * speed;
    }

    public abstract void receiveHit();

    public void die() {
        deaths++;
        alive  = false;
        shield = false; // escudo se pierde al morir
        dx = 0; dy = 0;
    }

    public void reset(int startX, int startY) {
        x     = startX;
        y     = startY;
        dx    = 0; dy = 0;
        alive = true;
        shield = false;
    }

    /** 
     * Da el escudo de fuente de vida 
     */
    public void grantShield(){ 
    	shield = true; 
    }
    
    /** 
     * Quita el escudo 
     */
    public void consumeShield(){
        shield = false;
        shieldInvincibleTicks = SHIELD_INVINCIBLE_DURATION;
    }
    
    public boolean hasShield(){ 
    	return shield; 
    }
    
    public boolean isShieldInvincible() {
        return shieldInvincibleTicks > 0;
    }

    /** 
     * Dibuja el escudo encima del jugador  
     */
    protected void drawShield(Graphics2D g2) {
        if (!shield) return;
        
        // Halo pulsante azul-cian alrededor del jugador
        float alpha = 160;
        g2.setColor(new Color(80, 200, 255, (int) alpha));
        g2.setStroke(new BasicStroke(3f));
        g2.drawRoundRect(x - 4, y - 4, width + 8, height + 8, 10, 10);

        g2.setColor(new Color(150, 230, 255, 50));
        g2.fillRoundRect(x - 4, y - 4, width + 8, height + 8, 10, 10);

        // Icono "+" pequeño en la esquina superior derecha
        g2.setColor(new Color(255, 255, 255, 200));
        g2.setStroke(new BasicStroke(1.5f));
        int sx = x + width - 3, sy = y - 5;
        g2.drawLine(sx, sy - 3, sx, sy + 3);
        g2.drawLine(sx - 3, sy, sx + 3, sy);
    }

    public boolean isAlive(){ 
    	return alive; 
    }
    
    public int getDeaths(){ 
    	return deaths; 
    }
    
    public void setBorderColor(Color c) { 
    	this.borderColor = c; 
    }
    
    public Color getBorderColor(){
    	return borderColor; 
    }
    
    /** 
     * Las subclases IA sobreescriben este método para calcular su movimiento. 
     */
    public void computeAIMove() { /* no-op para jugadores humanos */ }
    
    public void setPlayerTag(String tag){ 
    	this.playerTag = tag; 
    }
    
    public String getPlayerTag(){ 
    	return playerTag; 
    }

    protected void drawTag(Graphics2D g2) {
        if (playerTag == null) return;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Color de fondo según jugador
        Color bgColor;
        Color fgColor = Color.WHITE;
        switch (playerTag) {
            case "J1":  bgColor = new Color(220, 60,  60,  220); break; // rojo
            case "J2":  bgColor = new Color(30,  100, 220, 220); break; // azul
            case "IA1": bgColor = new Color(160, 30,  200, 220); break; // morado
            case "IA":  bgColor = new Color(30,  160, 200, 220); break; // cian
            default:    bgColor = new Color(40,  40,  40,  200);
        }

        // Etiqueta encima del jugador
        g2.setFont(new Font("Arial", Font.BOLD, 9));
        FontMetrics fm = g2.getFontMetrics();
        int tw = fm.stringWidth(playerTag) + 6;
        int th = 12;
        int tx = x + width / 2 - tw / 2;
        int ty = y - th - 3;

        // Fondo coloreado con borde
        g2.setColor(bgColor);
        g2.fillRoundRect(tx, ty, tw, th, 5, 5);
        g2.setColor(fgColor);
        g2.setStroke(new BasicStroke(1f));
        g2.drawRoundRect(tx, ty, tw, th, 5, 5);

        // Texto
        g2.setColor(fgColor);
        g2.drawString(playerTag, tx + 3, ty + th - 2);

        // Flecha indicadora debajo del nombre (apunta al jugador)
        g2.setColor(bgColor);
        int ax = x + width / 2;
        int ay = y - 2;
        g2.fillPolygon(new int[]{ax-4, ax+4, ax}, new int[]{ay-4, ay-4, ay+1}, 3);
    }
    
    public int getSpeed(){ 
    	return speed; 
    }
    
    /**
     *  Crea una versión transformada del jugador con el skin dado. 
     */
    /** Retorna true si este jugador es controlado por IA. Sobreescribir en MachinePlayer. */
    public boolean isMachinePlayer() { return false; }

    public Player createTransformed(String skinType, int x, int y, Level level) {
        switch(skinType){
            case "BLUE": return new BluePlayer(x, y);
            case "GREEN": return new GreenPlayer(x, y);
            default: return new RedPlayer(x, y);
        }
    }
}