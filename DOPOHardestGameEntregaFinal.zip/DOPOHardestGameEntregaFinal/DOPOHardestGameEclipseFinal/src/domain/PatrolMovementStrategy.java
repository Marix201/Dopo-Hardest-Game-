package domain;

/**
 * Estrategia de movimiento en patrulla rectangular.
 */
public class PatrolMovementStrategy implements MovementStrategy {

    private int speed;
    private int step = 0;

    public PatrolMovementStrategy(int speed) {
        this.speed = speed;
    }

    @Override
    public void move(Enemy enemy) {

        step++;

        // Derecha
        if (step < 60) {
            enemy.setX(enemy.getX() + speed);
        }

        // Abajo
        else if (step < 120) {
            enemy.setY(enemy.getY() + speed);
        }

        // Izquierda
        else if (step < 180) {
            enemy.setX(enemy.getX() - speed);
        }

        // Arriba
        else if (step < 240) {
            enemy.setY(enemy.getY() - speed);
        }

        else {
            step = 0;
        }
    }

    @Override
    public void reverseX() {
        speed = -speed;
    }

    @Override
    public void reverseY() {
        speed = -speed;
    }
}