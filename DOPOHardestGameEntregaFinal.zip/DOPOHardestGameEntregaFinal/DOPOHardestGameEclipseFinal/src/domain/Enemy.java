package domain;
import java.awt.*;

/**
 * Enemigo del juego — obstáculo móvil que mata al jugador al contacto.
 */
public class Enemy extends GameElement {
    private MovementStrategy movementStrategy;

    public Enemy(int x, int y, MovementStrategy movementStrategy) {
        super(x, y, 20, 20);
        this.movementStrategy = movementStrategy;
    }

    public void move(){ 
    	movementStrategy.move(this); 
    }
    
    public void reverseX() { 
    	movementStrategy.reverseX(); 
    }
    
    public void reverseY() { 
    	movementStrategy.reverseY(); 
    }

    public void setMovementStrategy(MovementStrategy s){ 
    	this.movementStrategy = s; 
    }

    public boolean collidesWithPlayer(Player p) {
        return getBounds().intersects(p.getBounds());
    }
    
    protected boolean alive = true;

    public boolean isAlive() {
        return alive;
    }

    public void destroy() {
        alive = false;
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 60));
        g2.fillOval(x + 3, y + 3, width, height);
        GradientPaint gp = new GradientPaint(
            x, y,             new Color(80, 140, 255),
            x + width, y + height, new Color(20, 60, 200));
        g2.setPaint(gp);
        g2.fillOval(x, y, width, height);
        g2.setColor(new Color(255, 255, 255, 100));
        g2.fillOval(x + 4, y + 3, width / 3, height / 3);
        g2.setColor(new Color(10, 30, 150));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawOval(x, y, width, height);
    }
}
