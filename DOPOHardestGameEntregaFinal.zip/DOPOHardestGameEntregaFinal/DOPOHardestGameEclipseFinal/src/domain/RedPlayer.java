package domain;
import java.awt.*;

/**
 * Jugador rojo — variante estándar y equilibrada.
 */
public class RedPlayer extends Player {

    public RedPlayer(int x, int y) { 
    	super(x, y, 20, 3); 
    }

    @Override
    public void receiveHit(){
        if (isShieldInvincible()) return;
        if (shield) { consumeShield(); } else { die(); }
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 5, 5);
        GradientPaint gp = new GradientPaint(
            x, y, new Color(255, 80, 80),
            x + width, y + height, new Color(180, 20, 20));
        g2.setPaint(gp);
        g2.fillRoundRect(x, y, width, height, 5, 5);
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
        drawTag(g2);
        drawShield(g2);
    }
}