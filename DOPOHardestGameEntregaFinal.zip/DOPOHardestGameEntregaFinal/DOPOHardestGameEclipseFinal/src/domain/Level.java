package domain;
import java.awt.Rectangle;
import java.util.*;

/**
 * Representa un nivel completo del juego con todos sus elementos.
 */
public class Level {
    private final int number;
    private final int timeLimit;
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Wall> walls = new ArrayList<>();
    private final List<Coin> coins = new ArrayList<>();
    private Zone startZone, intermediateZone, goalZone;

    private final List<LifeSource> lifeSources = new ArrayList<>();
    private final List<Bomb> bombs = new ArrayList<>();

    // Zonas jugables para la IA
    private final List<Rectangle> playableZones = new ArrayList<>();


    public Level(int number, int timeLimit) {
        this.number    = number;
        this.timeLimit = timeLimit;
    }

    public void addEnemy(Enemy e){ 
    	enemies.add(e); 
    }
    
    public void addWall(Wall w){ 
    	walls.add(w); 
    }
    
    public void addCoin(Coin c){ 
    	coins.add(c); 
    }
    
    public void setStartZone(Zone z){ 
    	startZone = z; 
    }
    
    public void setIntermediateZone(Zone z){ 
    	intermediateZone = z; 
    }
    
    public void setGoalZone(Zone z){ 
    	goalZone = z; 
    }

    public boolean isComplete(Player p) {
        boolean allNormalCoins = coins.stream()
            .filter(c -> !c.isSkinCoin())
            .allMatch(Coin::isCollected);
        return allNormalCoins && goalZone != null && goalZone.contains(p);
    }

    public void reset() {
        coins.stream()
             .filter(c -> !c.isSkinCoin())
             .forEach(Coin::reset);
    }

    public int getNumber(){ 
    	return number; 
    }
    
    public int getTimeLimit(){ 
    	return timeLimit; 
    }
    
    public List<Enemy> getEnemies(){ 
    	return enemies; 
    }
    
    public List<Wall> getWalls(){ 
    	return walls; 
    }
    
    public List<Coin> getCoins(){ 
    	return coins; 
    }
    
    public Zone getStartZone(){ 
    	return startZone; 
    }
    
    public Zone getIntermediateZone(){ 
    	return intermediateZone; 
    }
    
    public Zone getGoalZone(){ 
    	return goalZone; 
    }
    
    public void addLifeSource(LifeSource ls){ 
    	lifeSources.add(ls); 
    }
    
    public void addBomb(Bomb b){ 
    	bombs.add(b); 
    }
    
    public List<LifeSource> getLifeSources(){
    	return lifeSources; 
    }
    public List<Bomb> getBombs(){ 
    	return bombs;
    }

    /** 
     * Registra un rectángulo donde el jugador/IA puede moverse 
     */
    public void addPlayableZone(int x, int y, int w, int h) {
        playableZones.add(new Rectangle(x, y, w, h));
    }

    /**
     * Devuelve true si el CENTRO del rectángulo dado está dentro de alguna zona jugable registrada 
     * (permite transiciones entre zonas). Si no hay zonas registradas, devuelve true (sin restricción).
     */
    public boolean isInsideBounds(Rectangle r) {
        if (playableZones.isEmpty()) return true;
        int cx = r.x + r.width  / 2;
        int cy = r.y + r.height / 2;
        for (Rectangle zone : playableZones) {
            if (zone.contains(cx, cy)) return true;
        }
        return false;
    }
}