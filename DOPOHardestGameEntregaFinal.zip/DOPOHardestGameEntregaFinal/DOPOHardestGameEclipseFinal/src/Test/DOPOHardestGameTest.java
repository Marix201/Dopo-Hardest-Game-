package Test;

import domain.*;
import domain.MachinePlayer.Profile;
import domain.Zone.ZoneType;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.*;
import java.util.List;

/**
 * Pruebas de aceptacion para The DOPO Hardest Game.
 */
public class DOPOHardestGameTest {

    private Level makeLevel() {
        LevelData ld = new LevelData();
        ld.number     = 1;
        ld.timeLimit  = 90;
        ld.layoutType = "STRAIGHT";
        ld.startZone  = new int[]{10, 60, 150, 280};
        ld.goalZone   = new int[]{460, 60, 150, 280};
        ld.spawn1     = new int[]{75, 190};
        ld.spawn2     = new int[]{495, 190};
        return LevelManager.buildLevel(ld);
    }

    private Level makeLevelWithCheckpoint() {
        LevelData ld = new LevelData();
        ld.number     = 1;
        ld.timeLimit  = 90;
        ld.layoutType = "STRAIGHT";
        ld.startZone  = new int[]{10, 60, 150, 280};
        ld.goalZone   = new int[]{460, 60, 150, 280};
        ld.checkZone  = new int[]{295, 60, 30, 280};
        ld.spawn1     = new int[]{75, 190};
        ld.spawn2     = new int[]{495, 190};
        return LevelManager.buildLevel(ld);
    }

    // 1. RedPlayer

    @Test
    public void redPlayer_initialState() {
        RedPlayer p = new RedPlayer(50, 100);
        assertEquals(50, p.getX());
        assertEquals(100, p.getY());
        assertEquals(20, p.getWidth());
        assertEquals(20, p.getHeight());
        assertEquals(3, p.getSpeed());
        assertTrue(p.isAlive());
        assertEquals(0, p.getDeaths());
        assertFalse(p.hasShield());
    }

    @Test
    public void redPlayer_dieIncrementsDeaths() {
        RedPlayer p = new RedPlayer(50, 100);
        p.die();
        assertFalse(p.isAlive());
        assertEquals(1, p.getDeaths());
    }

    @Test
    public void redPlayer_dieMultipleTimes() {
        RedPlayer p = new RedPlayer(50, 100);
        p.die(); p.reset(50, 100); p.die();
        assertEquals(2, p.getDeaths());
    }

    @Test
    public void redPlayer_resetRestoresAliveAndPosition() {
        RedPlayer p = new RedPlayer(50, 100);
        p.die();
        p.reset(200, 300);
        assertTrue(p.isAlive());
        assertEquals(200, p.getX());
        assertEquals(300, p.getY());
    }

    @Test
    public void redPlayer_reset_doesNotClearDeaths() {
        RedPlayer p = new RedPlayer(0, 0);
        p.die(); p.die();
        p.reset(0, 0);
        assertEquals(2, p.getDeaths());
    }

    @Test
    public void redPlayer_receiveHit_withoutShield_dies() {
        RedPlayer p = new RedPlayer(50, 100);
        p.receiveHit();
        assertFalse(p.isAlive());
        assertEquals(1, p.getDeaths());
    }

    @Test
    public void redPlayer_receiveHit_withShield_losesShieldNotLife() {
        RedPlayer p = new RedPlayer(50, 100);
        p.grantShield();
        assertTrue(p.hasShield());
        p.receiveHit();
        assertTrue(p.isAlive());
        assertFalse(p.hasShield());
    }

    @Test
    public void redPlayer_shieldInvincibilityAfterHit() {
        RedPlayer p = new RedPlayer(50, 100);
        p.grantShield();
        p.receiveHit(); // pierde escudo -> invencibilidad
        p.receiveHit(); // debe ignorarse
        assertTrue(p.isAlive());
    }

    @Test
    public void redPlayer_setDirection_movesCorrectly() {
        RedPlayer p = new RedPlayer(50, 100);
        p.setDirection(1, 0);
        p.move();
        assertEquals(53, p.getX());
        assertEquals(100, p.getY());
    }

    @Test
    public void redPlayer_move_diagonal() {
        RedPlayer p = new RedPlayer(50, 100);
        p.setDirection(1, 1);
        p.move();
        assertEquals(53, p.getX());
        assertEquals(103, p.getY());
    }

    @Test
    public void redPlayer_playerTag_nullByDefault() {
        RedPlayer p = new RedPlayer(0, 0);
        assertNull(p.getPlayerTag());
    }

    @Test
    public void redPlayer_playerTag_setAndGet() {
        RedPlayer p = new RedPlayer(0, 0);
        p.setPlayerTag("J1");
        assertEquals("J1", p.getPlayerTag());
    }

    @Test
    public void redPlayer_grantShield_thenDie_shieldLost() {
        RedPlayer p = new RedPlayer(0, 0);
        p.grantShield();
        p.die();
        assertFalse(p.hasShield());
    }

    @Test
    public void redPlayer_isNotMachinePlayer() {
        RedPlayer p = new RedPlayer(0, 0);
        assertFalse(p.isMachinePlayer());
    }

    @Test
    public void redPlayer_borderColor_setAndGet() {
        RedPlayer p = new RedPlayer(0, 0);
        p.setBorderColor(java.awt.Color.RED);
        assertEquals(java.awt.Color.RED, p.getBorderColor());
    }

    // 2. BluePlayer

    @Test
    public void bluePlayer_isBiggerAndFaster() {
        BluePlayer p = new BluePlayer(0, 0);
        assertEquals(28, p.getWidth());
        assertEquals(28, p.getHeight());
        assertEquals(4, p.getSpeed());
    }

    @Test
    public void bluePlayer_initiallyAlive() {
        BluePlayer p = new BluePlayer(10, 20);
        assertTrue(p.isAlive());
        assertEquals(0, p.getDeaths());
    }

    @Test
    public void bluePlayer_receiveHit_withoutShield_dies() {
        BluePlayer p = new BluePlayer(0, 0);
        p.receiveHit();
        assertFalse(p.isAlive());
    }

    @Test
    public void bluePlayer_receiveHit_withShield_survives() {
        BluePlayer p = new BluePlayer(0, 0);
        p.grantShield();
        p.receiveHit();
        assertTrue(p.isAlive());
        assertFalse(p.hasShield());
    }

    @Test
    public void bluePlayer_isNotMachinePlayer() {
        BluePlayer p = new BluePlayer(0, 0);
        assertFalse(p.isMachinePlayer());
    }

    @Test
    public void bluePlayer_movesAtHigherSpeed() {
        BluePlayer p = new BluePlayer(0, 0);
        p.setDirection(1, 0);
        p.move();
        assertEquals(4, p.getX());
    }

    // 3. GreenPlayer

    @Test
    public void greenPlayer_hasOwnShieldAtStart() {
        GreenPlayer p = new GreenPlayer(0, 0);
        assertTrue(p.hasOwnShield());
    }

    @Test
    public void greenPlayer_firstHit_losesOwnShield_notLife() {
        GreenPlayer p = new GreenPlayer(0, 0);
        p.receiveHit();
        assertTrue(p.isAlive());
        assertFalse(p.hasOwnShield());
    }

    @Test
    public void greenPlayer_speedReducedAfterOwnShieldLost() {
        GreenPlayer p = new GreenPlayer(0, 0);
        p.receiveHit();
        assertEquals(2, p.getSpeed());
    }

    @Test
    public void greenPlayer_secondHit_afterInvincibility_dies() {
        GreenPlayer p = new GreenPlayer(0, 0);
        p.receiveHit();
        for (int i = 0; i < 65; i++) p.move();
        p.receiveHit();
        assertFalse(p.isAlive());
    }

    @Test
    public void greenPlayer_hitDuringInvincibility_ignored() {
        GreenPlayer p = new GreenPlayer(0, 0);
        p.receiveHit();
        p.receiveHit(); // ignorado
        assertTrue(p.isAlive());
    }

    @Test
    public void greenPlayer_reset_restoresOwnShieldAndSpeed() {
        GreenPlayer p = new GreenPlayer(0, 0);
        p.receiveHit();
        p.reset(0, 0);
        assertTrue(p.hasOwnShield());
        assertEquals(3, p.getSpeed());
    }

    @Test
    public void greenPlayer_externalShield_takesHitFirst() {
        GreenPlayer p = new GreenPlayer(0, 0);
        p.grantShield();
        p.receiveHit();
        assertTrue(p.isAlive());
        assertFalse(p.hasShield());
        assertTrue(p.hasOwnShield());
    }

    @Test
    public void greenPlayer_isNotMachinePlayer() {
        GreenPlayer p = new GreenPlayer(0, 0);
        assertFalse(p.isMachinePlayer());
    }

    // 4. Coin y SkinCoin

    @Test
    public void coin_initiallyNotCollected() {
        Coin c = new Coin(100, 200);
        assertFalse(c.isCollected());
        assertFalse(c.isSkinCoin());
    }

    @Test
    public void coin_collect() {
        Coin c = new Coin(100, 200);
        c.collect();
        assertTrue(c.isCollected());
    }

    @Test
    public void coin_reset_afterCollect() {
        Coin c = new Coin(100, 200);
        c.collect();
        c.reset();
        assertFalse(c.isCollected());
    }

    @Test
    public void coin_position() {
        Coin c = new Coin(150, 250);
        assertEquals(150, c.getX());
        assertEquals(250, c.getY());
    }

    @Test
    public void skinCoin_isSkinCoin() {
        SkinCoin sc = new SkinCoin(50, 50, "BLUE");
        assertTrue(sc.isSkinCoin());
        assertEquals("BLUE", sc.getSkinType());
    }

    @Test
    public void skinCoin_typesRED() {
        assertEquals("RED", new SkinCoin(0, 0, "RED").getSkinType());
    }

    @Test
    public void skinCoin_typesGREEN() {
        assertEquals("GREEN", new SkinCoin(0, 0, "GREEN").getSkinType());
    }

    @Test
    public void skinCoin_typesBLUE() {
        assertEquals("BLUE", new SkinCoin(0, 0, "BLUE").getSkinType());
    }

    @Test
    public void skinCoin_collect_isCollected() {
        SkinCoin sc = new SkinCoin(0, 0, "BLUE");
        sc.collect();
        assertTrue(sc.isCollected());
    }

    @Test
    public void skinCoin_reset_uncollects() {
        SkinCoin sc = new SkinCoin(0, 0, "RED");
        sc.collect();
        sc.reset();
        assertFalse(sc.isCollected());
    }

    // 5. Enemy

    @Test
    public void enemy_movesWithLinearStrategy() {
        Enemy e = new Enemy(100, 100, new LinearMovementStrategy(2, 0));
        e.move();
        assertEquals(102, e.getX());
        assertEquals(100, e.getY());
    }

    @Test
    public void enemy_reverseX() {
        Enemy e = new Enemy(100, 100, new LinearMovementStrategy(2, 0));
        e.reverseX();
        e.move();
        assertEquals(98, e.getX());
    }

    @Test
    public void enemy_reverseY() {
        Enemy e = new Enemy(100, 100, new LinearMovementStrategy(0, 3));
        e.reverseY();
        e.move();
        assertEquals(97, e.getY());
    }

    @Test
    public void enemy_aliveByDefault() {
        Enemy e = new Enemy(0, 0, new LinearMovementStrategy(1, 0));
        assertTrue(e.isAlive());
    }

    @Test
    public void enemy_destroy() {
        Enemy e = new Enemy(0, 0, new LinearMovementStrategy(1, 0));
        e.destroy();
        assertFalse(e.isAlive());
    }

    @Test
    public void enemy_collidesWithPlayer_whenOverlapping() {
        Enemy en = new Enemy(50, 50, new LinearMovementStrategy(0, 0));
        RedPlayer p = new RedPlayer(50, 50);
        assertTrue(en.collidesWithPlayer(p));
    }

    @Test
    public void enemy_noCollision_whenFarApart() {
        Enemy en = new Enemy(200, 200, new LinearMovementStrategy(0, 0));
        RedPlayer p = new RedPlayer(50, 50);
        assertFalse(en.collidesWithPlayer(p));
    }

    @Test
    public void enemy_setMovementStrategy_changesMovement() {
        Enemy e = new Enemy(100, 100, new LinearMovementStrategy(2, 0));
        e.setMovementStrategy(new LinearMovementStrategy(0, 3));
        e.move();
        assertEquals(100, e.getX());
        assertEquals(103, e.getY());
    }

    @Test
    public void diagonalStrategy_movesInBothAxes() {
        Enemy e = new Enemy(100, 100, new DiagonalMovementStrategy(2, 3));
        e.move();
        assertEquals(102, e.getX());
        assertEquals(103, e.getY());
    }

    @Test
    public void diagonalStrategy_reverseX() {
        DiagonalMovementStrategy s = new DiagonalMovementStrategy(2, 3);
        Enemy e = new Enemy(100, 100, s);
        s.reverseX();
        e.move();
        assertEquals(98, e.getX());
        assertEquals(103, e.getY());
    }

    @Test
    public void linearStrategy_reverseX_changesDirection() {
        LinearMovementStrategy s = new LinearMovementStrategy(2, 0);
        Enemy e = new Enemy(100, 100, s);
        s.reverseX();
        e.move();
        assertEquals(98, e.getX());
    }

    @Test
    public void linearStrategy_reverseY_changesDirection() {
        LinearMovementStrategy s = new LinearMovementStrategy(0, 2);
        Enemy e = new Enemy(100, 100, s);
        s.reverseY();
        e.move();
        assertEquals(98, e.getY());
    }

    @Test
    public void linearStrategy_movesHorizontally_multipleSteps() {
        Enemy e = new Enemy(100, 100, new LinearMovementStrategy(3, 0));
        e.move(); e.move();
        assertEquals(106, e.getX());
        assertEquals(100, e.getY());
    }

    // 6. Zone

    @Test
    public void zone_contains_playerFullyInside() {
        Zone z = new Zone(10, 60, 150, 280, ZoneType.START);
        RedPlayer p = new RedPlayer(50, 100);
        assertTrue(z.contains(p));
    }

    @Test
    public void zone_doesNotContain_playerOutside() {
        Zone z = new Zone(10, 60, 150, 280, ZoneType.START);
        RedPlayer p = new RedPlayer(300, 300);
        assertFalse(z.contains(p));
    }

    @Test
    public void zone_intersects_playerPartiallyInside() {
        Zone z = new Zone(100, 100, 100, 100, ZoneType.INTERMEDIATE);
        RedPlayer p = new RedPlayer(95, 100);
        assertTrue(z.intersects(p));
    }

    @Test
    public void zone_typeGoal() {
        assertEquals(ZoneType.GOAL, new Zone(0, 0, 10, 10, ZoneType.GOAL).getType());
    }

    @Test
    public void zone_typeIntermediate() {
        assertEquals(ZoneType.INTERMEDIATE, new Zone(0, 0, 10, 10, ZoneType.INTERMEDIATE).getType());
    }

    @Test
    public void zone_typeStart() {
        assertEquals(ZoneType.START, new Zone(0, 0, 10, 10, ZoneType.START).getType());
    }

    @Test
    public void zone_dimensions() {
        Zone z = new Zone(5, 10, 200, 100, ZoneType.GOAL);
        assertEquals(5, z.getX());
        assertEquals(10, z.getY());
        assertEquals(200, z.getWidth());
        assertEquals(100, z.getHeight());
    }

    // 7. Level

    @Test
    public void level_metadata() {
        Level lvl = makeLevel();
        assertEquals(1, lvl.getNumber());
        assertEquals(90, lvl.getTimeLimit());
    }

    @Test
    public void level_addAndGetEnemies() {
        Level lvl = makeLevel();
        lvl.addEnemy(new Enemy(100, 100, new LinearMovementStrategy(1, 0)));
        assertEquals(1, lvl.getEnemies().size());
    }

    @Test
    public void level_addAndGetCoins() {
        Level lvl = makeLevel();
        lvl.addCoin(new Coin(200, 190));
        assertEquals(1, lvl.getCoins().size());
    }

    @Test
    public void level_isComplete_requiresAllCoinsAndGoal() {
        Level lvl = makeLevel();
        lvl.addCoin(new Coin(200, 190));
        RedPlayer p = new RedPlayer(500, 190);
        assertFalse(lvl.isComplete(p));
        lvl.getCoins().get(0).collect();
        assertTrue(lvl.isComplete(p));
    }

    @Test
    public void level_isComplete_falseIfNotInGoal() {
        Level lvl = makeLevel();
        lvl.addCoin(new Coin(200, 190));
        lvl.getCoins().get(0).collect();
        RedPlayer p = new RedPlayer(50, 190);
        assertFalse(lvl.isComplete(p));
    }

    @Test
    public void level_reset_uncollectsNormalCoins() {
        Level lvl = makeLevel();
        Coin c = new Coin(200, 190);
        lvl.addCoin(c);
        c.collect();
        lvl.reset();
        assertFalse(c.isCollected());
    }

    @Test
    public void level_reset_doesNotUncollectSkinCoins() {
        Level lvl = makeLevel();
        SkinCoin sc = new SkinCoin(200, 190, "BLUE");
        lvl.addCoin(sc);
        sc.collect();
        lvl.reset();
        assertTrue(sc.isCollected());
    }

    @Test
    public void level_zones_setAndGet() {
        Level lvl = makeLevel();
        assertNotNull(lvl.getStartZone());
        assertNotNull(lvl.getGoalZone());
        assertNull(lvl.getIntermediateZone());
    }

    @Test
    public void level_withCheckpoint() {
        Level lvl = makeLevelWithCheckpoint();
        assertNotNull(lvl.getIntermediateZone());
    }

    @Test
    public void level_addMultipleEnemies() {
        Level lvl = makeLevel();
        lvl.addEnemy(new Enemy(100, 100, new LinearMovementStrategy(1, 0)));
        lvl.addEnemy(new Enemy(200, 100, new LinearMovementStrategy(-1, 0)));
        assertEquals(2, lvl.getEnemies().size());
    }

    @Test
    public void level_isInsideBounds_noZones_alwaysTrue() {
        Level lvl = new Level(1, 60);
        assertTrue(lvl.isInsideBounds(new java.awt.Rectangle(0, 0, 20, 20)));
    }

    @Test
    public void level_isInsideBounds_withZone_insideReturnsTrue() {
        Level lvl = new Level(1, 60);
        lvl.addPlayableZone(0, 0, 400, 400);
        assertTrue(lvl.isInsideBounds(new java.awt.Rectangle(100, 100, 20, 20)));
    }

    @Test
    public void level_isInsideBounds_withZone_outsideReturnsFalse() {
        Level lvl = new Level(1, 60);
        lvl.addPlayableZone(0, 0, 100, 100);
        assertFalse(lvl.isInsideBounds(new java.awt.Rectangle(500, 500, 20, 20)));
    }

    // 8. Bomb

    @Test
    public void bomb_notExplodedInitially() {
        Bomb b = new Bomb(100, 100);
        assertFalse(b.isExploded());
    }

    @Test
    public void bomb_explode() {
        Bomb b = new Bomb(100, 100);
        b.explode();
        assertTrue(b.isExploded());
    }

    @Test
    public void bomb_killsPlayer_onContact() {
        Level lvl = makeLevel();
        Bomb bomb = new Bomb(200, 190);
        lvl.addBomb(bomb);
        RedPlayer p = new RedPlayer(200, 190);
        GameEngine engine = new GameEngine(p, lvl);
        bomb.checkCollision(engine);
        assertFalse(p.isAlive());
        assertTrue(bomb.isExploded());
    }

    @Test
    public void bomb_doesNotKillPlayer_whenExploded() {
        Level lvl = makeLevel();
        Bomb bomb = new Bomb(200, 190);
        bomb.explode();
        lvl.addBomb(bomb);
        RedPlayer p = new RedPlayer(200, 190);
        GameEngine engine = new GameEngine(p, lvl);
        bomb.checkCollision(engine);
        assertTrue(p.isAlive());
    }

    @Test
    public void bomb_destroysEnemy_onContact() {
        Level lvl = makeLevel();
        Enemy en = new Enemy(100, 100, new LinearMovementStrategy(0, 0));
        lvl.addEnemy(en);
        Bomb bomb = new Bomb(100, 100);
        lvl.addBomb(bomb);
        RedPlayer p = new RedPlayer(500, 500);
        GameEngine engine = new GameEngine(p, lvl);
        bomb.checkCollision(engine);
        assertFalse(en.isAlive());
        assertTrue(bomb.isExploded());
    }

    @Test
    public void bomb_doesNotExplode_whenPlayerFarAway() {
        Level lvl = makeLevel();
        Bomb bomb = new Bomb(100, 100);
        lvl.addBomb(bomb);
        RedPlayer p = new RedPlayer(500, 500);
        GameEngine engine = new GameEngine(p, lvl);
        bomb.checkCollision(engine);
        assertFalse(bomb.isExploded());
    }

    // 9. LifeSource

    @Test
    public void lifeSource_notUsedInitially() {
        LifeSource ls = new LifeSource(100, 100);
        assertFalse(ls.isUsed());
    }

    @Test
    public void lifeSource_use() {
        LifeSource ls = new LifeSource(100, 100);
        ls.use();
        assertTrue(ls.isUsed());
    }

    @Test
    public void lifeSource_grantsShieldViaEngine() {
        Level lvl = makeLevel();
        lvl.addLifeSource(new LifeSource(75, 190));
        RedPlayer p = new RedPlayer(75, 190);
        GameEngine engine = new GameEngine(p, lvl);
        engine.update();
        assertTrue(p.hasShield());
    }

    @Test
    public void lifeSource_usedOnce_doesNotGrantShieldAgain() {
        Level lvl = makeLevel();
        LifeSource ls = new LifeSource(75, 190);
        lvl.addLifeSource(ls);
        RedPlayer p = new RedPlayer(75, 190);
        GameEngine engine = new GameEngine(p, lvl);
        engine.update();
        assertTrue(ls.isUsed());
        p.consumeShield();
        engine.update();
        assertFalse(p.hasShield()); // no vuelve a dar escudo
    }

    // 10. GameEngine

    @Test
    public void engine_enemyKillsPlayer_outsideSafeZone() {
        Level lvl = makeLevel();
        lvl.addEnemy(new Enemy(200, 190, new LinearMovementStrategy(0, 0)));
        RedPlayer p = new RedPlayer(200, 190);
        GameEngine engine = new GameEngine(p, lvl);
        engine.update();
        assertFalse(p.isAlive());
    }

    @Test
    public void engine_enemyDoesNotKillPlayer_inStartZone() {
        Level lvl = makeLevel();
        lvl.addEnemy(new Enemy(50, 190, new LinearMovementStrategy(0, 0)));
        RedPlayer p = new RedPlayer(50, 190);
        GameEngine engine = new GameEngine(p, lvl);
        engine.update();
        assertTrue(p.isAlive());
    }

    @Test
    public void engine_enemyDoesNotKillPlayer_inGoalZone() {
        Level lvl = makeLevel();
        lvl.addEnemy(new Enemy(490, 190, new LinearMovementStrategy(0, 0)));
        RedPlayer p = new RedPlayer(490, 190);
        GameEngine engine = new GameEngine(p, lvl);
        engine.update();
        assertTrue(p.isAlive());
    }

    @Test
    public void engine_enemyDoesNotKillPlayer_inCheckpoint() {
        Level lvl = makeLevelWithCheckpoint();
        lvl.addEnemy(new Enemy(295, 190, new LinearMovementStrategy(0, 0)));
        RedPlayer p = new RedPlayer(295, 190);
        GameEngine engine = new GameEngine(p, lvl);
        engine.update();
        assertTrue(p.isAlive());
    }

    @Test
    public void engine_twoPlayers_collisionCausesDeathToBoth() {
        Level lvl = makeLevel();
        RedPlayer p1 = new RedPlayer(200, 190);
        RedPlayer p2 = new RedPlayer(200, 190);
        GameEngine engine = new GameEngine(p1, p2, lvl);
        engine.update();
        assertFalse(p1.isAlive());
        assertFalse(p2.isAlive());
    }

    @Test
    public void engine_getPlayer_returnsP1() {
        Level lvl = makeLevel();
        RedPlayer p1 = new RedPlayer(50, 190);
        GameEngine engine = new GameEngine(p1, lvl);
        assertSame(p1, engine.getPlayer());
    }

    @Test
    public void engine_getPlayer2_returnsNullInSingleMode() {
        Level lvl = makeLevel();
        GameEngine engine = new GameEngine(new RedPlayer(50, 190), lvl);
        assertNull(engine.getPlayer2());
    }

    @Test
    public void engine_setPlayer1_replacesPlayer() {
        Level lvl = makeLevel();
        RedPlayer old = new RedPlayer(50, 190);
        GameEngine engine = new GameEngine(old, lvl);
        RedPlayer next = new RedPlayer(75, 190);
        engine.setPlayer1(next);
        assertSame(next, engine.getPlayer());
    }

    @Test
    public void engine_setPlayer2_replacesPlayer() {
        Level lvl = makeLevel();
        RedPlayer p1 = new RedPlayer(50, 190);
        RedPlayer p2 = new RedPlayer(490, 190);
        GameEngine engine = new GameEngine(p1, p2, lvl);
        RedPlayer p2new = new RedPlayer(480, 190);
        engine.setPlayer2(p2new);
        assertSame(p2new, engine.getPlayer2());
    }

    @Test
    public void engine_getCurrentLevel_returnsLevel() {
        Level lvl = makeLevel();
        GameEngine engine = new GameEngine(new RedPlayer(50, 190), lvl);
        assertSame(lvl, engine.getCurrentLevel());
    }

    // 11. MachinePlayer

    @Test
    public void machinePlayer_profile_aleatoria() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.ALEATORIA, lvl);
        assertEquals(Profile.ALEATORIA, mp.getProfile());
    }

    @Test
    public void machinePlayer_profile_experta() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.EXPERTA, lvl);
        assertEquals(Profile.EXPERTA, mp.getProfile());
    }

    @Test
    public void machinePlayer_isMachinePlayer_true() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.ALEATORIA, lvl);
        assertTrue(mp.isMachinePlayer());
    }

    @Test
    public void machinePlayer_computeAIMove_doesNotThrow() {
        Level lvl = makeLevel();
        lvl.addCoin(new Coin(200, 190));
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.EXPERTA, lvl);
        mp.computeAIMove();
    }

    @Test
    public void machinePlayer_aleatoria_multipleTicksNoException() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.ALEATORIA, lvl);
        for (int i = 0; i < 50; i++) mp.computeAIMove();
    }

    @Test
    public void machinePlayer_experta_movesTowardCoin() {
        Level lvl = makeLevel();
        lvl.addPlayableZone(0, 0, 640, 480);
        Coin c = new Coin(300, 190);
        lvl.addCoin(c);
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.EXPERTA, lvl);
        int initialX = mp.getX();
        for (int i = 0; i < 10; i++) { mp.computeAIMove(); mp.move(); }
        assertTrue(mp.getX() > initialX);
    }

    @Test
    public void machinePlayer_skinType_default_RED() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(0, 0, Profile.ALEATORIA, lvl);
        assertEquals("RED", mp.getSkinType());
    }

    @Test
    public void machinePlayer_skinType_custom() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(0, 0, Profile.EXPERTA, lvl, "BLUE");
        assertEquals("BLUE", mp.getSkinType());
    }

    @Test
    public void machinePlayer_createTransformed_isMachinePlayer() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(0, 0, Profile.EXPERTA, lvl, "RED");
        Player transformed = mp.createTransformed("GREEN", 50, 50, lvl);
        assertTrue(transformed.isMachinePlayer());
    }

    @Test
    public void machinePlayer_createTransformed_skinType() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(0, 0, Profile.EXPERTA, lvl, "RED");
        Player transformed = mp.createTransformed("GREEN", 50, 50, lvl);
        assertEquals("GREEN", ((MachinePlayer) transformed).getSkinType());
    }

    @Test
    public void machinePlayer_createTransformed_preservesProfile() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(0, 0, Profile.EXPERTA, lvl, "RED");
        Player transformed = mp.createTransformed("BLUE", 0, 0, lvl);
        assertEquals(Profile.EXPERTA, ((MachinePlayer) transformed).getProfile());
    }

    // 12. LevelData

    @Test
    public void levelData_defaultValues() {
        LevelData ld = new LevelData();
        assertEquals("Sin nombre", ld.name);
        assertEquals(1, ld.number);
        assertEquals(60, ld.timeLimit);
        assertEquals("STRAIGHT", ld.layoutType);
        assertNotNull(ld.enemies);
        assertNotNull(ld.coins);
        assertNotNull(ld.lifeSources);
        assertNotNull(ld.bombs);
    }

    @Test
    public void levelData_enemyData_constructor() {
        LevelData.EnemyData ed = new LevelData.EnemyData("LINEAR", 100, 200, 2, 0);
        assertEquals("LINEAR", ed.type);
        assertEquals(100, ed.x);
        assertEquals(200, ed.y);
        assertEquals(2, ed.dx);
        assertEquals(0, ed.dy);
    }

    @Test
    public void levelData_coinData_constructor() {
        LevelData.CoinData cd = new LevelData.CoinData("YELLOW", 150, 190);
        assertEquals("YELLOW", cd.type);
        assertEquals(150, cd.x);
        assertEquals(190, cd.y);
    }

    @Test
    public void levelData_lifeSourceData_constructor() {
        LevelData.LifeSourceData ls = new LevelData.LifeSourceData(200, 190);
        assertEquals(200, ls.x);
        assertEquals(190, ls.y);
    }

    @Test
    public void levelData_bombData_constructor() {
        LevelData.BombData bd = new LevelData.BombData(300, 190);
        assertEquals(300, bd.x);
        assertEquals(190, bd.y);
    }

    // 13. LevelManager — buildLevel

    @Test
    public void levelManager_buildLevel_zonesCreated() {
        Level lvl = makeLevel();
        assertNotNull(lvl.getStartZone());
        assertNotNull(lvl.getGoalZone());
        assertEquals(ZoneType.START, lvl.getStartZone().getType());
        assertEquals(ZoneType.GOAL,  lvl.getGoalZone().getType());
    }

    @Test
    public void levelManager_buildLevel_enemiesCreated() {
        LevelData ld = new LevelData();
        ld.startZone = new int[]{10, 60, 150, 280};
        ld.goalZone  = new int[]{460, 60, 150, 280};
        ld.spawn1 = new int[]{75, 190};
        ld.spawn2 = new int[]{495, 190};
        ld.enemies.add(new LevelData.EnemyData("LINEAR",   200, 190, 2, 0));
        ld.enemies.add(new LevelData.EnemyData("DIAGONAL", 250, 190, 1, 1));
        Level lvl = LevelManager.buildLevel(ld);
        assertEquals(2, lvl.getEnemies().size());
    }

    @Test
    public void levelManager_buildLevel_coinsCreated() {
        LevelData ld = new LevelData();
        ld.startZone = new int[]{10, 60, 150, 280};
        ld.goalZone  = new int[]{460, 60, 150, 280};
        ld.spawn1 = new int[]{75, 190};
        ld.spawn2 = new int[]{495, 190};
        ld.coins.add(new LevelData.CoinData("YELLOW", 200, 190));
        ld.coins.add(new LevelData.CoinData("BLUE",   300, 190));
        ld.coins.add(new LevelData.CoinData("GREEN",  350, 190));
        Level lvl = LevelManager.buildLevel(ld);
        assertEquals(3, lvl.getCoins().size());
        assertFalse(lvl.getCoins().get(0).isSkinCoin());
        assertTrue(lvl.getCoins().get(1).isSkinCoin());
        assertTrue(lvl.getCoins().get(2).isSkinCoin());
    }

    @Test
    public void levelManager_buildLevel_lifeSources() {
        LevelData ld = new LevelData();
        ld.startZone = new int[]{10, 60, 150, 280};
        ld.goalZone  = new int[]{460, 60, 150, 280};
        ld.spawn1 = new int[]{75, 190};
        ld.spawn2 = new int[]{495, 190};
        ld.lifeSources.add(new LevelData.LifeSourceData(200, 190));
        Level lvl = LevelManager.buildLevel(ld);
        assertEquals(1, lvl.getLifeSources().size());
    }

    @Test
    public void levelManager_buildLevel_bombs() {
        LevelData ld = new LevelData();
        ld.startZone = new int[]{10, 60, 150, 280};
        ld.goalZone  = new int[]{460, 60, 150, 280};
        ld.spawn1 = new int[]{75, 190};
        ld.spawn2 = new int[]{495, 190};
        ld.bombs.add(new LevelData.BombData(300, 190));
        ld.bombs.add(new LevelData.BombData(350, 190));
        Level lvl = LevelManager.buildLevel(ld);
        assertEquals(2, lvl.getBombs().size());
    }

    @Test
    public void levelManager_buildLevel_notDuplicatedElements() {
        LevelData ld = new LevelData();
        ld.startZone = new int[]{10, 60, 150, 280};
        ld.goalZone  = new int[]{460, 60, 150, 280};
        ld.spawn1 = new int[]{75, 190};
        ld.spawn2 = new int[]{495, 190};
        ld.coins.add(new LevelData.CoinData("YELLOW", 200, 190));
        ld.coins.add(new LevelData.CoinData("YELLOW", 250, 190));
        ld.lifeSources.add(new LevelData.LifeSourceData(220, 190));
        ld.bombs.add(new LevelData.BombData(320, 190));
        Level lvl = LevelManager.buildLevel(ld);
        assertEquals("LifeSources no deben duplicarse", 1, lvl.getLifeSources().size());
        assertEquals("Bombs no deben duplicarse", 1, lvl.getBombs().size());
    }

    // 14. LevelManager — round-trip txt
    
    @Test
    public void levelManager_saveAndLoad_roundTrip() throws IOException {
        LevelData original = new LevelData();
        original.name = "Test Level";
        original.number = 99;
        original.timeLimit = 45;
        original.layoutType = "STRAIGHT";
        original.startZone = new int[]{10, 60, 150, 280};
        original.goalZone  = new int[]{460, 60, 150, 280};
        original.spawn1 = new int[]{75, 190};
        original.spawn2 = new int[]{495, 190};
        original.enemies.add(new LevelData.EnemyData("LINEAR", 200, 190, 2, 0));
        original.coins.add(new LevelData.CoinData("YELLOW", 300, 190));
        original.lifeSources.add(new LevelData.LifeSourceData(250, 190));
        original.bombs.add(new LevelData.BombData(350, 190));

        Path tmp = Files.createTempFile("dopo_test_", ".txt");
        try {
            LevelManager.saveToTxt(original, tmp.toString());
            LevelData loaded = LevelManager.loadFromTxt(tmp.toString());
            assertEquals(original.name,       loaded.name);
            assertEquals(original.number,     loaded.number);
            assertEquals(original.timeLimit,  loaded.timeLimit);
            assertEquals(original.layoutType, loaded.layoutType);
            assertEquals(1, loaded.enemies.size());
            assertEquals(1, loaded.coins.size());
            assertEquals(1, loaded.lifeSources.size());
            assertEquals(1, loaded.bombs.size());
            assertEquals("LINEAR", loaded.enemies.get(0).type);
            assertEquals("YELLOW", loaded.coins.get(0).type);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    @Test
    public void levelManager_saveAndLoad_enemyData() throws IOException {
        LevelData original = new LevelData();
        original.startZone = new int[]{10, 60, 150, 280};
        original.goalZone  = new int[]{460, 60, 150, 280};
        original.spawn1 = new int[]{75, 190};
        original.spawn2 = new int[]{495, 190};
        original.enemies.add(new LevelData.EnemyData("DIAGONAL", 300, 200, 3, -2));
        Path tmp = Files.createTempFile("dopo_enemy_", ".txt");
        try {
            LevelManager.saveToTxt(original, tmp.toString());
            LevelData loaded = LevelManager.loadFromTxt(tmp.toString());
            assertEquals("DIAGONAL", loaded.enemies.get(0).type);
            assertEquals(300, loaded.enemies.get(0).x);
            assertEquals(200, loaded.enemies.get(0).y);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    @Test
    public void levelManager_loadAllFromFolder() {
        List<LevelData> all = LevelManager.loadAllFromFolder("levels");
        assertTrue("Debe cargar al menos 1 nivel", all.size() >= 1);
        for (int i = 1; i < all.size(); i++) {
            assertTrue(all.get(i).number >= all.get(i - 1).number);
        }
    }

    // 15. GameSave

    @Test
    public void gameSave_saveAndLoad_roundTrip() throws IOException {
        RedPlayer p1 = new RedPlayer(75, 190);
        RedPlayer p2 = new RedPlayer(495, 190);
        java.util.List<Coin> coins = new java.util.ArrayList<>();
        coins.add(new Coin(200, 190)); coins.get(0).collect();
        coins.add(new Coin(300, 190));

        Path tmp = Files.createTempFile("dopo_save_", ".txt");
        try {
            GameSave.save(tmp.toString(), 2, "RED", p1, "BLUE", p2, 42, coins);
            GameSave.SaveData sd = GameSave.load(tmp.toString());
            assertEquals(2,     sd.levelNumber);
            assertEquals("RED", sd.player1Type);
            assertEquals("BLUE",sd.player2Type);
            assertEquals(42,    sd.timeLeft);
            assertEquals(75,    sd.player1X);
            assertEquals(190,   sd.player1Y);
            assertEquals(2,     sd.coinsState.length);
            assertEquals("1",   sd.coinsState[0]);
            assertEquals("0",   sd.coinsState[1]);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    @Test
    public void gameSave_noPlayer2_saveAndLoad() throws IOException {
        RedPlayer p1 = new RedPlayer(75, 190);
        Path tmp = Files.createTempFile("dopo_save1p_", ".txt");
        try {
            GameSave.save(tmp.toString(), 1, "GREEN", p1, null, null, 30,
                          new java.util.ArrayList<>());
            GameSave.SaveData sd = GameSave.load(tmp.toString());
            assertEquals("NONE", sd.player2Type);
            assertEquals(30,     sd.timeLeft);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    @Test
    public void gameSave_player1Position_saved() throws IOException {
        RedPlayer p1 = new RedPlayer(123, 456);
        Path tmp = Files.createTempFile("dopo_pos_", ".txt");
        try {
            GameSave.save(tmp.toString(), 1, "RED", p1, null, null, 50,
                          new java.util.ArrayList<>());
            GameSave.SaveData sd = GameSave.load(tmp.toString());
            assertEquals(123, sd.player1X);
            assertEquals(456, sd.player1Y);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    // 16. createTransformed 

    @Test
    public void redPlayer_createTransformed_blue_isNotMachine() {
        Level lvl = makeLevel();
        RedPlayer p = new RedPlayer(50, 190);
        Player t = p.createTransformed("BLUE", 50, 190, lvl);
        assertFalse(t.isMachinePlayer());
        assertEquals(28, t.getWidth()); // BluePlayer es mas grande
    }

    @Test
    public void redPlayer_createTransformed_green_hasOwnShield() {
        Level lvl = makeLevel();
        RedPlayer p = new RedPlayer(50, 190);
        Player t = p.createTransformed("GREEN", 50, 190, lvl);
        assertFalse(t.isMachinePlayer());
        GreenPlayer gp = (GreenPlayer) t;
        assertTrue(gp.hasOwnShield());
    }

    @Test
    public void redPlayer_createTransformed_red_standardSize() {
        Level lvl = makeLevel();
        RedPlayer p = new RedPlayer(50, 190);
        Player t = p.createTransformed("RED", 50, 190, lvl);
        assertFalse(t.isMachinePlayer());
        assertEquals(20, t.getWidth());
        assertEquals(3, t.getSpeed());
    }

    @Test
    public void machinePlayer_createTransformed_isMachinePlayerPolymorphic() {
        Level lvl = makeLevel();
        MachinePlayer mp = new MachinePlayer(0, 0, Profile.ALEATORIA, lvl);
        Player t = mp.createTransformed("BLUE", 0, 0, lvl);
        assertTrue(t.isMachinePlayer());
    }

    // 17. PatrolMovementStrategy

    @Test
    public void patrolStrategy_enemyMoves() {
        PatrolMovementStrategy patrol = new PatrolMovementStrategy(2);
        Enemy e = new Enemy(100, 100, patrol);
        int x0 = e.getX(), y0 = e.getY();
        e.move();
        assertTrue(e.getX() != x0 || e.getY() != y0);
    }

    // 18. computeAIMove 

    @Test
    public void player_computeAIMove_isNoOp_forHuman() {
        RedPlayer p = new RedPlayer(50, 50);
        p.setDirection(0, 0);
        p.computeAIMove(); // no-op
        p.move();
        assertEquals(50, p.getX());
        assertEquals(50, p.getY());
    }

    @Test
    public void machinePlayer_computeAIMove_changesDirection() {
        Level lvl = makeLevel();
        lvl.addPlayableZone(0, 0, 640, 480);
        lvl.addCoin(new Coin(400, 190));
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.EXPERTA, lvl);
        mp.computeAIMove();
        // Después de computeAIMove, al moverse debe desplazarse
        int x0 = mp.getX(), y0 = mp.getY();
        mp.move();
        assertTrue(mp.getX() != x0 || mp.getY() != y0);
    }

    @Test
    public void engine_computeAIMove_calledPolymorphically() {
        Level lvl = makeLevel();
        lvl.addCoin(new Coin(300, 190));
        MachinePlayer mp = new MachinePlayer(50, 190, Profile.EXPERTA, lvl);
        GameEngine engine = new GameEngine(mp, lvl);
        // No debe lanzar excepcion — computeAIMove se llama via polimorfismo
        engine.update();
    }
}
