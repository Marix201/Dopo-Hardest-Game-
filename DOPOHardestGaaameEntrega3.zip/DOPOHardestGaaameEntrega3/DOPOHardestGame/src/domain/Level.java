package domain;
import java.util.*;

public class Level {
    private final int number;
    private final int timeLimit;
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Wall>  walls   = new ArrayList<>();
    private final List<Coin>  coins   = new ArrayList<>();
    private Zone startZone, intermediateZone, goalZone;

    public Level(int number, int timeLimit) {
        this.number    = number;
        this.timeLimit = timeLimit;
    }

    public void addEnemy(Enemy e)           { enemies.add(e); }
    public void addWall(Wall w)             { walls.add(w); }
    public void addCoin(Coin c)             { coins.add(c); }
    public void setStartZone(Zone z)        { startZone = z; }
    public void setIntermediateZone(Zone z) { intermediateZone = z; }
    public void setGoalZone(Zone z)         { goalZone = z; }

    public boolean isComplete(Player p) {
        boolean allNormalCoins = coins.stream()
            .filter(c -> !c.isSkinCoin())
            .allMatch(Coin::isCollected);
        return allNormalCoins && goalZone != null && goalZone.contains(p);
    }

    public void reset() {
        coins.stream()
             .filter(c -> !c.isSkinCoin())
             .forEach(Coin::reset);
    }

    public int         getNumber()           { return number; }
    public int         getTimeLimit()        { return timeLimit; }
    public List<Enemy> getEnemies()          { return enemies; }
    public List<Wall>  getWalls()            { return walls; }
    public List<Coin>  getCoins()            { return coins; }
    public Zone        getStartZone()        { return startZone; }
    public Zone        getIntermediateZone() { return intermediateZone; }
    public Zone        getGoalZone()         { return goalZone; }
}