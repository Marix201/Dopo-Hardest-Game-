package domain;

public interface MovementStrategy {
    void move(Enemy enemy);
    void reverseX();
    void reverseY();
}
