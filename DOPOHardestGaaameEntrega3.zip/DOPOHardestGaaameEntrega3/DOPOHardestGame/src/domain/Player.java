package domain;
import java.awt.*;

/**
 * Clase base abstracta para todos los jugadores.
 * El contador de muertes (deaths) solo sube en die() y nunca se resetea.
 */
public abstract class Player extends GameElement {
    protected int     dx, dy;
    protected boolean alive;
    protected int     deaths;
    protected int     speed;
    protected Color   borderColor;

    public Player(int x, int y, int size, int speed) {
        super(x, y, size, size);
        this.speed       = speed;
        this.alive       = true;
        this.deaths      = 0;
        this.borderColor = Color.WHITE;
    }

    public void move() { x += dx; y += dy; }

    public void setDirection(int dx, int dy) {
        this.dx = dx * speed;
        this.dy = dy * speed;
    }

    /** Cada subclase define qué pasa al recibir un golpe de enemigo */
    public abstract void receiveHit();

    /**
     * Suma UNA muerte y marca al jugador como muerto.
     * NO mueve la posición; eso lo hace reset().
     */
    public void die() {
        deaths++;
        alive = false;
        dx    = 0;
        dy    = 0;
    }

    /**
     * Vuelve al jugador a la posición dada y lo marca como vivo.
     * El contador de muertes NO cambia aquí.
     */
    public void reset(int startX, int startY) {
        x     = startX;
        y     = startY;
        dx    = 0;
        dy    = 0;
        alive = true;
    }

    public boolean isAlive()               { return alive; }
    public int     getDeaths()             { return deaths; }
    public void    setBorderColor(Color c) { this.borderColor = c; }
    public Color   getBorderColor()        { return borderColor; }
    public int     getSpeed()              { return speed; }
}
