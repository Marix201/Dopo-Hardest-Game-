package domain;

public class GameEngine {
    private Player player1;
    private Player player2;
    private final Level currentLevel;

    public GameEngine(Player p1, Level level) {
        this.player1      = p1;
        this.player2      = null;
        this.currentLevel = level;
    }

    public GameEngine(Player p1, Player p2, Level level) {
        this.player1      = p1;
        this.player2      = p2;
        this.currentLevel = level;
    }

    public void update() {
        if (player2 instanceof MachinePlayer) {
            ((MachinePlayer) player2).computeAIMove();
        }
        player1.move();
        if (player2 != null) player2.move();
        currentLevel.getEnemies().forEach(Enemy::move);
        checkCollisions();
    }

    private void checkCollisions() {
        checkForPlayer(player1);
        if (player2 != null) checkForPlayer(player2);

        if (player2 != null
                && player1.isAlive() && player2.isAlive()
                && player1.getBounds().intersects(player2.getBounds())) {
            player1.receiveHit();
            player2.receiveHit();
        }
    }

    private void checkForPlayer(Player p) {
        if (!p.isAlive()) return;
        for (Enemy e : currentLevel.getEnemies()) {
            if (e.collidesWithPlayer(p)) { p.receiveHit(); return; }
        }
        for (Coin c : currentLevel.getCoins()) {
            if (c.isSkinCoin()) continue;
            if (!c.isCollected() && c.getBounds().intersects(p.getBounds())) {
                c.collect();
            }
        }
    }

    public void setPlayer1(Player p) { this.player1 = p; }
    public void setPlayer2(Player p) { this.player2 = p; }

    public Player getPlayer()       { return player1; }
    public Player getPlayer2()      { return player2; }
    public Level  getCurrentLevel() { return currentLevel; }
}