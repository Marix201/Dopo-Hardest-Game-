package domain;
import java.awt.*;

/**
 * Clyde — cuadrado verde resistente.
 * Absorbe el primer golpe (pierde velocidad). Al segundo, muere.
 */
public class GreenPlayer extends Player {
    private boolean shieldActive = true;

    public GreenPlayer(int x, int y) { super(x, y, 20, 3); }

    @Override
    public void receiveHit() {
        if (shieldActive) {
            shieldActive = false;
            speed = 2; // baja a ~0.7x
        } else {
            die();
        }
    }

    @Override
    public void reset(int startX, int startY) {
        super.reset(startX, startY);
        shieldActive = true;
        speed = 3;
    }

    public boolean hasShield() { return shieldActive; }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 5, 5);
        Color top = shieldActive ? new Color(80, 255, 100) : new Color(40, 160, 60);
        Color bot = shieldActive ? new Color(20, 180, 50)  : new Color(10, 90, 30);
        GradientPaint gp = new GradientPaint(x, y, top, x + width, y + height, bot);
        g2.setPaint(gp);
        g2.fillRoundRect(x, y, width, height, 5, 5);
        if (shieldActive) {
            g2.setColor(new Color(200, 255, 200, 100));
            g2.setStroke(new BasicStroke(3f));
            g2.drawRoundRect(x - 2, y - 2, width + 4, height + 4, 7, 7);
        }
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(x, y, width, height, 5, 5);
    }
}
