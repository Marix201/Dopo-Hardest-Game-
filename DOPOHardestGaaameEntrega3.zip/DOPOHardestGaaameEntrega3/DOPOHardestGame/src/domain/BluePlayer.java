package domain;
import java.awt.*;

/**
 * Inky — cuadrado azul rápido y más grande.
 * Velocidad 1.5x (speed=4), tamaño 30x30. Muere al primer contacto.
 */
public class BluePlayer extends Player {

    public BluePlayer(int x, int y) { super(x, y, 30, 4); }

    @Override
    public void receiveHit() { die(); }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 80));
        g2.fillRoundRect(x + 3, y + 3, width, height, 7, 7);
        GradientPaint gp = new GradientPaint(
            x, y, new Color(80, 160, 255),
            x + width, y + height, new Color(20, 80, 200));
        g2.setPaint(gp);
        g2.fillRoundRect(x, y, width, height, 7, 7);
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(x, y, width, height, 7, 7);
    }
}
