package domain;
import java.io.*;
import java.util.List;

/**
 * Maneja guardar y cargar el estado de una partida en un archivo .txt
 *
 * Formato del archivo:
 *   level=2
 *   player1Type=RED
 *   player1X=45
 *   player1Y=130
 *   player1Deaths=3
 *   player2Type=NONE
 *   timeLeft=42
 *   coins=0,1,0,1   (0=no recogida, 1=recogida)
 */
public class GameSave {

    public static void save(String path, int levelNum, String p1Type,
                            Player p1, String p2Type, Player p2,
                            int timeLeft, List<Coin> coins) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
            pw.println("level=" + levelNum);
            pw.println("player1Type=" + p1Type);
            pw.println("player1X=" + p1.getX());
            pw.println("player1Y=" + p1.getY());
            pw.println("player1Deaths=" + p1.getDeaths());
            pw.println("player2Type=" + (p2Type == null ? "NONE" : p2Type));
            if (p2 != null) {
                pw.println("player2X=" + p2.getX());
                pw.println("player2Y=" + p2.getY());
            }
            pw.println("timeLeft=" + timeLeft);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < coins.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(coins.get(i).isCollected() ? "1" : "0");
            }
            pw.println("coins=" + sb);
        }
    }

    public static SaveData load(String path) throws IOException {
        SaveData sd = new SaveData();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("=", 2);
                if (parts.length < 2) continue;
                String key = parts[0].trim(), val = parts[1].trim();
                switch (key) {
                    case "level":         sd.levelNumber   = Integer.parseInt(val); break;
                    case "player1Type":   sd.player1Type   = val; break;
                    case "player1X":      sd.player1X      = Integer.parseInt(val); break;
                    case "player1Y":      sd.player1Y      = Integer.parseInt(val); break;
                    case "player1Deaths": sd.player1Deaths = Integer.parseInt(val); break;
                    case "player2Type":   sd.player2Type   = val; break;
                    case "player2X":      sd.player2X      = Integer.parseInt(val); break;
                    case "player2Y":      sd.player2Y      = Integer.parseInt(val); break;
                    case "timeLeft":      sd.timeLeft      = Integer.parseInt(val); break;
                    case "coins":         sd.coinsState    = val.split(","); break;
                }
            }
        }
        return sd;
    }

    public static class SaveData {
        public int      levelNumber   = 1;
        public String   player1Type   = "RED";
        public int      player1X      = 0;
        public int      player1Y      = 0;
        public int      player1Deaths = 0;
        public String   player2Type   = "NONE";
        public int      player2X      = 0;
        public int      player2Y      = 0;
        public int      timeLeft      = 60;
        public String[] coinsState    = {};
    }
}
