package domain;
import java.util.*;

/**
 * Jugador controlado por la máquina (modo PvsM).
 *
 * ALEATORIA: cambia de dirección cada cierto número de ticks de forma aleatoria.
 * EXPERTA:   se dirige en línea recta hacia la moneda más cercana no recogida,
 *            y luego hacia el GOAL cuando ya las recogió todas.
 */
public class MachinePlayer extends RedPlayer {

    public enum Profile { ALEATORIA, EXPERTA }

    private final Profile profile;
    private final Random  rng = new Random();
    private Level level;

    // Estado IA aleatoria
    private int ticksSinceDir = 0;
    private int dirChangeTick = 20;
    private int aiDx = 1, aiDy = 0;

    public MachinePlayer(int x, int y, Profile profile, Level level) {
        super(x, y);
        this.profile = profile;
        this.level   = level;
    }

    /**
     * Calcula el próximo movimiento de la IA.
     * Debe llamarse una vez por tick ANTES de move().
     */
    public void computeAIMove() {
        if (profile == Profile.ALEATORIA) moveRandom();
        else                              moveExpert();
    }

    // ── IA Aleatoria ─────────────────────────────────────────────────────────

    private void moveRandom() {
        ticksSinceDir++;
        if (ticksSinceDir >= dirChangeTick) {
            ticksSinceDir = 0;
            dirChangeTick = 15 + rng.nextInt(30);
            int[] opts = {-1, 0, 1};
            aiDx = opts[rng.nextInt(3)];
            aiDy = opts[rng.nextInt(3)];
        }
        setDirection(aiDx, aiDy);
    }

    // ── IA Experta (greedy hacia objetivo) ────────────────────────────────────

    private void moveExpert() {
        // Busca la primera moneda sin recoger
        Coin target = level.getCoins().stream()
                           .filter(c -> !c.isCollected())
                           .min(Comparator.comparingDouble(c ->
                               Math.hypot(c.getX() - getX(), c.getY() - getY())))
                           .orElse(null);

        int targetX, targetY;
        if (target != null) {
            targetX = target.getX();
            targetY = target.getY();
        } else if (level.getGoalZone() != null) {
            targetX = level.getGoalZone().getX() + level.getGoalZone().getWidth() / 2;
            targetY = level.getGoalZone().getY() + level.getGoalZone().getHeight() / 2;
        } else {
            moveRandom();
            return;
        }

        int dx = 0, dy = 0;
        int diffX = targetX - getX();
        int diffY = targetY - getY();

        // Alterna entre mover en X o en Y según cuál diferencia sea mayor
        if (Math.abs(diffX) > Math.abs(diffY)) {
            dx = diffX > 0 ? 1 : -1;
        } else if (diffY != 0) {
            dy = diffY > 0 ? 1 : -1;
        }

        setDirection(dx, dy);
    }

    public void setLevel(Level level) { this.level = level; }
    public Profile getProfile()       { return profile; }
}
