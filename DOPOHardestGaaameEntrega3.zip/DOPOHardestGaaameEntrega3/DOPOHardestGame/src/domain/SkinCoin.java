package domain;
import java.awt.*;

public class SkinCoin extends Coin {
    private final String skinType;
    private final Color  coinColor;

    public SkinCoin(int x, int y, String skinType) {
        super(x, y);
        this.skinType = skinType;
        switch (skinType) {
            case "BLUE":  coinColor = new Color(80, 160, 255); break;
            case "GREEN": coinColor = new Color(60, 200, 80);  break;
            default:      coinColor = new Color(255, 80, 80);  break;
        }
    }

    public String getSkinType()     { return skinType; }

    @Override
    public boolean isSkinCoin()     { return true; }

    @Override
    public void draw(Graphics g) {
        if (!isCollected()) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            g2.setColor(new Color(0, 0, 0, 50));
            g2.fillOval(x + 2, y + 2, w, h);
            GradientPaint gp = new GradientPaint(
                x, y, coinColor.brighter(),
                x + w, y + h, coinColor.darker());
            g2.setPaint(gp);
            g2.fillOval(x, y, w, h);
            g2.setColor(new Color(255, 255, 255, 130));
            g2.fillOval(x + 2, y + 2, w / 3, h / 3);
            g2.setColor(coinColor.darker().darker());
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawOval(x, y, w, h);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.BOLD, 8));
            g2.drawString("S", x + 4, y + 10);
        }
    }
}