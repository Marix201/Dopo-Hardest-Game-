package presentation;

import domain.*;
import domain.Zone.ZoneType;
import domain.MachinePlayer.Profile;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.List;

public class GamePanel extends JPanel implements KeyListener, ActionListener {

    private GameEngine engine;
    private HUDPanel   hud;
    private DopoHardestGameGUI gui;
    private Timer      timer;
    private boolean[]  keys   = new boolean[256];
    private boolean    won    = false;
    private boolean    lost   = false;
    private boolean    paused = false;
    private boolean    wasWon = false;

    private String gameMode;
    private String p1Type;
    private String p2Type;
    private String p1OriginalType;
    private String p2OriginalType;

    private int p1SpawnX, p1SpawnY;
    private int p2SpawnX, p2SpawnY;

    private int p1PrevX, p1PrevY;
    private int p2PrevX, p2PrevY;

    private String p1ActiveSkin = null;
    private String p2ActiveSkin = null;

    private static final int TOTAL_LEVELS = 3;
    private int timeLeft;
    private int tickCount    = 0;
    private int currentLevel = 1;

    public static final int W = 620;
    public static final int H = 400;

    private static final int N1_BX=10,  N1_BY=60,  N1_BW=600, N1_BH=280;
    private static final int N1_CX=160, N1_CW=280;
    private static final int N1_ZW=N1_CX-N1_BX;
    private static final int N1_SX=N1_BX,        N1_SY=N1_BY;
    private static final int N1_GX=N1_CX+N1_CW,  N1_GY=N1_BY;
    private static final int N1_PX=N1_SX+N1_ZW/2-10, N1_PY=N1_SY+N1_BH/2-10;

    private static final int N2_SX=10,  N2_SY=20,  N2_SW=150, N2_SH=260;
    private static final int N2_CX=160, N2_CY=160, N2_CW=300, N2_CH=120;
    private static final int N2_GX=460, N2_GY=160, N2_GW=150, N2_GH=220;
    private static final int N2_PX=N2_SX+N2_SW/2-10, N2_PY=N2_SY+20;

    private static final int N3_SX  = 10,  N3_SY  = 80,  N3_SW  = 100, N3_SH  = 170;
    private static final int N3_IZX = 110, N3_IZY = 80,  N3_IZW = 80,  N3_IZH = 220;
    private static final int N3_BJX = 110, N3_BJY = 270, N3_BJW = 380, N3_BJH = 80;
    private static final int N3_DRX = 450, N3_DRY = 60,  N3_DRW = 80,  N3_DRH = 290;
    private static final int N3_GX  = 500, N3_GY  = 60,  N3_GW  = 110, N3_GH  = 130;
    private static final int N3_CKX = 275, N3_CKY = 270, N3_CKW = 40,  N3_CKH = 80;
    private static final int N3_P1X = N3_SX + 10,              N3_P1Y = N3_SY + N3_SH/2 - 10;
    private static final int N3_P2X = N3_GX + N3_GW/2 - 10,   N3_P2Y = N3_GY + 20;

    private static final int ES = 2;

    private Rectangle btnPrimary, btnLevels, btnSave, btnExit;

    public GamePanel(HUDPanel hud, DopoHardestGameGUI gui) {
        this.hud = hud;
        this.gui = gui;
        setPreferredSize(new Dimension(W, H));
        setFocusable(true);
        addKeyListener(this);
        timer = new Timer(33, this);

        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (!won && !lost) return;
                Point p = e.getPoint();
                if (btnSave != null && btnSave.contains(p)) { doSave(); return; }
                if (btnPrimary != null && btnPrimary.contains(p)) {
                    boolean goNext = wasWon;
                    won = false; lost = false; wasWon = false;
                    int next = goNext
                        ? (currentLevel < TOTAL_LEVELS ? currentLevel + 1 : 1)
                        : currentLevel;
                    startGame(gameMode, p1OriginalType, p2OriginalType, next);
                } else if (btnLevels != null && btnLevels.contains(p)) {
                    timer.stop(); gui.showLevelSelect();
                } else if (btnExit != null && btnExit.contains(p)) {
                    timer.stop(); gui.showMenu();
                }
            }
        });
    }

    public Timer getTimer() { return timer; }

    public void startGame(String mode, String p1Type, String p2Type, int levelNum) {
        this.gameMode       = mode;
        this.p1Type         = p1Type;
        this.p2Type         = p2Type;
        this.p1OriginalType = p1Type;
        this.p2OriginalType = p2Type;
        this.currentLevel   = levelNum;
        this.won            = false;
        this.lost           = false;
        this.wasWon         = false;
        this.paused         = false;
        this.p1ActiveSkin   = null;
        this.p2ActiveSkin   = null;

        Level level = buildLevel(levelNum);

        int[] sp1 = spawnPos(levelNum, 1);
        p1SpawnX = sp1[0]; p1SpawnY = sp1[1];
        p1PrevX  = p1SpawnX; p1PrevY = p1SpawnY;
        Player p1 = makePlayer(p1Type, p1SpawnX, p1SpawnY);

        if ("PLAYER".equals(mode)) {
            engine = new GameEngine(p1, level);
        } else {
            int[] sp2 = spawnPos(levelNum, 2);
            p2SpawnX = sp2[0]; p2SpawnY = sp2[1];
            p2PrevX  = p2SpawnX; p2PrevY = p2SpawnY;
            Player p2;
            switch (mode) {
                case "PVM_RANDOM":
                    p2 = new MachinePlayer(p2SpawnX, p2SpawnY, Profile.ALEATORIA, level);
                    break;
                case "PVM_EXPERT":
                    p2 = new MachinePlayer(p2SpawnX, p2SpawnY, Profile.EXPERTA, level);
                    break;
                default:
                    p2 = makePlayer(p2Type != null ? p2Type : "BLUE", p2SpawnX, p2SpawnY);
            }
            engine = new GameEngine(p1, p2, level);
        }

        timeLeft  = level.getTimeLimit();
        tickCount = 0;
        if (!timer.isRunning()) timer.start();
    }

    public void startGame(int levelNum) { startGame("PLAYER", "RED", null, levelNum); }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (won || lost || paused) return;

        tickCount++;
        if (tickCount >= 30) {
            tickCount = 0;
            timeLeft--;
            if (timeLeft <= 0) {
                timeLeft = 0;
                lost   = true;
                wasWon = false;
                timer.stop();
                Level lvl = engine.getCurrentLevel();
                hud.update(engine.getPlayer().getDeaths(),
                           lvl.getNumber(), 0,
                           countNormalCoins(), countTotalNormalCoins());
                repaint();
                return;
            }
        }

        // Guardar posición ANTES de mover
        Player p1 = engine.getPlayer();
        p1PrevX = p1.getX(); p1PrevY = p1.getY();
        Player p2 = engine.getPlayer2();
        if (p2 != null) { p2PrevX = p2.getX(); p2PrevY = p2.getY(); }

        int dx1 = 0, dy1 = 0;
        if (keys[KeyEvent.VK_LEFT]  || keys[KeyEvent.VK_A]) dx1 = -1;
        if (keys[KeyEvent.VK_RIGHT] || keys[KeyEvent.VK_D]) dx1 =  1;
        if (keys[KeyEvent.VK_UP]    || keys[KeyEvent.VK_W]) dy1 = -1;
        if (keys[KeyEvent.VK_DOWN]  || keys[KeyEvent.VK_S]) dy1 =  1;
        p1.setDirection(dx1, dy1);

        if (p2 != null && "PVP".equals(gameMode)) {
            int dx2 = 0, dy2 = 0;
            if (keys[KeyEvent.VK_J]) dx2 = -1;
            if (keys[KeyEvent.VK_L]) dx2 =  1;
            if (keys[KeyEvent.VK_I]) dy2 = -1;
            if (keys[KeyEvent.VK_K]) dy2 =  1;
            p2.setDirection(dx2, dy2);
        }

        engine.update();
        applyBounds();
        checkSkinCoins();
        checkCheckpoint();
        handleDeaths();

        Level lvl = engine.getCurrentLevel();
        p1 = engine.getPlayer();
        p2 = engine.getPlayer2();
        if (lvl.isComplete(p1) || (p2 != null && lvl.isComplete(p2))) {
            won    = true;
            wasWon = true;
            timer.stop();
        }

        hud.update(p1.getDeaths(), lvl.getNumber(), timeLeft,
                   countNormalCoins(), countTotalNormalCoins());
        repaint();
    }

    private void checkSkinCoins() {
        for (Coin c : engine.getCurrentLevel().getCoins()) {
            if (!c.isSkinCoin() || c.isCollected()) continue;
            SkinCoin sc = (SkinCoin) c;
            Player   p1 = engine.getPlayer();
            Player   p2 = engine.getPlayer2();
            if (c.getBounds().intersects(p1.getBounds())) {
                c.collect();
                transformPlayer(1, sc.getSkinType(), p1);
            } else if (p2 != null && c.getBounds().intersects(p2.getBounds())) {
                c.collect();
                transformPlayer(2, sc.getSkinType(), p2);
            }
        }
    }

    private void transformPlayer(int playerNum, String skinType, Player old) {
        Player nuevo = makePlayer(skinType, old.getX(), old.getY());
        nuevo.setBorderColor(old.getBorderColor());
        int deaths = old.getDeaths();
        for (int i = 0; i < deaths; i++) nuevo.die();
        nuevo.reset(old.getX(), old.getY());
        if (playerNum == 1) { p1ActiveSkin = skinType; engine.setPlayer1(nuevo); }
        else                { p2ActiveSkin = skinType; engine.setPlayer2(nuevo); }
    }

    private void checkCheckpoint() {
        Zone ck = engine.getCurrentLevel().getIntermediateZone();
        if (ck == null) return;
        int ckSpawnX = ck.getX() + ck.getWidth()  / 2 - 10;
        int ckSpawnY = ck.getY() + ck.getHeight() / 2 - 10;
        Player p1 = engine.getPlayer();
        if (ck.intersects(p1)) { p1SpawnX = ckSpawnX; p1SpawnY = ckSpawnY; }
        Player p2 = engine.getPlayer2();
        if (p2 != null && ck.intersects(p2)) { p2SpawnX = ckSpawnX; p2SpawnY = ckSpawnY; }
    }

    private void handleDeaths() {
        Player p1 = engine.getPlayer();
        if (!p1.isAlive()) {
            engine.getCurrentLevel().reset();
            Player restored = makePlayer(p1OriginalType, p1SpawnX, p1SpawnY);
            restored.setBorderColor(p1.getBorderColor());
            int deaths = p1.getDeaths();
            for (int i = 0; i < deaths; i++) restored.die();
            restored.reset(p1SpawnX, p1SpawnY);
            engine.setPlayer1(restored);
            p1PrevX = p1SpawnX; p1PrevY = p1SpawnY;
            p1ActiveSkin = null;
        }
        Player p2 = engine.getPlayer2();
        if (p2 != null && !p2.isAlive()) {
            String orig = p2OriginalType != null ? p2OriginalType : "BLUE";
            Player restored = makePlayer(orig, p2SpawnX, p2SpawnY);
            restored.setBorderColor(p2.getBorderColor());
            int deaths = p2.getDeaths();
            for (int i = 0; i < deaths; i++) restored.die();
            restored.reset(p2SpawnX, p2SpawnY);
            engine.setPlayer2(restored);
            p2PrevX = p2SpawnX; p2PrevY = p2SpawnY;
            p2ActiveSkin = null;
        }
    }

    private void applyBounds() {
        Player p1 = engine.getPlayer();
        Player p2 = engine.getPlayer2();
        switch (currentLevel) {
            case 1:
                clamp(p1, N1_BX, N1_BY, N1_BW, N1_BH);
                if (p2 != null) clamp(p2, N1_BX, N1_BY, N1_BW, N1_BH);
                bounceEnemiesInBox(N1_CX, N1_BY, N1_CW, N1_BH);
                break;
            case 2:
                boundsL2(p1);
                if (p2 != null) boundsL2(p2);
                bounceEnemiesInBox(N2_CX, N2_CY, N2_CW, N2_CH);
                break;
            case 3:
                boundsL3(p1, p1PrevX, p1PrevY);
                if (p2 != null) boundsL3(p2, p2PrevX, p2PrevY);
                bounceEnemiesL3();
                break;
        }
    }

    private void boundsL2(Player p) {
        int px = p.getX(), py = p.getY(), pw = p.getWidth(), ph = p.getHeight();
        int cx = px + pw / 2;

        int minX = N2_SX, maxX = N2_GX + N2_GW - pw;
        int minY = N2_SY, maxY = N2_GY + N2_GH - ph;
        if (px < minX) { p.setX(minX); px = minX; cx = px + pw/2; }
        if (px > maxX) { p.setX(maxX); px = maxX; cx = px + pw/2; }
        if (py < minY) { p.setY(minY); py = minY; }
        if (py > maxY) { p.setY(maxY); py = maxY; }

        boolean enStart    = cx <= N2_CX;
        boolean enGoal     = cx >= N2_GX;
        boolean enCorredor = !enStart && !enGoal;

        if (enStart) {
            if (py < N2_SY)              p.setY(N2_SY);
            if (py + ph > N2_SY + N2_SH) p.setY(N2_SY + N2_SH - ph);
            if (px + pw > N2_CX && (py < N2_CY || py + ph > N2_CY + N2_CH))
                p.setX(N2_CX - pw);
        }
        if (enCorredor) {
            if (py < N2_CY)              p.setY(N2_CY);
            if (py + ph > N2_CY + N2_CH) p.setY(N2_CY + N2_CH - ph);
        }
        if (enGoal) {
            if (py < N2_GY)              p.setY(N2_GY);
            if (py + ph > N2_GY + N2_GH) p.setY(N2_GY + N2_GH - ph);
            if (px < N2_GX && (py < N2_CY || py + ph > N2_CY + N2_CH))
                p.setX(N2_GX);
        }
    }

    private void boundsL3(Player p, int prevX, int prevY) {
        int pw = p.getWidth(), ph = p.getHeight();
        int nx = p.getX(), ny = p.getY();
        int ncx = nx + pw/2, ncy = ny + ph/2;

        String zona = zonaL3(ncx, ncy);
        if (zona != null) {
            clampEnZona(p, zona);
            return;
        }
        // Revertir solo X
        if (zonaL3(prevX + pw/2, ncy) != null) {
            p.setX(prevX);
            clampEnZona(p, zonaL3(prevX + pw/2, ncy));
            return;
        }
        // Revertir solo Y
        if (zonaL3(ncx, prevY + ph/2) != null) {
            p.setY(prevY);
            clampEnZona(p, zonaL3(ncx, prevY + ph/2));
            return;
        }
        // Revertir ambos
        p.setX(prevX);
        p.setY(prevY);
    }

    private String zonaL3(int cx, int cy) {
        if (inRect(N3_SX,  N3_SY,  N3_SW,  N3_SH,  cx, cy)) return "START";
        if (inRect(N3_GX,  N3_GY,  N3_GW,  N3_GH,  cx, cy)) return "GOAL";
        boolean enIZ = inRect(N3_IZX, N3_IZY, N3_IZW, N3_IZH, cx, cy);
        boolean enBJ = inRect(N3_BJX, N3_BJY, N3_BJW, N3_BJH, cx, cy);
        boolean enDR = inRect(N3_DRX, N3_DRY, N3_DRW, N3_DRH, cx, cy);
        if (enBJ) return "BJ";
        if (enDR) return "DR";
        if (enIZ) return "IZ";
        return null;
    }

    private boolean inRect(int rx, int ry, int rw, int rh, int px, int py) {
        return px >= rx && px <= rx + rw && py >= ry && py <= ry + rh;
    }

    private void clampEnZona(Player p, String zona) {
        switch (zona) {
            case "START": clamp(p, N3_SX,  N3_SY,  N3_SW,  N3_SH);  break;
            case "IZ":    clamp(p, N3_IZX, N3_IZY, N3_IZW, N3_IZH); break;
            case "BJ":    clamp(p, N3_BJX, N3_BJY, N3_BJW, N3_BJH); break;
            case "DR":    clamp(p, N3_DRX, N3_DRY, N3_DRW, N3_DRH); break;
            case "GOAL":  clamp(p, N3_GX,  N3_GY,  N3_GW,  N3_GH);  break;
        }
    }

    private void bounceEnemiesInBox(int bx, int by, int bw, int bh) {
        for (Enemy en : engine.getCurrentLevel().getEnemies()) {
            if (en.getX() <= bx)                       en.reverseX();
            if (en.getX() + en.getWidth()  >= bx + bw) en.reverseX();
            if (en.getY() <= by)                       en.reverseY();
            if (en.getY() + en.getHeight() >= by + bh) en.reverseY();
        }
    }

    private void bounceEnemiesL3() {
        List<Enemy> enemies = engine.getCurrentLevel().getEnemies();
        for (int i = 0; i < enemies.size(); i++) {
            Enemy en = enemies.get(i);
            int ex = en.getX(), ey = en.getY(), ew = en.getWidth(), eh = en.getHeight();
            if (i < 3) {
                if (ex <= N3_BJX)               en.reverseX();
                if (ex + ew >= N3_BJX + N3_BJW) en.reverseX();
                if (ey <= N3_BJY)               en.reverseY();
                if (ey + eh >= N3_BJY + N3_BJH) en.reverseY();
            } else if (i < 5) {
                if (ey <= N3_IZY)               en.reverseY();
                if (ey + eh >= N3_IZY + N3_IZH) en.reverseY();
                if (ex <= N3_IZX)               en.reverseX();
                if (ex + ew >= N3_IZX + N3_IZW) en.reverseX();
            } else {
                if (ey <= N3_DRY)               en.reverseY();
                if (ey + eh >= N3_DRY + N3_DRH) en.reverseY();
                if (ex <= N3_DRX)               en.reverseX();
                if (ex + ew >= N3_DRX + N3_DRW) en.reverseX();
            }
        }
    }

    private void clamp(Player p, int x, int y, int w, int h) {
        if (p.getX() < x)                     p.setX(x);
        if (p.getX() > x + w - p.getWidth())  p.setX(x + w - p.getWidth());
        if (p.getY() < y)                     p.setY(y);
        if (p.getY() > y + h - p.getHeight()) p.setY(y + h - p.getHeight());
    }

    private Level buildLevel(int n) {
        if (n == 1) return buildL1();
        if (n == 2) return buildL2();
        return buildL3();
    }

    private Level buildL1() {
        Level lvl = new Level(1, 60);
        lvl.setStartZone(new Zone(N1_SX, N1_SY, N1_ZW, N1_BH, ZoneType.START));
        lvl.setGoalZone( new Zone(N1_GX, N1_GY, N1_ZW, N1_BH, ZoneType.GOAL));
        int s = ES, d = 2;
        lvl.addEnemy(new Enemy(215, N1_BY,       new LinearMovementStrategy(0,  s)));
        lvl.addEnemy(new Enemy(305, N1_BY + 93,  new LinearMovementStrategy(0,  s)));
        lvl.addEnemy(new Enemy(395, N1_BY + 186, new LinearMovementStrategy(0,  s)));
        lvl.addEnemy(new Enemy(N1_CX + 10,         N1_BY + 10,          new DiagonalMovementStrategy( d,  d)));
        lvl.addEnemy(new Enemy(N1_CX + N1_CW - 30, N1_BY + N1_BH - 30, new DiagonalMovementStrategy(-d, -d)));
        int coinY = N1_BY + N1_BH / 2 - 6;
        lvl.addCoin(new Coin(222, coinY));
        lvl.addCoin(new Coin(305, coinY));
        lvl.addCoin(new Coin(388, coinY));
        lvl.addCoin(new SkinCoin(265, coinY - 30, "GREEN"));
        return lvl;
    }

    private Level buildL2() {
        Level lvl = new Level(2, 60);
        lvl.setStartZone(new Zone(N2_SX, N2_SY, N2_SW, N2_SH, ZoneType.START));
        lvl.setGoalZone( new Zone(N2_GX, N2_GY, N2_GW, N2_GH, ZoneType.GOAL));
        int s  = ES + 1;
        int f1 = N2_CY + 10, f2 = N2_CY + N2_CH / 2 - 10, f3 = N2_CY + N2_CH - 30;
        lvl.addEnemy(new Enemy(N2_CX + 10,         f1, new LinearMovementStrategy( s, 0)));
        lvl.addEnemy(new Enemy(N2_CX + N2_CW / 2,  f1, new LinearMovementStrategy( s, 0)));
        lvl.addEnemy(new Enemy(N2_CX + N2_CW / 4,  f2, new LinearMovementStrategy(-s, 0)));
        lvl.addEnemy(new Enemy(N2_CX + N2_CW - 30, f2, new LinearMovementStrategy(-s, 0)));
        lvl.addEnemy(new Enemy(N2_CX + 10,          f3, new LinearMovementStrategy( s, 0)));
        lvl.addEnemy(new Enemy(N2_CX + N2_CW / 2,  f3, new LinearMovementStrategy( s, 0)));
        int coinY = N2_CY + N2_CH / 2 - 6;
        lvl.addCoin(new Coin(N2_CX + 60,  coinY));
        lvl.addCoin(new Coin(N2_CX + 150, coinY));
        lvl.addCoin(new Coin(N2_CX + 240, coinY));
        lvl.addCoin(new SkinCoin(N2_CX + 105, coinY - 25, "BLUE"));
        lvl.addCoin(new SkinCoin(N2_CX + 195, coinY + 25, "RED"));
        return lvl;
    }

    private Level buildL3() {
        Level lvl = new Level(3, 90);
        lvl.setStartZone(       new Zone(N3_SX,  N3_SY,  N3_SW,  N3_SH,  ZoneType.START));
        lvl.setIntermediateZone(new Zone(N3_CKX, N3_CKY, N3_CKW, N3_CKH, ZoneType.INTERMEDIATE));
        lvl.setGoalZone(        new Zone(N3_GX,  N3_GY,  N3_GW,  N3_GH,  ZoneType.GOAL));
        int s = ES + 1;
        lvl.addEnemy(new Enemy(N3_BJX + 20,          N3_BJY + 15, new LinearMovementStrategy( s, 0)));
        lvl.addEnemy(new Enemy(N3_BJX + N3_BJW / 2,  N3_BJY + 45, new LinearMovementStrategy(-s, 0)));
        lvl.addEnemy(new Enemy(N3_BJX + N3_BJW - 50, N3_BJY + 15, new LinearMovementStrategy( s, 0)));
        lvl.addEnemy(new Enemy(N3_IZX + 15, N3_IZY + 20,  new LinearMovementStrategy(0,  s)));
        lvl.addEnemy(new Enemy(N3_IZX + 45, N3_IZY + 120, new LinearMovementStrategy(0, -s)));
        lvl.addEnemy(new Enemy(N3_DRX + 15, N3_DRY + 30,  new LinearMovementStrategy(0,  s)));
        lvl.addEnemy(new Enemy(N3_DRX + 45, N3_DRY + 180, new LinearMovementStrategy(0, -s)));
        lvl.addCoin(new Coin(N3_BJX + 50,  N3_BJY + N3_BJH / 2 - 6));
        lvl.addCoin(new Coin(N3_BJX + 140, N3_BJY + N3_BJH / 2 - 6));
        lvl.addCoin(new Coin(N3_BJX + 230, N3_BJY + N3_BJH / 2 - 6));
        lvl.addCoin(new Coin(N3_BJX + 320, N3_BJY + N3_BJH / 2 - 6));
        lvl.addCoin(new Coin(N3_IZX + N3_IZW / 2 - 6, N3_IZY + 70));
        lvl.addCoin(new Coin(N3_IZX + N3_IZW / 2 - 6, N3_IZY + 160));
        lvl.addCoin(new Coin(N3_DRX + N3_DRW / 2 - 6, N3_DRY + 60));
        lvl.addCoin(new Coin(N3_DRX + N3_DRW / 2 - 6, N3_DRY + 190));
        lvl.addCoin(new SkinCoin(N3_BJX + 185, N3_BJY + N3_BJH / 2 - 6, "GREEN"));
        lvl.addCoin(new SkinCoin(N3_DRX + N3_DRW / 2 - 6, N3_DRY + 125, "BLUE"));
        return lvl;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if      (currentLevel == 1) drawL1(g2);
        else if (currentLevel == 2) drawL2(g2);
        else                        drawL3(g2);

        Level lvl = engine.getCurrentLevel();
        Zone  ck  = lvl.getIntermediateZone();
        if (ck != null) ck.draw(g2);

        lvl.getCoins().forEach(c    -> c.draw(g2));
        lvl.getEnemies().forEach(en -> en.draw(g2));
        engine.getPlayer().draw(g2);
        if (engine.getPlayer2() != null) engine.getPlayer2().draw(g2);

        drawSkinIndicator(g2);
        drawModeIndicator(g2);

        if (paused) drawPause(g2);
        if (won)    drawWin(g2);
        if (lost)   drawLose(g2);
    }

    private void drawSkinIndicator(Graphics2D g2) {
        if (p1ActiveSkin == null && p2ActiveSkin == null) return;
        g2.setFont(new Font("Arial", Font.BOLD, 11));
        if (p1ActiveSkin != null) {
            g2.setColor(skinColor(p1ActiveSkin));
            g2.drawString("J1: " + p1ActiveSkin, 10, 14);
        }
        if (p2ActiveSkin != null) {
            g2.setColor(skinColor(p2ActiveSkin));
            g2.drawString("J2: " + p2ActiveSkin, 120, 14);
        }
    }

    private void drawModeIndicator(Graphics2D g2) {
        if ("PVM_RANDOM".equals(gameMode) || "PVM_EXPERT".equals(gameMode)) {
            g2.setFont(new Font("Arial", Font.BOLD, 10));
            g2.setColor(new Color(255, 180, 60));
            String lbl = "PVM_RANDOM".equals(gameMode) ? "IA: ALEATORIA" : "IA: EXPERTA";
            g2.drawString(lbl, W - 100, 14);
        }
    }

    private Color skinColor(String s) {
        switch (s) {
            case "BLUE":  return new Color(80, 160, 255);
            case "GREEN": return new Color(60, 200, 80);
            default:      return new Color(255, 80, 80);
        }
    }

    private void drawL1(Graphics2D g2) {
        g2.setColor(new Color(100, 120, 200));
        g2.fillRect(0, 0, W, H);
        g2.setColor(new Color(120, 210, 120));
        g2.fillRect(N1_SX, N1_SY, N1_ZW, N1_BH);
        checkers(g2, N1_CX, N1_BY, N1_CW, N1_BH);
        g2.setColor(new Color(255, 220, 80));
        g2.fillRect(N1_GX, N1_GY, N1_ZW, N1_BH);
        border(g2);
        zlabel(g2, "START", N1_SX, N1_SY, N1_ZW, N1_BH);
        zlabel(g2, "GOAL",  N1_GX, N1_GY, N1_ZW, N1_BH);
    }

    private void drawL2(Graphics2D g2) {
        g2.setColor(new Color(100, 120, 200));
        g2.fillRect(0, 0, W, H);
        g2.setColor(new Color(120, 210, 120));
        g2.fillRect(N2_SX, N2_SY, N2_SW, N2_SH);
        checkers(g2, N2_CX, N2_CY, N2_CW, N2_CH);
        g2.setColor(new Color(255, 220, 80));
        g2.fillRect(N2_GX, N2_GY, N2_GW, N2_GH);
        border(g2);
        zlabel(g2, "START", N2_SX, N2_SY, N2_SW, N2_SH);
        zlabel(g2, "GOAL",  N2_GX, N2_GY, N2_GW, N2_GH);
    }

    private void drawL3(Graphics2D g2) {
        g2.setColor(new Color(25, 25, 55));
        g2.fillRect(0, 0, W, H);
        g2.setColor(new Color(100, 190, 100));
        g2.fillRect(N3_SX, N3_SY, N3_SW, N3_SH);
        g2.setColor(new Color(240, 200, 60));
        g2.fillRect(N3_GX, N3_GY, N3_GW, N3_GH);
        checkers(g2, N3_IZX, N3_IZY, N3_IZW, N3_IZH);
        checkers(g2, N3_BJX, N3_BJY, N3_BJW, N3_BJH);
        checkers(g2, N3_DRX, N3_DRY, N3_DRW, N3_DRH);
        g2.setColor(new Color(80, 80, 160));
        g2.setStroke(new BasicStroke(2));
        g2.drawRect(N3_IZX, N3_IZY, N3_IZW, N3_IZH);
        g2.drawRect(N3_BJX, N3_BJY, N3_BJW, N3_BJH);
        g2.drawRect(N3_DRX, N3_DRY, N3_DRW, N3_DRH);
        g2.setColor(new Color(255, 255, 255, 100));
        g2.setFont(new Font("Arial", Font.BOLD, 18));
        g2.drawString("↓", N3_IZX + N3_IZW / 2 - 6, N3_IZY + N3_IZH / 2 + 6);
        g2.drawString("→", N3_BJX + N3_BJW / 2 - 6, N3_BJY + N3_BJH / 2 + 6);
        g2.drawString("↑", N3_DRX + N3_DRW / 2 - 6, N3_DRY + N3_DRH / 2 + 6);
        border(g2);
        zlabel(g2, "START", N3_SX, N3_SY, N3_SW, N3_SH);
        zlabel(g2, "GOAL",  N3_GX, N3_GY, N3_GW, N3_GH);
    }

    private void checkers(Graphics2D g2, int x, int y, int w, int h) {
        int ts = 20;
        for (int r = 0; r * ts < h; r++)
            for (int c = 0; c * ts < w; c++) {
                g2.setColor((r + c) % 2 == 0 ? new Color(225, 225, 245) : new Color(205, 205, 230));
                int rx = x + c * ts, ry = y + r * ts;
                int rw = Math.min(ts, x + w - rx), rh = Math.min(ts, y + h - ry);
                if (rw > 0 && rh > 0) g2.fillRect(rx, ry, rw, rh);
            }
    }

    private void border(Graphics2D g2) {
        g2.setColor(new Color(20, 20, 40));
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(2, 2, W - 4, H - 4);
    }

    private void zlabel(Graphics2D g2, String txt, int x, int y, int w, int h) {
        g2.setColor(new Color(20, 70, 20));
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(txt, x + (w - fm.stringWidth(txt)) / 2, y + h / 2 + 4);
    }

    private void drawPause(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, 0, W, H);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 38));
        centered(g2, "PAUSADO", W / 2, H / 2 - 10);
        g2.setFont(new Font("Arial", Font.PLAIN, 14));
        centered(g2, "Presiona P para continuar", W / 2, H / 2 + 28);
    }

    private void setOverlayBtns(int bx, int by, int bw) {
        int bW = 95, bH = 36, gap = 8;
        int total = 4 * bW + 3 * gap;
        int sx = bx + (bw - total) / 2;
        int y  = by + 195;
        btnPrimary = new Rectangle(sx,              y, bW, bH);
        btnLevels  = new Rectangle(sx + bW + gap,   y, bW, bH);
        btnSave    = new Rectangle(sx + 2*(bW+gap), y, bW, bH);
        btnExit    = new Rectangle(sx + 3*(bW+gap), y, bW, bH);
    }

    private void drawWin(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 160)); g2.fillRect(0, 0, W, H);
        int bw = 430, bh = 280, bx = (W - bw) / 2, by = (H - bh) / 2;
        g2.setPaint(new GradientPaint(bx, by, new Color(20, 70, 20), bx+bw, by+bh, new Color(5, 35, 5)));
        g2.fillRoundRect(bx, by, bw, bh, 20, 20);
        g2.setColor(new Color(80, 220, 80)); g2.setStroke(new BasicStroke(3));
        g2.drawRoundRect(bx, by, bw, bh, 20, 20);
        g2.setColor(new Color(120, 255, 120)); g2.setFont(new Font("Arial", Font.BOLD, 34));
        centered(g2, "¡GANASTE!", bx + bw/2, by + 55);
        g2.setColor(Color.WHITE); g2.setFont(new Font("Arial", Font.PLAIN, 14));
        centered(g2, "Muertes: "         + engine.getPlayer().getDeaths(),                       bx + bw/2, by + 90);
        centered(g2, "Monedas: "         + countNormalCoins() + " / " + countTotalNormalCoins(), bx + bw/2, by + 112);
        centered(g2, "Tiempo restante: " + timeLeft + "s",                                        bx + bw/2, by + 134);
        if ("PVP".equals(gameMode) || (gameMode != null && gameMode.startsWith("PVM"))) {
            g2.setColor(new Color(255, 220, 80));
            centered(g2, gameMode.startsWith("PVM") ? "Ganó la partida" : "¡Ambos completaron!", bx + bw/2, by + 156);
        }
        setOverlayBtns(bx, by, bw);
        String lbl = currentLevel < TOTAL_LEVELS ? "SIGUIENTE" : "REINICIAR";
        btn(g2, btnPrimary, new Color(40,130,40), lbl);
        btn(g2, btnLevels,  new Color(40,40,160), "NIVELES");
        btn(g2, btnSave,    new Color(110,75,0),  "GUARDAR");
        btn(g2, btnExit,    new Color(160,30,30), "SALIR");
    }

    private void drawLose(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 160)); g2.fillRect(0, 0, W, H);
        int bw = 430, bh = 280, bx = (W - bw) / 2, by = (H - bh) / 2;
        g2.setPaint(new GradientPaint(bx, by, new Color(110, 20, 20), bx+bw, by+bh, new Color(55, 8, 8)));
        g2.fillRoundRect(bx, by, bw, bh, 20, 20);
        g2.setColor(new Color(220, 60, 60)); g2.setStroke(new BasicStroke(3));
        g2.drawRoundRect(bx, by, bw, bh, 20, 20);
        g2.setColor(new Color(255, 100, 100)); g2.setFont(new Font("Arial", Font.BOLD, 30));
        centered(g2, "¡TIEMPO AGOTADO!", bx + bw/2, by + 55);
        g2.setColor(Color.WHITE); g2.setFont(new Font("Arial", Font.PLAIN, 14));
        centered(g2, "Muertes: "           + engine.getPlayer().getDeaths(),                       bx + bw/2, by + 90);
        centered(g2, "Monedas recogidas: " + countNormalCoins() + " / " + countTotalNormalCoins(), bx + bw/2, by + 112);
        setOverlayBtns(bx, by, bw);
        btn(g2, btnPrimary, new Color(40,130,40), "REINTENTAR");
        btn(g2, btnLevels,  new Color(40,40,160), "NIVELES");
        btn(g2, btnSave,    new Color(110,75,0),  "GUARDAR");
        btn(g2, btnExit,    new Color(160,30,30), "SALIR");
    }

    private void centered(Graphics2D g2, String txt, int cx, int y) {
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(txt, cx - fm.stringWidth(txt) / 2, y);
    }

    private void btn(Graphics2D g2, Rectangle r, Color c, String lbl) {
        g2.setColor(c); g2.fillRoundRect(r.x, r.y, r.width, r.height, 10, 10);
        g2.setColor(Color.WHITE); g2.setStroke(new BasicStroke(1));
        g2.drawRoundRect(r.x, r.y, r.width, r.height, 10, 10);
        g2.setFont(new Font("Arial", Font.BOLD, 10));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(lbl, r.x + (r.width  - fm.stringWidth(lbl)) / 2,
                           r.y + (r.height + fm.getAscent()) / 2 - 2);
    }

    private Player makePlayer(String type, int x, int y) {
        switch (type) {
            case "BLUE":  return new BluePlayer(x, y);
            case "GREEN": return new GreenPlayer(x, y);
            default:      return new RedPlayer(x, y);
        }
    }

    private int[] spawnPos(int level, int player) {
        if (level == 2) return player == 2
                ? new int[]{N2_GX + 10, N2_GY + 20}
                : new int[]{N2_PX, N2_PY};
        if (level == 3) return player == 2
                ? new int[]{N3_P2X, N3_P2Y}
                : new int[]{N3_P1X, N3_P1Y};
        return player == 2
                ? new int[]{N1_GX + N1_ZW / 2 - 10, N1_GY + N1_BH / 2 - 10}
                : new int[]{N1_PX, N1_PY};
    }

    private int countNormalCoins() {
        return (int) engine.getCurrentLevel().getCoins().stream()
               .filter(c -> !c.isSkinCoin() && c.isCollected()).count();
    }

    private int countTotalNormalCoins() {
        return (int) engine.getCurrentLevel().getCoins().stream()
               .filter(c -> !c.isSkinCoin()).count();
    }

    public void doSave() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Guardar partida");
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String path = fc.getSelectedFile().getAbsolutePath();
            if (!path.endsWith(".txt")) path += ".txt";
            try {
                GameSave.save(path, currentLevel, p1OriginalType, engine.getPlayer(),
                              gameMode.startsWith("PV") ? p2OriginalType : null,
                              engine.getPlayer2(), timeLeft,
                              engine.getCurrentLevel().getCoins());
                JOptionPane.showMessageDialog(this, "¡Partida guardada!");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage());
            }
        }
    }

    public void doLoad() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Cargar partida");
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                GameSave.SaveData sd = GameSave.load(fc.getSelectedFile().getAbsolutePath());
                String mode = "NONE".equals(sd.player2Type) ? "PLAYER" : "PVP";
                startGame(mode, sd.player1Type,
                          "NONE".equals(sd.player2Type) ? null : sd.player2Type,
                          sd.levelNumber);
                engine.getPlayer().reset(sd.player1X, sd.player1Y);
                timeLeft = sd.timeLeft;
                List<Coin> coins = engine.getCurrentLevel().getCoins();
                for (int i = 0; i < sd.coinsState.length && i < coins.size(); i++)
                    if ("1".equals(sd.coinsState[i])) coins.get(i).collect();
                JOptionPane.showMessageDialog(this, "¡Partida cargada!");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al cargar: " + ex.getMessage());
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        keys[e.getKeyCode()] = true;
        if (e.getKeyCode() == KeyEvent.VK_P && !won && !lost) paused = !paused;
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) { timer.stop(); gui.showMenu(); }
    }
    @Override public void keyReleased(KeyEvent e) { keys[e.getKeyCode()] = false; }
    @Override public void keyTyped(KeyEvent e) {}
}