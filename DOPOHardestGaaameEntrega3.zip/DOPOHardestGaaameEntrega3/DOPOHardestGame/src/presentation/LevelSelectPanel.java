package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Pantalla de selección de nivel.
 * Los 3 niveles están desbloqueados desde el inicio.
 */
public class LevelSelectPanel extends JPanel {
    private final DopoHardestGameGUI gui;

    public LevelSelectPanel(DopoHardestGameGUI gui) {
        this.gui = gui;
        setPreferredSize(new Dimension(620, 412));
        setLayout(null);
        setBackground(new Color(155, 170, 215));
        build();
    }

    private void build() {
        JLabel title = new JLabel("SELECCIONA UN NIVEL");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(25, 35, 100));
        title.setBounds(0, 35, 620, 40);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title);

        JLabel sub = new JLabel("Todos los niveles están disponibles");
        sub.setFont(new Font("Arial", Font.PLAIN, 12));
        sub.setForeground(new Color(50, 60, 120));
        sub.setBounds(0, 72, 620, 20);
        sub.setHorizontalAlignment(SwingConstants.CENTER);
        add(sub);

        int btnW = 150, btnH = 120, gap = 30;
        int total = 3 * btnW + 2 * gap;
        int sx = (620 - total) / 2;
        int sy = 120;

        String[] levelNames = {"Nivel 1", "Nivel 2", "Nivel 3"};
        String[] levelDesc  = {
            "<html><center>Corredor recto<br>3 enemigos<br>Moneda skin verde</center></html>",
            "<html><center>Forma de L<br>6 enemigos<br>Monedas skin azul y roja</center></html>",
            "<html><center>Forma de U<br>7 enemigos<br>Checkpoint · 90s</center></html>"
        };
        Color[] levelColors = {
            new Color(40, 160, 60),
            new Color(30, 100, 180),
            new Color(150, 50, 30)
        };

        for (int i = 0; i < 3; i++) {
            final int level = i + 1;
            int x = sx + i * (btnW + gap);

            JButton btn = new JButton("<html><center><b>" + levelNames[i] + "</b><br><br>"
                                      + levelDesc[i] + "</center></html>");
            btn.setBounds(x, sy, btnW, btnH);
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setFocusPainted(false);
            btn.setBackground(levelColors[i]);
            btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            btn.addActionListener(e -> gui.startGame(level));
            add(btn);
        }

        JButton back = new JButton("← VOLVER");
        back.setBounds(18, 370, 115, 30);
        back.setBackground(new Color(130, 45, 130));
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Arial", Font.BOLD, 12));
        back.setFocusPainted(false);
        back.addActionListener(e -> gui.showMenu());
        add(back);
    }
}
