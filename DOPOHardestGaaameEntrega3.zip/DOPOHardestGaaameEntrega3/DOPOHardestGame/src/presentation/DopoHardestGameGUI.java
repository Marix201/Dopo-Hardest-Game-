package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Ventana principal y controlador de navegación entre pantallas.
 */
public class DopoHardestGameGUI {
    private JFrame           frame;
    private MenuPanel        menuPanel;
    private GamePanel        gamePanel;
    private HUDPanel         hudPanel;
    private LevelSelectPanel levelSelectPanel;

    public DopoHardestGameGUI() {
        frame = new JFrame("The DOPO Hardest Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        menuPanel = new MenuPanel(this);
        frame.add(menuPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void showMenu() {
        frame.getContentPane().removeAll();
        menuPanel = new MenuPanel(this);
        frame.add(menuPanel);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    public void showLevelSelect() {
        frame.getContentPane().removeAll();
        levelSelectPanel = new LevelSelectPanel(this);
        frame.add(levelSelectPanel);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    public void showInstructions() {
        frame.getContentPane().removeAll();
        menuPanel = new MenuPanel(this);
        menuPanel.goToInstructions();
        frame.add(menuPanel);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    /**
     * Inicia el juego con el modo y personajes elegidos en el menú.
     * @param levelNumber número de nivel a cargar (1-3)
     */
    public void startGame(int levelNumber) {
        String mode = menuPanel != null ? menuPanel.getSelectedMode() : "PLAYER";
        String p1   = menuPanel != null ? menuPanel.getSelectedP1()   : "RED";
        String p2   = menuPanel != null ? menuPanel.getSelectedP2()   : "BLUE";

        frame.getContentPane().removeAll();
        hudPanel  = new HUDPanel(this);
        gamePanel = new GamePanel(hudPanel, this);
        hudPanel.setGameTimer(gamePanel.getTimer());

        frame.setLayout(new BorderLayout());
        frame.add(hudPanel,  BorderLayout.NORTH);
        frame.add(gamePanel, BorderLayout.CENTER);
        frame.pack();
        frame.revalidate();
        frame.repaint();

        gamePanel.requestFocusInWindow();
        gamePanel.startGame(mode, p1, p2, levelNumber);
    }

    /**
     * Abre el diálogo de carga de partida.
     */
    public void loadGame() {
        frame.getContentPane().removeAll();
        hudPanel  = new HUDPanel(this);
        gamePanel = new GamePanel(hudPanel, this);
        hudPanel.setGameTimer(gamePanel.getTimer());

        frame.setLayout(new BorderLayout());
        frame.add(hudPanel,  BorderLayout.NORTH);
        frame.add(gamePanel, BorderLayout.CENTER);
        frame.pack();
        frame.revalidate();
        frame.repaint();

        gamePanel.requestFocusInWindow();
        // Arranca con valores por defecto; doLoad() los sobreescribe
        gamePanel.startGame("PLAYER", "RED", null, 1);
        gamePanel.doLoad();
    }
}
